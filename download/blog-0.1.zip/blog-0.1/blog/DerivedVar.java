/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

/**
 * A random variable whose value is a deterministic function of some 
 * basic variables.  In this default implementation, the DerivedVar's value 
 * is given by some ArgSpec.  
 */
public class DerivedVar implements BayesNetVar {
    /**
     * Creates a new DerivedVar whose value is given by <code>argSpec</code>.
     */
    public DerivedVar(ArgSpec argSpec) {
	this.argSpec = argSpec;
	this.assignment = new Assignment();
    }

    /**
     * Creates a new DerivedVar whose value is given by <code>argSpec</code>
     * under assignment <code>a</code>.
     */
    public DerivedVar(ArgSpec argSpec, Assignment a) {
	this.argSpec = argSpec;
	this.assignment = a;
    }

    public boolean isDetermined(PartialWorld w) {
	return argSpec.isDetermined(w, assignment);
    }

    /**
     * Always returns 1, since the probability that a derived variable 
     * takes on its value given its parents is always 1.  Note that 
     * PartialWorld objects do not store values for derived variables, so 
     * we don't need to worry about the case where the world is storing 
     * the wrong value.
     */
    public double getProbOfValue(PartialWorld w) {
	return 1;
    }

    /**
     * Returns the value of this random variable in the given world.  
     *
     * @throws IllegalArgumentException if the given partial world is not 
     *                                  complete enough to determine the 
     *                                  value of this variable
     */
    public Object getValue(PartialWorld w) {
	ParentsAndValue info 
	    = argSpec.getParentsAndValue(w, assignment, 
					 ValueChooser.NO_INSTANTIATION);
	return info.getValue();
    }	

    /**
     * Ensures that the given basic variable is supported (that is, all its 
     * active ancestors are instantiated) in the given world.  If new values 
     * are needed for variables, they are obtained by calling the 
     * <code>chooseValue</code> method on the given 
     * <code>ValueChooser</code> object.
     *
     * <p>Because world objects do not store values for derived variables, 
     * this method never has to instantiate this variable; it just has to 
     * ensure it is supported.
     *
     * @return a ParentsAndValue object containing the active parent set 
     *         and (possibly new) value of this variable
     */
    public ParentsAndValue ensureInstAndSupported(PartialWorld w, 
						  ValueChooser chooser) {
	return argSpec.getParentsAndValue(w, assignment, chooser);
    }

    /**
     * Returns the string representation of this derived variable's 
     * ArgSpec.
     */
    public String toString() {
	// TODO: have the string represent the assignment as well
	return ("DerivedVar " + argSpec.toString());
    }

    protected ArgSpec argSpec;
    protected Assignment assignment;
}
