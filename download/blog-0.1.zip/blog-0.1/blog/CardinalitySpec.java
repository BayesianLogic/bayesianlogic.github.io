/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import common.Multiset;

/**
 * Argument specifier that refers to the size of an implicitly defined 
 * set.  
 */
public class CardinalitySpec extends ArgSpec {
    /**
     * Creates a new CardinalitySpec that counts the elements in the 
     * given implicitly defined set.
     */
    public CardinalitySpec(ImplicitSetSpec setSpec) {
	this.setSpec = setSpec;
    }

    public ImplicitSetSpec getSetSpec() {
	return setSpec;
    }

    /**
     * Returns the active parents and value of this ArgSpec in the 
     * given partial world.  If the world is not complete enough to 
     * evaluate this ArgSpec, uses the given ValueChooser object to 
     * instantiate the necessary basic variables.  If the world is 
     * not complete enough and the ValueChooser is null, then this 
     * method returns null.  
     *
     * <p>The parents of a CardinalitySpec are just the parents of 
     * the underlying ImplicitSetSpec.  
     */
    public ParentsAndValue getParentsAndValue(PartialWorld w, 
					      Assignment a, 
					      ValueChooser chooser) {
	ParentsAndValue info = setSpec.getParentsAndValue(w, a, chooser);
	if (info == null) {
	    return null;
	}
	Integer value = new Integer(((PartEnumSet) info.getValue()).size());
	return new ParentsAndValue(info.getParents(), value);
    }

    public boolean checkTypesAndScope(Map scope) {
	return setSpec.checkTypesAndScope(scope);
    }

    public boolean isNumeric() {
	return true;
    }

    public boolean equals(Object o) {
	if (o instanceof CardinalitySpec) {
	    CardinalitySpec other = (CardinalitySpec) o;
	    return setSpec.equals(other.getSetSpec());
	}
	return false;
    }

    public int hashCode() {
	return setSpec.hashCode();
    }

    public String toString() {
	return ("#" + setSpec);
    }

    private ImplicitSetSpec setSpec;
}
