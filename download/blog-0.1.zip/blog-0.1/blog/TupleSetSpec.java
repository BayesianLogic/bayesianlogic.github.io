/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import common.AbstractTupleIterator;
import common.Multiset;
import common.HashMultiset;
import common.HashMapDiff;

/** Represents an argument - set consisting of implicitly specified
 * tuples.  The components of each tuple are assumed to be Terms. The
 * general form of the i-th component of a tuple is specified by the
 * object in the i-th position of <code>tuple</tuple>. The variables
 * in all components of the tuple <code>set_elt</code> and possible
 * additional variables, all contained in <code>vars</code>, satisfy
 * the given Formula <code>cond</cond>.
 */
public class TupleSetSpec extends ArgSpec{

    
    public TupleSetSpec( List tuple, List var_types, List vars, 
			 Formula cond ){

	this.tuple = tuple;
	this.vars = vars;
	this.var_types = var_types;
	this.cond = cond;

	// Convert cond to propositional DNF and treat each disjunct 
	// separately.  For each disjunct, keep array of object generation 
	// graphs, one for each element of the tuple.  In the graph for 
	// variable i, later variables are free.  

	disjuncts = cond.getPropDNF().getDisjuncts();
	objGenGraphs = new ObjGenGraph[disjuncts.size()][vars.size()];
	for (int i = 0; i < disjuncts.size(); ++i) {
	    List constraints = ((ConjFormula) disjuncts.get(i)).getConjuncts();
	    for (int j = 0; j < vars.size(); ++j) {
		List freeVars = vars.subList(j, vars.size());
		objGenGraphs[i][j] = new ObjGenGraph((Type) var_types.get(j), 
						     (String) vars.get(j),
						     constraints, 
						     new HashSet(freeVars));
	    }
	}
    }


    public List getGenericTuple( ){

	return tuple;

    }


    public List  getParams( ){

	return vars;

    }


    public List getParamTypes( ){

	return var_types;

    }

  
    public Formula getCond( ){

	return cond;

    }

    /**
     * Returns the active parents and value of this formula in the 
     * given partial world.  If the world is not complete enough to 
     * evaluate this formula, uses the given ValueChooser object to 
     * instantiate the necessary basic variables.  If the world is 
     * not complete enough and the ValueChooser is null, then this 
     * method returns null.  
     *
     * <p>This method first enumerates the assignments that satisfy the 
     * first disjunct, then those that satisfy the second but not 
     * the first, etc.  If the VarValuesIterator for the first disjunct 
     * returns infinitely many values, this process will never invoke 
     * the VarValuesIterators for the remaining disjuncts.  But there's no 
     * such thing as short-circuit evaluation for TupleSetSpecs anyway: 
     * we always return the whole set.  
     */
    public ParentsAndValue getParentsAndValue(PartialWorld w, 
					      Assignment a, 
					      ValueChooser chooser) {
	Multiset s = new HashMultiset();
	Assignment b = new Assignment(a);
	Set parents = new HashSet();

	for (int i = 0; i < disjuncts.size(); ++i) {
	    // Iterate over assignments that might satisfy disjunct i
	    ObjectIterator iter = new VarValuesIterator(w, a, chooser, i);
	    while (iter.hasNext()) {
		b.addTupleBinding(vars, (List) iter.next());
		Boolean isFirst = isFirstSatisfiedDisjunct(w, b, chooser, 
							   i, parents);
		if (isFirst == null) {
		    return null;
		}
		if (isFirst.booleanValue()) {
		    // These values satisfy disjunct i and no earlier disjunct
		    List tuple = evaluateTuple(w, b, chooser, parents);
		    if (tuple == null) {
			return null;
		    }
		    s.add(tuple);
		}
	    }
	    if (!iter.canComputeNext()) {
		return null;
	    }
	    parents.addAll(iter.getParents());
	}

	return new ParentsAndValue(parents, s);
    }

    public boolean checkTypesAndScope(Map scope) {
	Map extendedScope = new HashMapDiff(scope);
	for (int i = 0; i < vars.size(); ++i) {
	    extendedScope.put(vars.get(i), var_types.get(i));
	}

	for (Iterator iter = tuple.iterator(); iter.hasNext(); ) {
	    if (!((Term) iter.next()).checkTypesAndScope(extendedScope)) {
		return false;
	    }
	}
	return true;
    }

    /**
     * Two tuple set specifications are equivalent if they have the same 
     * tuple of terms, variable type list, variable list, and condition.  
     * There are various ways to construct a tuple set specification that 
     * is equivalent to a given specification (rename the variables, reorder 
     * the variables and types, etc.), but we do not consider those 
     * variations equal to the given specification.
     */
    public boolean equals(Object o) {
	if (o instanceof TupleSetSpec) {
	    TupleSetSpec other = (TupleSetSpec) o;
	    return (tuple.equals(other.getGenericTuple())
		    && vars.equals(other.getParams())
		    && var_types.equals(other.getParamTypes())
		    && cond.equals(other.getCond()));
	}
	return false;
    }

    public int hashCode() {
	return (tuple.hashCode() ^ vars.hashCode() ^ var_types.hashCode() 
		^ cond.hashCode());
    }

    /**
     * Returns a string of the form 
     * <blockquote>
     *   {t1, ..., tK for T1 v1, ..., TN vN : cond} 
     * </blockquote>
     * where t1, ..., tK are the terms, T1, ..., TN are the variable types, 
     * v1, ..., vN are the variables, and cond is the condition.
     */
    public String toString() {
	StringBuffer buf = new StringBuffer();
	buf.append("{");

	if (!tuple.isEmpty()) {
	    buf.append(tuple.get(0));
	    for (int i = 1; i < tuple.size(); ++i) {
		buf.append(", ");
		buf.append(tuple.get(i));
	    }
	}

	buf.append(" for ");

	if (!vars.isEmpty()) {
	    buf.append(var_types.get(0) + " " + vars.get(0));
	    for (int i = 1; i < vars.size(); ++i) {
		buf.append(", ");
		buf.append(var_types.get(i) + " " + vars.get(i));
	    }
	}

	buf.append(" : ");
	buf.append(cond);
	buf.append("}");
	return buf.toString();
    }

    /**
     * Returns a List containing the values of the terms <code>tuple</code> 
     * evaluated in the given world with the given assignment.  
     */
    private List evaluateTuple(PartialWorld w, Assignment b, 
			       ValueChooser chooser, Set parents) {
	List result = new ArrayList();
	for (Iterator iter = tuple.iterator(); iter.hasNext(); ) {
	    ParentsAndValue info = ((Term) iter.next()).getParentsAndValue
		(w, b, chooser);
	    if (info == null) {
		return null;
	    }
	    result.add(info.getValue());
	    parents.addAll(info.getParents());
	}
	return result;
    }

    private Boolean isFirstSatisfiedDisjunct(PartialWorld w, Assignment b, 
					     ValueChooser chooser, 
					     int disjIndex, Set parents) {
	ParentsAndValue info = ((Formula) disjuncts.get(disjIndex))
	    .getParentsAndValue(w, b, chooser);
	if (info == null) {
	    return null;
	}
	parents.addAll(info.getParents());
	if (!((Boolean) info.getValue()).booleanValue()) {
	    return Boolean.FALSE;
	}

	for (int i = 0; i < disjIndex; ++i) {
	    info = ((Formula) disjuncts.get(i))
		.getParentsAndValue(w, b, chooser);
	    if (info == null) {
		return null;
	    }
	    parents.addAll(info.getParents());
	    if (((Boolean) info.getValue()).booleanValue()) {
		return Boolean.FALSE;
	    }
	}

	return Boolean.TRUE;
    }

    /**
     * Inner class for iterating over tuples of objects that satisfy 
     * the tuple of object generation graphs for a particular disjunct.  
     * An AbstractTupleIterator is not guaranteed to return every tuple 
     * after finitely many steps: if its last object generation graph 
     * has infinitely many satisfiers, it will loop forever returning 
     * tuples that only differ in their last element.  But this is ok 
     * because short-circuit evaluation is impossible for TupleSetSpecs 
     * anyway.
     */
    private class VarValuesIterator extends AbstractTupleIterator 
                                    implements ObjectIterator {
	VarValuesIterator(PartialWorld w, Assignment a, ValueChooser chooser, 
			  int disjIndex) {
	    super(vars.size());
	    this.w = w;
	    this.b = new Assignment(a);
	    this.chooser = chooser;
	    this.disjIndex = disjIndex;
	}

	protected Iterator getIterator(int indexInTuple, List tuple) {
	    if (!canComputeNext()) {
		return ObjectIterator.STUCK_ITER;
	    }

	    for (int i = 0; i < indexInTuple; ++i) {
		b.add((String) vars.get(i), tuple.get(i));
	    }

	    Iterator iter = objGenGraphs[disjIndex][indexInTuple]
		.iterator(w, b, chooser);
	    return iter;
	}

	protected void doneWithIterator(Iterator iter) {
	    if (!((ObjectIterator) iter).canComputeNext()) {
		// The reason why iter's getNext method returned false was 
		// that the partial world was not complete enough
		canComputeNext = false;
	    } else {
		parents.addAll(((ObjectIterator) iter).getParents());
	    }
	}

	public Set getParents() {
	    return parents;
	}

	public boolean canComputeNext() {
	    return canComputeNext;
	}

	PartialWorld w;
	Assignment b;
	ValueChooser chooser;
	int disjIndex;

	Set parents = new HashSet();
	boolean canComputeNext = true;
    }

    private List tuple; // of Term
    private List vars; // of String
    private List var_types; // of Type
    private Formula cond;

    List disjuncts; // of ConjFormula;
    ObjGenGraph[][] objGenGraphs;
}
