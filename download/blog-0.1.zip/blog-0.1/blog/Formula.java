/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;


/** Formula is an abstract class from which all classes denoting particular 
 * kinds of formulas inherit. A formula can be "wrapped" in the class Wrapper 
 * that facilitates error-checking.
 */
public abstract class Formula extends ArgSpec {


    /** Returns the logical value of the formula with respect to the given 
     * with respect to the given world and assignment (a set of variable 
     * bindings).
     */
    public boolean isTrue(PartialWorld w, Assignment a) {
	return ((Boolean) evaluate(w, a)).booleanValue();
    }



    /**
     * Returns a new formula in which:
     * <ul>
     * <li> occurrences of the formula "true" have been converted to 
     *      empty conjunctions;
     * <li> implications have been converted to disjunctions;
     * <li> only literals (atomic/equality/nullity formulas) are negated.
     * </ul>
     * The default implementation just returns this formula.
     */
    public Formula getStandardForm() {
	return this;
    }

    /**
     * Returns a formula that is equivalent to the negation of this formula 
     * but is not a NegFormula.  If no such formula exists, returns null.
     *
     * <p>The default implementation returns null.
     */
    public Formula getEquivToNegation() {
	return null;
    }

    /**
     * Returns the proper subformulas of this formula.  The default 
     * implementation returns an empty list.
     *
     * @return unmodifiable List of Formula objects
     */
    public List getSubformulas() {
	return Collections.EMPTY_LIST;
    }

    /**
     * Returns the terms that are part of this formula, but not part of 
     * any other term or formula within this formula.  The default 
     * implementation returns an empty list.
     *
     * @return unmodifiable List of Term objects
     */
    public List getTopLevelTerms() {
	return Collections.EMPTY_LIST;
    }

    /**
     * Returns true if this formula contains the given term.
     */
    public boolean containsTerm(Term target) {
	for (Iterator iter = getSubformulas().iterator(); iter.hasNext(); ) {
	    if (((Formula) iter.next()).containsTerm(target)) {
		return true;
	    }
	}

	for (Iterator iter = getTopLevelTerms().iterator(); iter.hasNext(); ) {
	    if (((Term) iter.next()).containsTerm(target)) {
		return true;
	    }
	}

	return false;
    }

    /**
     * Returns the set of generating functions that are applied to the
     * term <code>subject</code> anywhere in this formula.  
     *
     * @return unmodifiable Set of GeneratingFunction
     */
    public Set getGenFuncsApplied(Term subject) {
	Set genFuncs = new HashSet();
	
	for (Iterator iter = getSubformulas().iterator(); 
	     iter.hasNext(); ) {
	    Formula sub = (Formula) iter.next();
	    genFuncs.addAll(sub.getGenFuncsApplied(subject));
	}
	
	for (Iterator iter = getTopLevelTerms().iterator();
	     iter.hasNext(); ) {
	    Term t = (Term) iter.next();
	    genFuncs.addAll(t.getGenFuncsApplied(subject));
	}

	return Collections.unmodifiableSet(genFuncs);
    }

    /**
     * Returns an equivalent formula that consists of a conjunction where 
     * each conjunct is an elementary disjunction.  An elementary formula 
     * is one in which all the subformulas are atomic, equality, or nullity 
     * formulas, or negations of those formulas, or unnegated quantified 
     * formulas.  This is "propositional" CNF in that quantified 
     * formulas are treated as atomic.  
     *
     * <p>The default implementation just returns a conjunction consisting 
     * of one disjunction, whose sole disjunct is this formula.  This is the 
     * correct behavior for literals and quantified formulas.
     */
    public ConjFormula getPropCNF() {
	return new ConjFormula(new DisjFormula(this));
    }

    /**
     * Returns an equivalent formula that consists of a disjunction where 
     * each disjunct is an elementary conjunction.  An elementary formula 
     * is one in which all the subformulas are atomic, equality, or nullity 
     * formulas, or negations of those formulas, or unnegated quantified 
     * formulas.  This is "propositional" DNF in that quantified 
     * formulas are treated as atomic.  
     *
     * <p>The default implementation just returns a disjunction consisting 
     * of one conjunction, whose sole conjunct is this formula.  This is the 
     * correct behavior for literals and quantified formulas.
     */
    public DisjFormula getPropDNF() {
	return new DisjFormula(new ConjFormula(this));
    }

    /**
     * Returns true if this formula is a literal, that is, an 
     * atomic/equality/nullity formula or the negation thereof.
     * The default implementation returns false.
     */
    public boolean isLiteral() {
	return false;
    }

    /**
     * Returns true if this is a quantified formula.  The default 
     * implementation returns false.
     */
    public boolean isQuantified() {
	return false;
    }

    /**
     * Returns true if this formula is elementary, that is, all its 
     * subformulas are literals or unnegated quantified formulas.  
     */
    public boolean isElementary() {
	for (Iterator iter = getSubformulas().iterator(); iter.hasNext(); ) {
	    Formula sub = (Formula) iter.next();
	    if (!(sub.isLiteral() || sub.isQuantified())) {
		return false;
	    }
	}
	return true;
    }
}
