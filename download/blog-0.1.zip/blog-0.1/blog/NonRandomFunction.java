/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;



import java.util.*;
import java.io.PrintStream;


/** Represents non-random function objects, whose value for the given tuple of
 * arguments is constant over worlds. Non-random functions do not have
 * dependency statement like the random functions do. Instead, the user is 
 * expected to write a class that inherits from NonRandomFunction and 
 * implements its getValue(.) method.
 *
 * @see blog.Function
 */
public abstract class NonRandomFunction extends Function {
    public NonRandomFunction( String fname, List arg_types, 
			     Type ret_type ) {

	super( fname, arg_types, ret_type );

    }


    public abstract Object getValue( List args );

    public Object getValueInWorld(List args, PartialWorld w, 
				  ValueChooser chooser, Set parents) {
	if (!w.areValidObjects(args)) {
	    throw new IllegalArgumentException
		("Some of the following arguments do not exist: " + args);
	}

	if (args.contains(Model.NULL)) {
	    return Model.NULL;
	}

	List specificArgs = Function.getSpecificArgs(args, w, chooser);
	if (specificArgs == null) {
	    return null;
	}

	return getValue(specificArgs);
    }

    /**
     * Prints a description of this NonRandomFunction to the given stream.
     */
    public void print(PrintStream s) {
	s.print("nonrandom ");
	s.print(getRetType());
	s.print(" ");
	s.print(getName());
	s.print("(");

	Iterator iter = getArgTypes().iterator();
	if (iter.hasNext()) {
	    s.print(iter.next());
	    while (iter.hasNext()) {
		s.print(", ");
		s.print(iter.next());
	    }
	}

	s.print(") defined by ");
	s.println(getClass());
    }

}
