/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;


/** 
 * A Formula consisting of a single boolean-valued term.
 *
 * @see blog.Term
 * @see blog.Formula
 */
public class AtomicFormula extends Formula {


    public AtomicFormula( Term sent ){

	this.sent = sent;

    }


    public Term getTerm( ) {

	return sent;

    }
    

    /**
     * Returns the active parents and value of this formula in the 
     * given partial world.  If the world is not complete enough to 
     * evaluate this formula, uses the given ValueChooser object to 
     * instantiate the necessary basic variables.  If the world is 
     * not complete enough and the ValueChooser is null, this method 
     * returns null. 
     */
    public ParentsAndValue getParentsAndValue(PartialWorld w, 
					      Assignment a, 
					      ValueChooser chooser) {
	return sent.getParentsAndValue(w, a, chooser);
    }

    /**
     * Returns the (basic or derived) random variable that this atomic
     * formula corresponds to under the given assignment.  This is just 
     * the random variable corresponding to underlying Boolean term.
     */
    public BayesNetVar getVariable(Assignment a) {
	return sent.getVariable(a);
    }

    /**
     * Returns true.
     */
    public boolean isLiteral() {
	return true;
    }

    public List getTopLevelTerms() {
	return Collections.singletonList(sent);
    }

    /**
     * Two atomic formulas are equal if their underlying terms are equal.
     */
    public boolean equals(Object o) {
	if (o instanceof AtomicFormula) {
	    AtomicFormula other = (AtomicFormula) o;
	    return sent.equals(other.getTerm());
	}
	return false;
    }

    public int hashCode() {
	return sent.hashCode();
    }

    /**
     * Returns the string representation of the underlying term.
     */
    public String toString() {
	return sent.toString();
    }

    /**
     * Returns true if the underlying term satisfies the type/scope
     * constraints and has a Boolean type.
     */
    public boolean checkTypesAndScope(Map scope) {
	return (sent.checkTypesAndScope(scope)
		&& sent.getType(scope).isSubtypeOf(BuiltInTypes.BOOLEAN));
    }

    /** The Term instance, assumed to be boolean-valued */
    private Term sent;

}

