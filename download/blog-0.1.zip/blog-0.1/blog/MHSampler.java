/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import common.Util;
import common.Timer;
import java.lang.reflect.Constructor;

/**
 * Generates samples from a Markov chain over possible worlds using a 
 * Metropolis-Hastings algorithm.  The proposal distribution for this 
 * algorithm is represented by an object that implements the Proposer 
 * interface.  
 *
 * <p>The MHSampler constructor looks at the following properties in the 
 * properties table that is passed in:
 * <dl>
 * <dt>proposerClass
 * <dd>Name of the proposer class to use.  This class must implement 
 *     the Proposer interface.  Default: blog.GenericProposer.
 * </dl> 
 * The property table is also passed to the proposer's constructor.
 */
public class MHSampler extends Sampler {
    /**
     * Creates a new sampler for the given BLOG model.  The properties 
     * table specifies configuration parameters.  In particular, this 
     * constructor looks for the following properties:
     */
    public MHSampler(Model model, Properties properties) {
	super(model);

	String proposerClassName = properties.getProperty
	    ("proposerClass", "blog.GenericProposer");
	System.out.println("Constructing M-H proposer of class "
			   + proposerClassName);

	try {
	    Class proposerClass = Class.forName(proposerClassName);
	    Class[] paramTypes = new Class[2];
	    paramTypes[0] = model.getClass();
	    paramTypes[1] = properties.getClass();
	    Constructor constructor = proposerClass.getConstructor(paramTypes);
	    
	    Object[] args = new Object[2];
	    args[0] = model;
	    args[1] = properties;
	    proposer = (Proposer) constructor.newInstance(args);
	} catch (java.lang.reflect.InvocationTargetException e) {
	    Util.fatalError(e.getCause(), true, true);
	} catch (Exception e) {
	    Util.fatalError(e, true, true);
	}
    }

    public void initialize(Evidence evidence, List queries) {
	super.initialize(evidence, queries);
	++numTrials;
	numSamplesThisTrial = 0;
	numAcceptedThisTrial = 0;

	curWorld = proposer.getInitialState(evidence, queries);
	curWorld.save();
	if (Main.verbose()) {
	    System.out.println("Initial world:");
	    curWorld.print(System.out);
	    System.out.println();
	}

	if (!validateIdentifiers(curWorld)) {
	    Util.fatalError("Fatal identifier errors in initial world.", true,
			    true);
	}

	if (!evidence.isTrue(curWorld)) {
	    throw new IllegalStateException
		("Error: evidence is not true in initial world.");
	}
    }
	

    /**
     * Generates the next world in the Markov chain.  This method gets a 
     * proposed world from the Proposer.  If the proposal is accepted, then 
     * the next world is the proposed world; otherwise the next world is 
     * the same as the previous world.  
     */
    public void nextSample() {
	++totalNumSamples;
	++numSamplesThisTrial;

	// Propose new world and get log proposal ratio, which is:
	//    log (q(x | x') / q(x' | x))
	// where x is current world, x' is proposed new world, and 
	// q is proposal distribution.  The proposer changes curWorld,
	// but the saved world is unchanged, and we can revert curWorld 
	// to this saved version if we reject the proposal.
	if (Main.verbose()) {
	    System.out.println("Proposing world...");
	}
	double logProposalRatio = proposer.proposeNextState(curWorld);
	if (Main.verbose()) {
	    System.out.println("Proposed world:");
	    curWorld.print(System.out);
	    System.out.println();
	    System.out.println("\tlog proposal ratio: " 
			       + logProposalRatio);
	}

	if (!validateIdentifiers(curWorld)) {
	    Util.fatalError("Fatal identifier errors in proposed world.", 
			    true, true);
	}

	// Compute the acceptance probability
	double logProbRatio 
	    = computeLogProbRatio(curWorld.getSaved(), curWorld);
	if (Main.verbose()) {
	    System.out.println("\tlog probability ratio: " + 
			       logProbRatio);
	}
	double logAcceptRatio 
	    = logProbRatio + logProposalRatio;
	if (Main.verbose()) {
	    System.out.println("\tlog acceptance ratio: " +
			       logAcceptRatio);
	}

	// Accept or reject proposal
	if ((logAcceptRatio >= 0)
	    || (Util.random() < Math.exp(logAcceptRatio))) {
	    curWorld.save(); 
	    if (Main.verbose()) {
		System.out.println("\taccepted");
	    }
	    ++totalNumAccepted;
	    ++numAcceptedThisTrial;

	} else {
	    curWorld.revert(); // clean slate for next proposal
	    if (Main.verbose()) {
		System.out.println("\trejected");
	    }
	}
    }

    public PartialWorld getLatestWorld() {
	return curWorld;
    }

    /**
     * Checks whether identifiers are used properly in the given
     * world.  For every identifier, the world should determine that
     * it satisfies a particular POP application, and the number
     * variable for this POP application should be instantiated.
     * Also, every identifier should be the value of some basic
     * variable (specifically a random function application variable,
     * since the values of number variables are integers).  Prints
     * error messages if it finds errors.
     *
     * @return true if the world is valid, false otherwise
     */
    private boolean validateIdentifiers(MutablePartialWorld world) {
	boolean valid = true;

	Set newlyUnsourced = world.getNewlyUnsourcedIds();
	if (!newlyUnsourced.isEmpty()) {
	    valid = false;
	}
	for (Iterator iter = newlyUnsourced.iterator(); iter.hasNext(); ) {
	    System.err.println("Error: World does not determine POP app"
			       + "satisfied by identifier: " + iter.next());
	}

	Set newlyImpossible = world.getNewlyImpossibleIds();
	if (!newlyImpossible.isEmpty()) {
	    valid = false;
	}
	for (Iterator iter = newlyImpossible.iterator(); iter.hasNext(); ) {
	    System.err.println("Error: World determines that identifier " 
			       + iter.next() + " satisfies no POP app.");
	}

	Set newlyMissing = world.getNewlyMissingNumberVars();
	if (!newlyMissing.isEmpty()) {
	    valid = false;
	}
	for (Iterator iter = newlyMissing.iterator(); iter.hasNext(); ) {
	    System.err.println("Error: Number variable " + iter.next()
			       + " is satisfied by some identifiers, "
			       + "but is not instantiated.");
	}

	Set newlyFloating = world.getNewlyFloatingIds();
	if (!newlyFloating.isEmpty()) {
	    valid = false;
	}
	for (Iterator iter = newlyFloating.iterator(); iter.hasNext(); ) {
	    System.err.println("Error: Identifier " + iter.next()
			       + " is not the value of any basic variable.");
	}

	return valid;
    }

    /**
     * Computes the log probability ratio:
     *     log (p(x') / p(x))
     * where x is the current world, x' is the proposed new world, and 
     * p is the posterior distribution defined by the model and the evidence.  
     * This method treats worlds that do not satisfy the evidence as having 
     * probability zero.  This means that the acceptance probability is 0 if 
     * the proposed new world does not satisfy the evidence, and undefined if 
     * the current world does not satisfy the evidence. 
     */
    private double computeLogProbRatio(PartialWorld savedWorld, 
				       MutablePartialWorld proposedWorld) {
	double logProbRatio = 0;

	Set varsWithChangedMultipliers 
	    = proposedWorld.getVarsWithChangedMultipliers();
	for (Iterator iter = varsWithChangedMultipliers.iterator();
	     iter.hasNext(); ) {	    
	    NumberVar v = (NumberVar) iter.next();

	    // The multiplier is n! / (n-k)! where n is the value of the 
	    // number variable, and k is the number of identifiers that 
	    // satisfy the number variable.  Note: this multiplier is only 
	    // correct if distinct assignments of objects to identifiers 
	    // yield concrete partial worlds that represent disjoint events. 
	    // One way to guarantee this is to ensure that each identifier 
	    // used in a partial world is the value of some term in that 
	    // partial world.  
	    double currentLogMult = 0;
	    if (savedWorld.isInstantiated(v)) {
		int numSat = savedWorld.getNumSatisfiers(v.pop(), v.args());
		int numIds = savedWorld.getSatisfyingIds(v.pop(), v.args())
		    .size();
		if (numIds > numSat) {
		    currentLogMult = Double.NEGATIVE_INFINITY;
		} else {
		    currentLogMult = Util.logPartialFactorial(numSat, numIds);
		}
	    }

	    double proposedLogMult = 0;
	    if (proposedWorld.isInstantiated(v)) {
		int numSat = proposedWorld.getNumSatisfiers(v.pop(), v.args());
		int numIds = proposedWorld.getSatisfyingIds(v.pop(), v.args())
		    .size();
		if (numIds > numSat) {
		    proposedLogMult = Double.NEGATIVE_INFINITY;
		} else {
		    proposedLogMult = Util.logPartialFactorial(numSat, numIds);
		}
	    }

	    logProbRatio -= currentLogMult;
	    logProbRatio += proposedLogMult;

	    if (Main.verbose()) {
		System.out.println("Current p multiplier: " + 
				   Math.exp(currentLogMult));
		System.out.println("Proposed p multiplier: " + 
				   Math.exp(proposedLogMult));
	    }
	}

	Set varsWithChangedProbs = proposedWorld.getVarsWithChangedProbs();
	for (Iterator iter = varsWithChangedProbs.iterator(); 
	     iter.hasNext(); ) {

	    BayesNetVar v = (BayesNetVar) iter.next();
	    double probInCurWorld = v.getProbOfValue(savedWorld);
	    double probInProposedWorld = v.getProbOfValue(proposedWorld);

	    // This is just in case the proposal changes the values of some 
	    // evidence variables.
	    if (evidence.getEvidenceVars().contains(v)) {
		Object obsVal = evidence.getObservedValue(v);
		if (!v.getValue(savedWorld).equals(obsVal)) {
		    probInCurWorld = 0;
		}
		if (!v.getValue(proposedWorld).equals(obsVal)) {
		    probInProposedWorld = 0;
		}
	    }
	    
	    if (Main.verbose()) {
		System.out.println("Variable " + v + " going from probability "
				   + probInCurWorld + " to probability " 
				   + probInProposedWorld);
	    }

	    logProbRatio -= Math.log(probInCurWorld);
	    logProbRatio += Math.log(probInProposedWorld);
	}
	return logProbRatio;
    }

    /**
     * Print statistics gathered during sampling to standard out.  These
     * figures are gathered during each call to sample() and is called once at
     * the end of each trial.
     */
    public void printStats() {
	System.out.println("======== MH Trial Stats ========");
	if (totalNumSamples > 0) {
	    if (numSamplesThisTrial > 0) {
		System.out.println
		    ("Fraction of proposals accepted (this trial): " 
		     + (numAcceptedThisTrial / (double) numSamplesThisTrial));
	    }
	    System.out.println
		("Fraction of proposals accepted (running avg, all trials): " 
		 + (totalNumAccepted / (double) totalNumSamples));
	} else {
	    System.out.println("No samples yet.");
	}
	    
	proposer.printStats();
    }

    private Proposer proposer;

    private MutablePartialWorld curWorld;

    private int numTrials = 0;
    private int totalNumSamples = 0;
    private int totalNumAccepted = 0;

    private int numSamplesThisTrial = 0;
    private int numAcceptedThisTrial = 0;
}
