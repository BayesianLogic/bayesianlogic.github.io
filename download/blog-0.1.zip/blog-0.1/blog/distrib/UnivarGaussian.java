/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog.distrib;

import blog.*;
import java.util.*;

//Based on http://www.cs.princeton.edu/introcs/26function/MyMath.java.html

public class UnivarGaussian extends AbstractCondProbDistrib{
    public UnivarGaussian(){
	mu = 0;
	sigma = 1;
    }

 
    public UnivarGaussian(List params){
	if (params.size() != 2) {
		throw new IllegalArgumentException
		    ("Univariate Gaussian distribution requires exactly 2 "
		     + "parameters, "
		     + "not " + params.size() + ".");
	    }

	    if (!(params.get(0) instanceof Number)){
		throw new IllegalArgumentException 
		    ("The first parameter (mean) for the univariate Gaussian "
		     + "distribution must be of "
		     + "type Number, not " + params.get(0).getClass() + ".");
	    }

	    mu = ((Number)params.get(0)).doubleValue();

	    if (!(params.get(1) instanceof Number)){
		throw new IllegalArgumentException 
		    ("The second parameter (variance) for the univariate "
		     + "Gaussian "
		     + "distribution must be of "
		     + "type Number, not " + params.get(1).getClass() + ".");
	    }

	    sigma =  ((Number)params.get(1)).doubleValue();

	    if (sigma < 0){
		throw new IllegalArgumentException 
		    ("The second parameter (variance) for the univariate "
		     + "Gaussian "
		     + "distribution must be positive; current value: "
		     + sigma + ".");
	    }
    }


    public double getProb(List args, Object value){
	if(!(value instanceof Number))
	    throw new IllegalArgumentException
		("The value passed to the univariate Gaussian distribution's "
		 + "getProb "
		 + "method must be of type Number, not "+value.getClass()+".");

	return Math.exp(-Math.pow((((Number)value).doubleValue() - mu), 2)
			/(2*Math.pow(sigma, 2)))
	                                   /(sigma * Math.sqrt(2 * Math.PI));
    }


    public Object sampleVal(List args, Type childType){
	double U = Math.random();
        double V = Math.random();
        return new Double(mu + sigma * 
	    Math.sin(2 * Math.PI * V) * Math.sqrt((-2 * Math.log(U))));
    }


    // fractional error less than 1.2 * 10 ^ -7.
    private double erf(double z) {
        double t = 1.0 / (1.0 + 0.5 * Math.abs(z));

        // use Horner's method
        double ans = 1 - t * Math.exp( -z*z   -   1.26551223 +
                                            t * ( 1.00002368 +
                                            t * ( 0.37409196 + 
                                            t * ( 0.09678418 + 
                                            t * (-0.18628806 + 
                                            t * ( 0.27886807 + 
                                            t * (-1.13520398 + 
                                            t * ( 1.48851587 + 
                                            t * (-0.82215223 + 
                                            t * ( 0.17087277))))))))));
        if (z >= 0) return  ans;
        else        return -ans;
    }


    private double mu;
    private double sigma;
}
