/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog.distrib;

import blog.*;
import java.util.*;
import Jama.*;

public class MultivarGaussian extends AbstractCondProbDistrib{
   
    /** Sets mean and covariance and ensures that their dimensions match. */
    public MultivarGaussian(List params){
	if (params.size() != 2) {
		throw new IllegalArgumentException
		    ("Multivariate Gaussian distribution requires exactly 2 "
		     + "parameters, "
		     + "not " + params.size() + ".");
	    }

	if (!((params.get(0) instanceof Matrix) 
	      && (((Matrix)params.get(0)).getColumnDimension() == 1))){
	    throw new IllegalArgumentException 
		("The first parameter (mean) for multivariate "
		 + "Gaussian "
		 + "distribution must be a column Matrix ");
	}

	mu = (Matrix)params.get(0);
	num_dim = ((Matrix)params.get(0)).getRowDimension();

	if (!((params.get(1) instanceof Matrix)
	      && (((Matrix)params.get(1)).getColumnDimension() == num_dim)
	      && (((Matrix)params.get(1)).getColumnDimension() == 
		  ((Matrix)params.get(1)).getRowDimension()))){
	    throw new IllegalArgumentException 
		("The second parameter (covariance) for the multivariate "
		 + "Gaussian distribution with a " + num_dim 
		 + "-dimensional mean vector must be a " + num_dim
		 + "-by-" + num_dim + " Matrix");
	}

	sigma = (Matrix)params.get(1);

	for (int i = 0; i < sigma.getRowDimension(); i++){
	    for (int j = 0; j < sigma.getColumnDimension(); j++){
		if (sigma.get(i,j) != sigma.get(j,i))
		    throw new IllegalArgumentException
			("The covariance Matrix of a multivariate Gaussian"
			 + " must be symmetric.");
	    }
	}
        						   
    }


    /** 
     * Ensures that x = value is a column matrix of appropriate dimension d and
     * returns p = 1/sqrt((2*pi)^d*|sigma|)*exp{-0.5(x-mean)'*inverse(sigma)*
     * (x-mean)}.
     */ 
    public double getProb(List args, Object value){
	if (!((value instanceof Matrix) 
	     && (((Matrix)value).getRowDimension() == num_dim) 
	     && (((Matrix)value).getColumnDimension() == 1)))
	    throw new IllegalArgumentException
		("The value passed to the " + num_dim + "-dimensional "
		 + "multivariate Gaussian distribution's"
		 + " getProb "
		 + "method must be a " + num_dim + "column Matrix");

	return 1/Math.sqrt(Math.pow(2*Math.PI,num_dim)*sigma.det())
	    *Math.exp(-0.5*((Matrix)value).minus(mu).transpose().times(
		   sigma.inverse()).times(((Matrix)value).minus(mu)).get(0,0));
    }

    /**
     * Samples a value from this multivariate Gaussian by generating <i>num_dim
     * </i> independent samples from univariate Gaussians with unit variance, 
     * one for each mean in the mean vector, and multiplying the obtained 
     * vector on the left by the square root of sigma (Cholesky decomposition
     * of sigma).
     */
    public Object sampleVal(List args, Type childType){
	Matrix temp = new Matrix(num_dim, 1);
	UnivarGaussian tempGauss;
	ArrayList params;
	for (int i = 0; i < num_dim; i++){
	    params = new ArrayList();
	    params.add(new Double(0));
	    params.add(new Double(1));
	    tempGauss = new UnivarGaussian(params);
	    temp.set(i,0, ((Double)tempGauss.sampleVal(
			   new ArrayList(), new Type("Dummy"))).doubleValue());
	}
	return mu.plus(sigma.chol().getL().times(temp));
    }


    private int num_dim;
    private Matrix mu;
    private Matrix sigma;
}
