/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog.distrib;

import blog.*;
import Jama.*;
import java.util.*;
import common.Util;



/**
 * The uniform distribution over n-dimentsional vectors coming from a specified
 * n-dimensional "box".
 */

public class UniformVectorDistrib extends AbstractCondProbDistrib {

    /**
     * The constructor takes an even number of parameters. For all i, 
     * 0<=i<=(n-1)/2, the (2i)-th parameter is treated as the lower bound of 
     * the generated vectors' i-th component, and every (2i+1)-th argument --
     * as the i-th component upper bound. All parameters must be of type Number
     *
     * @throws IllegalArgumentException  
     */
    public UniformVectorDistrib( List params ){
	if ((params.size()%2) != 0) {
	    throw new IllegalArgumentException
		("Uniform vector distribution require an even number "
		 + "of parameters, current number of parameters: " 
		 + params.size() + ".");
	}

	for (int i = 0; i < params.size(); i++){
	    if(!(params.get(i) instanceof Number))
		throw new  IllegalArgumentException 
		    ("Parameter " + i + " to the uniform vector "
		     + "distribution is of type " + params.get(i).getClass()
		     + ", not Number as required.");
	    grid.add(params.get(i));
	}
    }


    /**
     * Returns the probability density corresponding to the given value vector
     * Since the distribution is uniform, returns 1.0 if the vector comes from
     * the specified bounding box, 0 otherwise."
     */
    public double getProb( List args, Object value ) {
	if (args.size() != 0) {
	    throw new IllegalArgumentException
		("Uniform vector distribution takes 0 arguments, "
		 + " not " + args.size() + ".");
	}

	if(!(value instanceof Vector)){
	    throw new IllegalArgumentException
		("The value passed to the uniform vector distribution's " 
		 + "getProb method must be of type Vector, not "
		 + value.getClass());
	}

	if(((Vector) value).size() != (grid.size()/2)){
	    throw new IllegalArgumentException
		("The vector passed to the uniform vector distribution's " 
		 + "getProb method must be " + grid.size()/2
		 + "-dimensional, not " + ((Vector)value).size()
		 + "-dimensional");
	}

	for (int i = 0; i < ((Vector) value).size(); i++){
	    if(!(((Vector)value).elementAt(i) instanceof Number))
		throw new IllegalArgumentException
		    ("Component " + i + " of the vector passed to"
		     + " the uniform vector distribution's getProb method "
		     + "is of type " + ((Vector)value).elementAt(i).getClass()
		     + ", not Number as required.");
	    if((((Number)grid.get(2*i)).doubleValue() > 
		((Number)((Vector)value).elementAt(i)).doubleValue())  || 
	       (((Number)grid.get(2*i+1)).doubleValue() < 
		((Number)((Vector)value).elementAt(i)).doubleValue()))
		return 0;
	}

	return 1.0;
    }


    public Object sampleVal( List args, Type childType ) {
	if (args.size() != 0) {
	    throw new IllegalArgumentException
		("Uniform vector distribution takes 0 arguments, "
		 + " not " + args.size() + ".");
	}

	Matrix sample = new Matrix(grid.size()/2, 1);
	for (int i = 0; i < grid.size(); i+=2)  
	    sample.set(i/2, 0, ((Number)grid.get(i)).doubleValue() +
				  Util.random() *
				  (((Number)grid.get(i+1)).doubleValue() -
				   ((Number)grid.get(i)).doubleValue()));

	return sample;
    }

    private ArrayList grid = new ArrayList();
}
