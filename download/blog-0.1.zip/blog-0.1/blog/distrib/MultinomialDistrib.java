/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog.distrib;

import blog.*;
import java.util.*;
import common.Util;

/**
 * A multinomial distribution over values from the given collection. 
 */ 
public class MultinomialDistrib extends AbstractCondProbDistrib {
    public MultinomialDistrib( List params ){
	if (params.size() != 1) {
	    throw new IllegalArgumentException
		("Multinomial distribution requires exactly one parameter, " 
		 + "not " + params.size() + ".");
	}
	Object param_obj = params.get(0);
	if (!(param_obj instanceof Collection)) {
	    throw new IllegalArgumentException
		("Parameter to Multinomial distrib must be of class "
		 + "Collection, " 
		 + "not " + param_obj.getClass() + ".");
	}
		
	elts = Arrays.asList(((Collection)param_obj).toArray());
    }


    /**
     * Returns 1/(size of the collection) if the passed value is in the
     * collection, 0 otherwise.
     */
    public double getProb( List args, Object value ) {
	if (args.size() != 0) {
	    throw new IllegalArgumentException
		("Multinomial distribution takes zero arguments, not "
		 + args.size() + ".");
	}

	if (elts.contains(value))
	    return 1/((double)elts.size());
	return 0;
    }


    /**
     * Samples an object uniformly form the collection.
     */
    public Object sampleVal( List args, Type childType ) {
	if (args.size() != 0) {
	    throw new IllegalArgumentException
		("Multinomial distribution takes zero arguments, not "
		 + args.size() + ".");
	}

	double sample = Util.random();

	for (int n = 0; n < elts.size(); n++){
	    if (sample < n/((double)elts.size()))
		return elts.get(n);
	}
	return null;
    }


    private List elts;
}
