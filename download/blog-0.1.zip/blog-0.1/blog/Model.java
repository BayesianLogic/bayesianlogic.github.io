/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import java.util.regex.*;
import java.io.PrintStream;
import common.Util;


/** This class contains all the information available about the structure of 
 * the model. In particular, it keeps lists of user-defined types and 
 * functions.  Attributes of those types and functions are stored in 
 * the individual Type and Function objects.  
 *
 * <p>Please note that the mutator methods contain little error-checking, 
 * if any.Since the type- and semantic checking of the model is done 
 * dynamically while the model file is being parsed, it is assumed that if an 
 * error occurs it is caught by the type/semantic checker.  
 */
public class Model {
    /**
     * The BLOG null value.  We use this object rather than the Java null
     * value so that we can always use <code>equals</code> to compare BLOG 
     * objects, and methods can return null as an error indicator without 
     * worrying about the possibility that a BLOG value might actually 
     * be null.
     */
    public static final Object NULL = new Object() {
	    public String toString() {
		return "null";
	    }
	};


    /**
     * Class constructor. 
     */ 
    public Model( ){
    }


    /** 
     * Creates a new user-defined type with the given name and adds it to 
     * this model.  
     */ 
    public void addType( String typeName ) {
	Type type = new Type(typeName);
	types.add(type);
	typesByName.put(typeName, type);
    }


    /** Checks whether the specified type has been defined. */
    public boolean existsType( String typeName ){
	return ( typesByName.containsKey( typeName ) ||
		 BuiltInTypes.exists(typeName));  
    }


    /** Returns the type information for the given type. */
    public Type getType( String typeName ){
	if ( typesByName.containsKey( typeName ) )
	    return ( Type ) typesByName.get( typeName );
	else
	    return  BuiltInTypes.getType( typeName );
    }


    /**
     * Returns the user-defined types in this model.
     *
     * @return unmodifiable Collection of Type
     */
    public Collection getTypes() {
	return Collections.unmodifiableCollection(types);
    }
    
    /**
     * Returns a Set consisting of the user-defined types named in the 
     * given string.  The string should be a comma-separated list of 
     * type names (spaces are optional).  The string can also be the 
     * special string "none", which yields an empty set, or "all", which 
     * yields the set of all user-defined types.
     *
     * <p>If some of the named types are undefined, this method prints an 
     * error message and returns null.
     */
    public Set getListedTypes(String typeList) {
	Set listedTypes = new HashSet();
	if (typeList.equals("none")) {
	    return listedTypes;
	} 

	if (typeList.equals("all")) {
	    listedTypes.addAll(types);
	    return listedTypes;
	}

	boolean correct = true;
	StringTokenizer st = new StringTokenizer(typeList, ", ", false);
	while (st.hasMoreTokens()) {
	    String typeName = st.nextToken();
	    Type type = getType(typeName);
	    if (type == null) {
		System.err.println("Undefined type: " + typeName);
		correct = false;
	    } else {
		listedTypes.add(type);
	    }
	}

	if (correct) {
	    return listedTypes;
	}
	return null;
    }

    /** Adds the given user-defined function to this model. 
     */
    public void addFunction(Function f) {
	functions.add(f);
	functionsByName.put(f.getName(), f);
    }


    /** Checks whether the function by the specified name has been defined.  
     */
    public boolean existsFunction( String fname ){
	return (functionsByName.containsKey( fname )
		|| BuiltInFunctions.exists(fname));
    }


    /** Retrieves the Function object  by the specified name. 
     */
    public Function getFunction( String fname ){
	Function f = (Function) functionsByName.get( fname );
	if (f == null) {
	    f = BuiltInFunctions.getFunction(fname);
	}
	return f;
    }


    /**
     * Returns the user-defined functions in this model.
     *
     * @return unmodifiable Collection of Function
     */
    public Collection getFunctions() {
	return Collections.unmodifiableCollection(functions);
    }


    /** Prints this model to the given stream. */
    public void print(PrintStream s) {
	// Print guaranteed objects
	for (Iterator iter = types.iterator(); iter.hasNext(); ) {
	    Type type = (Type) iter.next();
	    s.println("guaranteed objects of type " + type + ": "
		      + type.getGuaranteedObjects());
	}

	// Print nonrandom functions
	for (Iterator iter = functions.iterator(); iter.hasNext(); ) {
	    Function f = (Function) iter.next();
	    if (f instanceof NonRandomFunction) {
		((NonRandomFunction) f).print(s);
	    }
	}

	// Print number statements
	for (Iterator typeIter = types.iterator(); typeIter.hasNext(); ) {
	    Type type = (Type) typeIter.next();
	    for (Iterator popIter = type.getPOPs().iterator(); 
		 popIter.hasNext(); ) {
		((POP) popIter.next()).printNumberStatement(s);
	    }
	}

	// Print dependency statements
	for (Iterator iter = functions.iterator(); iter.hasNext(); ) {
	    Function f = (Function) iter.next();
	    if (f instanceof RandomFunction) {
		((RandomFunction) f).printDepStatement(s);
	    }
	}
    }


    /**
     * Check types and scopes in the model.  Returns true if no errors; 
     * otherwise prints error messages and returns false.  
     */
    public boolean semanticCheck() { 
	boolean correct = true;

	// Check dependency statements
	for (Iterator iter = functions.iterator(); iter.hasNext(); ) {
	    Function f = (Function) iter.next();
	    if (f instanceof RandomFunction) {
                RandomFunction rf = (RandomFunction) f;
		DependencyModel depModel = rf.getDepModel();
		if (depModel == null) {
		    System.err.println("No dependency statement found for "
				       + "random function " + rf);
		    correct = false;
		} else {
		    Map scope = new HashMap();
		    for (int i = 0; i < rf.getArgVars().size(); ++i) {
			scope.put(rf.getArgVars().get(i), 
				  rf.getArgTypes().get(i));
		    }

		    if (!depModel.checkTypesAndScope(scope, rf.getRetType())) {
			correct = false;
		    }
		}
	    }
	}

	// Check number statements
	for (Iterator typeInfoIter = types.iterator(); 
	     typeInfoIter.hasNext(); ) {
	    Type t = (Type) typeInfoIter.next();
	    Iterator popIter = t.getPOPs().iterator();
	    while (popIter.hasNext()) {
		POP pop = (POP) popIter.next();
		Map scope = new HashMap();
		for (int i = 0; i < pop.getGenObjVars().size(); ++i) {
		    scope.put(pop.getGenObjVars().get(i), 
			      pop.getArgTypes().get(i));
		}

		if (!pop.getDepModel().checkTypesAndScope
		    (scope, BuiltInTypes.NATURAL_NUM)) {
		    correct = false;
		}
	    }
	}

	return correct;
    }

    /**
     * Compares two objects that can serve as arguments to basic random 
     * variables.  First, non-guaranteed objects come after guaranteed 
     * objects.  Non-guaranteed objects have their own comparison method 
     * based on depths and generating objects.  Guaranteed objects are 
     * compared first by the order in which their types were defined, then 
     * based on order within their type.
     */
    public static int compareArgs(Object obj1, Object obj2) {
	// Non-guaranteed objects go last
	if (obj1 instanceof NonGuaranteedObject) {
	    if (obj2 instanceof NonGuaranteedObject) {
		return ((NonGuaranteedObject) obj1).compareTo(obj2);
	    }
	    return 1; // obj2 goes first
	} else if (obj2 instanceof NonGuaranteedObject) {
	    return -1; // obj1 goes first
	}

	// Integers go before objects of user-defined types
	if (obj1 instanceof Integer) {
	    if (obj2 instanceof Integer) {
		return ((Integer) obj1).compareTo((Integer) obj2);
	    }
	    return -1; // obj1 goes first
	} else if (obj2 instanceof Integer) {
	    return 1; // obj2 goes first
	}

	// User-defined guaranteed objects are compared by their types'
	// creation indices, then by their indices within the type
	if ((obj1 instanceof EnumeratedObject)
	    && (obj2 instanceof EnumeratedObject)) {
	    
	    int typeDiff 
		= ((EnumeratedObject) obj1).getType().getCreationIndex()
		- ((EnumeratedObject) obj2).getType().getCreationIndex();
	    if (typeDiff != 0) {
		return typeDiff;
	    }
	    return ((EnumeratedObject) obj1).compareTo(obj2);
	}

	return 0; // unrecognized object types
    }

    /**
     * Returns a number that is negative, positive, or zero according to 
     * whether <code>objs1</code> comes before, after, or at the same place as 
     * <code>objs2</code> in a lexicographic ordering.
     *
     * @param objs1 a List of BLOG objects that can serve as arguments
     * @param objs2 a List of BLOG objects that can serve as arguments
     */
    public static int compareArgLists(List objs1, List objs2) {
	for (int i = 0; i < objs1.size(); ++i) {
	    if (i >= objs2.size()) {
		return 1; // objs2 is proper prefix of objs1, so it goes first
	    }
	    
	    int objDiff = compareArgs(objs1.get(i), objs2.get(i));
	    if (objDiff != 0) {
		return objDiff;
	    }
	}

	// If we get here, then objs1 is a prefix of objs2
	if (objs2.size() > objs1.size()) {
	    return -1; // objs1 is proper prefix of objs2
	}
	return 0;
    }

    /**
     * Stores user-defined Type objects in the order they were declared.
     */
    private List types = new ArrayList(); // of Type

    /**
     * Maps type names to Type objects.  For user-defined types.  
     */
    private Map typesByName = new HashMap(); // from String to Type

    /**
     * Stores user-defined Function objects in the order they were declared.
     */
    private List functions = new ArrayList(); // of Function

    /**
     * Maps function names to Function objects.  For user-defined functions
     */
    private Map functionsByName = new HashMap(); // from String to Function
}

