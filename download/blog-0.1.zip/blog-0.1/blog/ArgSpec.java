/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;


/** Represents an abstract argument specification. In general, an argument 
 * can be:
 * <UL>
 *     <LI> a Term;
 *     <LI> an explicitly specified set of terms;
 *     <LI> an implicitly specified set of terms;
 *     <LI> an implicitly specified set of tuples of terms;
 * </UL>
 * Functions are only allowed to take Terms as arguments, whereas CPDs are 
 * are allowed to take all argument types.
 */
public abstract class ArgSpec extends WrappedClass {
    /**
     * Returns a List consisting of the objects obtained by evaluating 
     * each element of <code>argSpecs</code> in the given world under 
     * the given assignment.
     */
    public static List evaluate(PartialWorld w, Assignment a, List argSpecs) {
	List results = new ArrayList();
	for (Iterator iter = argSpecs.iterator(); iter.hasNext(); ) {
	    results.add(((ArgSpec) iter.next()).evaluate(w, a));
	}
	return results;
    }

    /**
     * Returns the value of this argument specification in the given world, 
     * under the given assignment of objects to logical variables.
     *
     * @throws IllegalStateException if the given world is not complete 
     *                               enough to evaluate this ArgSpec
     */
    public Object evaluate(PartialWorld w, Assignment a) {
	ParentsAndValue info 
	    = getParentsAndValue(w, a, ValueChooser.NO_INSTANTIATION);
	return info.getValue();
    }

    /**
     * Returns true if the given partial world is complete enough to 
     * determine the value of this ArgSpec under the given variable 
     * assignment.
     */
    public boolean isDetermined(PartialWorld w, Assignment a) {
	return (getParentsAndValue(w, a, null) != null);
    }

    /**
     * Returns the active parents and value of this ArgSpec in the 
     * given partial world.  If the world is not complete enough to 
     * evaluate this ArgSpec, uses the given ValueChooser object to 
     * instantiate the necessary basic variables.  If the world is not 
     * complete enough and the ValueChooser is null, this method 
     * returns null.
     */
    public abstract ParentsAndValue getParentsAndValue(PartialWorld w, 
						       Assignment a, 
						       ValueChooser chooser);

    /**
     * Returns the (basic or derived) random variable that this argument 
     * specification corresponds to under the given assignment.  The 
     * default implementation just returns a DerivedVar with this 
     * ArgSpec.  However, some argument specifications (such as 
     * function application terms and atomic formulas) may correspond to 
     * BasicVars.  
     */
    public BayesNetVar getVariable(Assignment a) {
	return new DerivedVar(this, a);
    }

    /**
     * Returns true if, within the given scope, all the variables used
     * in this ArgSpec are in scope and all type constraints are
     * satisfied.  If there is a type or scope error, calls the
     * WrappedClass.typeError method with an appropriate message.
     *
     * @param scope a Map from Strings (variable names) to Types
     */
    public abstract boolean checkTypesAndScope(Map scope);

    /**
     * Returns true if the value of this ArgSpec is always an instance 
     * of Number (regardless of scope).  The default implementation 
     * returns false.
     */
    public boolean isNumeric() {
	return false;
    }
} 
