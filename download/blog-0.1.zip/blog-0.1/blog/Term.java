/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;


/** Represents a Bayesian atom. All specific kinds of terms are expected to
 * implement this interface.
 */
public abstract class Term extends ArgSpec {


    /** Calculates the value of the term with respect to the given
     * {@link blog.PartialWorld} and {@link blog.Assignment}
     */
    public Object getDenotation(PartialWorld w, Assignment a) {
	return evaluate(w, a);
    }

    /** Calculates the value of a list of terms with respect to the
     * given {@link blog.PartialWorld} and {@link blog.Assignment}
     */ 
    public static List getDenotations(PartialWorld world, Assignment assign, 
				      List terms) {

	List toReturn = new ArrayList( );
	Iterator termIter = terms.iterator();
	Term curr;
	while(termIter.hasNext()) {

	    curr = (Term) termIter.next();
	    toReturn.add(curr.getDenotation(world, assign));
	}

	return toReturn;
    }

    /**
     * Returns the non-random value of this term if it is non-random; 
     * otherwise returns null.  Note that since the BLOG value "null" 
     * is represented by Model.NULL rather than the Java null value, 
     * this method will never return null as the non-random value.  
     *
     * @param a the Assignment to use for evaluating variables in this term
     */
    public abstract Object getValueIfNonRandom(Assignment a);

    /**
     * Returns a new Term that is the same as this one, except that any 
     * nested variables have been renamed according to the given map.
     *
     * @param renaming a Map from String to String where the keys are old 
     *                 variable names and the values are new variable names
     */
    public abstract Term getFormWithVarsRenamed(Map renaming);

    /**
     * Returns the set of variables that occur in this term.
     *
     * @return unmodifiable Set of String objects
     */
    public abstract Set getVariables();

    /**
     * Returns true if the given term occurs in this term (or if the given 
     * term is equal to this term).  
     */
    public abstract boolean containsTerm(Term target);

    /**
     * Returns the set of generating functions that are applied to the
     * term <code>subject</code> by this term or any of its subterms.
     */
    public abstract Set getGenFuncsApplied(Term subject); 

    /**
     * Returns the type of this term in the given scope, or null if
     * this term is a variable that is not in scope.
     *
     * @param scope a Map from Strings (variable names) to Types
     */
    public abstract Type getType(Map scope);

    /**
     * Returns true if this term is the constant term that always denotes 
     * Model.NULL.  The default implementation returns false.  
     */
    public boolean isConstantNull() {
	return false;
    }
}
