/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;


/** Represents a function invocation.
 *
 * @see blog.Term
 */
public class FuncAppTerm extends Term {
    /**
     * Creates a new function application term with the given function and 
     * an empty argument list.
     *
     * @param f        a Function
     */
    public FuncAppTerm(Function f){
    
	this.f = f;
	this.arg_lst = Collections.EMPTY_LIST;

    }

    /**
     * Creates a new function application term with the given function and 
     * argument list.
     *
     * @param f        a Function
     * @param arg_lst  a List of Term objects representing arguments
     */
    public FuncAppTerm( Function f, List arg_lst ){
    
	this.f = f;
	this.arg_lst = arg_lst;

    }


    /**
     * Returns the function in this function application term.
     */
    public Function getFunction() {
	return f;
    }

    /**
     * Returns the arguments in this function application term.
     *
     * @return a List of Term objects
     */
    public List getArgs() {
	return arg_lst;
    }

    /**
     * Returns the non-random value of this term if it is non-random; 
     * otherwise returns null.  
     *
     * @param a the Assignment to use for evaluating variables in this term
     */
    public Object getValueIfNonRandom(Assignment a) {
	if (f instanceof NonRandomFunction) {
	    List argValues = getArgValuesIfNonRandom(a);
	    if (argValues != null) {
		return ((NonRandomFunction) f).getValue(argValues);
	    }
	}
	return null;
    }

    /**
     * Returns the non-random values of the arguments in this function 
     * application term if they are non-random.  Otherwise returns null.
     *
     * @param a the Assignment to use for evaluating variables in the arguments
     * @return  a List of arbitrary Objects
     */
    public List getArgValuesIfNonRandom(Assignment a) {
	List argValues = new ArrayList();
	for (Iterator iter = arg_lst.iterator(); iter.hasNext(); ) {
	    Object value = ((Term) iter.next()).getValueIfNonRandom(a);
	    if (value == null) {
		return null;
	    }
	    argValues.add(value);
	}
	return argValues;
    }

    /**
     * Returns the active parents and value of this term in the 
     * given partial world.  If the world is not complete enough to 
     * evaluate this term, uses the given ValueChooser object to 
     * instantiate the necessary basic variables.  If the world is 
     * not complete enough and the ValueChooser is null, this method 
     * returns null. 
     */
    public ParentsAndValue getParentsAndValue(PartialWorld w, 
					      Assignment a, 
					      ValueChooser chooser) {
	Set parentSet = new HashSet();
	List argValues = new ArrayList();
	
	for (Iterator iter = arg_lst.iterator(); iter.hasNext(); ) {
	    Term term = (Term) iter.next();
	    ParentsAndValue termInfo = term.getParentsAndValue(w, a, chooser);
	    if (termInfo == null) {
		return null;
	    }
	    parentSet.addAll(termInfo.getParents());
	    argValues.add(termInfo.getValue());

	    if (termInfo.getValue() == Model.NULL) {
		// short-circuit, don't evaluate other args
		Object value = Model.NULL;
		return new ParentsAndValue(parentSet, value);
	    }
	}

	Object value = f.getValueInWorld(argValues, w, chooser, parentSet);
	if (value == null) {
	    return null;
	}
	return new ParentsAndValue(parentSet, value);
    }
	
    /**
     * Returns the (basic or derived) random variable that this function
     * application term corresponds to under the given assignment.  If 
     * all the arguments in this function application are non-random and 
     * the function itself is random, then this is a BasicVar (specifically, 
     * a RandFuncAppVar).  Otherwise, it's a DerivedVar.  
     */
    public BayesNetVar getVariable(Assignment a) {
	if (f instanceof RandomFunction) {
	    List argValues = getArgValuesIfNonRandom(a);
	    if (argValues != null) {
		return new RandFuncAppVar((RandomFunction) f, argValues);
	    }
	}
	return new DerivedVar(this, a);
    }

    /**
     * Returns a new Term that is the same as this one, except that any 
     * nested variables have been renamed according to the given map.
     *
     * @param renaming a Map from String to String where the keys are old 
     *                 variable names and the values are new variable names
     */
    public Term getFormWithVarsRenamed(Map renaming) {
	List newArgs = new ArrayList();
	for (Iterator iter = arg_lst.iterator(); iter.hasNext(); ) {
	    newArgs.add(((Term) iter.next()).getFormWithVarsRenamed(renaming));
	}
	return new FuncAppTerm(f, newArgs);
    }

    public Set getVariables() {
	Set vars = new HashSet();
	for (Iterator iter = arg_lst.iterator(); iter.hasNext(); ) {
	    vars.addAll(((Term) iter.next()).getVariables());
	}
	return Collections.unmodifiableSet(vars);
    }

    public boolean containsTerm(Term target) {
	if (equals(target)) {
	    return true;
	}

	for (Iterator iter = arg_lst.iterator(); iter.hasNext(); ) {
	    if (((Term) iter.next()).containsTerm(target)) {
		return true;
	    }
	}

	return false;
    }

    public Set getGenFuncsApplied(Term subject) {
	Set genFuncsApplied = new HashSet();

	for (Iterator iter = arg_lst.iterator(); iter.hasNext(); ) {
	    Term arg = (Term) iter.next();
	    if (arg.equals(subject)
		&& (f instanceof GeneratingFunction)) {
		genFuncsApplied.add(f);
	    } else {
		genFuncsApplied.addAll(arg.getGenFuncsApplied(subject));
	    }
	}

	return Collections.unmodifiableSet(genFuncsApplied);
    }

    /**
     * Two function application terms are equal if all their arguments 
     * are equal and their functions are equal.
     */
    public boolean equals(Object o) {
	if (o instanceof FuncAppTerm) {
	    FuncAppTerm other = (FuncAppTerm) o;
	    return (f.equals(other.getFunction())
		    && arg_lst.equals(other.getArgs()));
	}
	return false;
    }

    public int hashCode() {
	return (f.hashCode() ^ arg_lst.hashCode());
    }

    /**
     * If this function application terms involves a non-zero number of
     * arguments, returns a string of the form f(t1, ..., tK) where f
     * is the string representation of the function and t1, ..., tK are
     * string representations of the argument terms.  If this function
     * application term involves zero arguments, just returns the
     * string representation of the function.
     */
    public String toString() {
	if (arg_lst.isEmpty()) {
	    return f.toString();
	}
		
	StringBuffer buf = new StringBuffer();
	buf.append(f);
	buf.append("(");
	buf.append(arg_lst.get(0));
	for (int i = 1; i < arg_lst.size(); ++i) {
	    buf.append(", ");
	    buf.append(arg_lst.get(i));
	}
	buf.append(")");
	return buf.toString();
    }

    /**
     * Type checks this function application.  
     */
    public boolean checkTypesAndScope(Map scope) {
	if ((arg_lst == null) && (f.getArgTypes() == null)) {
	    return true;
	} else if ((arg_lst == null) || (f.getArgTypes() == null)) {
	    typeError("Invalid number of arguments to " + f.getName());
	    return false;
	} else {
	    List expectedArgTypes = f.getArgTypes();
	    if (arg_lst.size() != expectedArgTypes.size()) {
		typeError("Invalid number of arguments to " +
				   f.getName());
		return false;
	    }

	    for (int i = 0 ; i < arg_lst.size() ; i++) {
		Term arg = (Term) arg_lst.get(i);
		if (!arg.checkTypesAndScope(scope)) {
		    return false;
		}

		Type typePassed = arg.getType(scope);
		if (!typePassed.isSubtypeOf((Type) expectedArgTypes.get(i))) {
		    typeError("Wrong type passed to " + f.getName() 
			      + ": " + typePassed + ".  Type "
			      + expectedArgTypes.get(i) + " expected.");
		    return false;
		}
	    }

	    return true;
	}
    }

    public Type getType(Map scope) {
	return f.getRetType();
    }

    public boolean isConstantNull() {
	return (f == BuiltInFunctions.NULL);
    }

    public boolean isNumeric() {
	return f.getRetType().isSubtypeOf(BuiltInTypes.REAL);
    }

    private  Function f;
    private  List arg_lst; // of Term

}




