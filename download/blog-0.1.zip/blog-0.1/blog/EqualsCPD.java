/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;


/** EqualsCPD class is a convenience hack to represent the situation when 
 * the value of the right-hand side of a {@link Clause} depends on a function 
 * application rather than on a CPD.
 */
public class EqualsCPD extends AbstractCondProbDistrib {

   
    /** Returns 1  if the only element of the <code> args </code> ArrayList
     * equals the <code> value </code>. This method is intended to be called
     * only while calculating the probability of a function
     * interpretation. When called in such circumstances it should return 1
     * unless there is an error.
     */
    public double getProb( List args, Object value ) {

	if( args.size( ) == 1 ) 
	    return ( args.get( 0 ).equals( value ) ? 1 : 0 ) ;
	else {
 	    System.out.println("Error: EqualsCPD takes only 1 argument");
	    return 0;  
	}

    }


    /** Returns the first element of the argument list. 
     *
     * @param args   a List assumed to be of length 1 (the remaining 
     *               entries are ignored). It contains the value obtained 
     *               previously by applying {@link blog.Term#getDenotation(
     *               PartialWorld, Assignment)}, where the Term instance is 
     *               the only element of the {@link blog.Clause#cpdArgs}.
     *
     * @param childType   ignored
     */
    public Object sampleVal( List args, Type childType ){

	return args.get( 0 );

    }
    
}
