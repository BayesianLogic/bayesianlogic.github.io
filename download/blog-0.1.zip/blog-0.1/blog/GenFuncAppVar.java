/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

/**
 * A function application variable where the function is a generating 
 * function.  For any specific BLOG object, the identity of the object 
 * determines the values of generating functions on it.  However, for 
 * an ObjectIdentifier, the values of generating functions need to be 
 * specified separately.  Thus, only ObjectIdentifiers make sense as 
 * arguments for GenFuncAppVar objects.  
 */
public class GenFuncAppVar implements BayesNetVar {
    /**
     * Creates a new GenFuncAppVar for the application of the given 
     * generating function to the given ObjectIdentifier.
     */
    public GenFuncAppVar(GeneratingFunction func, ObjectIdentifier arg) {
	this.f = func;
	this.arg = arg;
    }

    /**
     * Returns the generating function involved in this variable.
     */
    public GeneratingFunction func() {
	return f;
    }

    /**
     * Returns the identifier to which the generating function is applied.
     */
    public ObjectIdentifier arg() {
	return arg;
    }

    /**
     * Returns true if this variable is instantiated in the given world.
     */
    public boolean isDetermined(PartialWorld w) {
	return w.isInstantiated(this);
    }

    /**
     * Returns 1, because generating function values are not included in the 
     * expression for the probability of the world.
     */
    public double getProbOfValue(PartialWorld w) {
	return 1.0;
    }

    /**
     * For now, just handle arguments of class NonGuaranteedObject, for 
     * which we can ignore w.
     */
    public Object getValue(PartialWorld w) {
	return f.getValueInWorld(Collections.singletonList(arg), w, 
				 ValueChooser.NO_INSTANTIATION, null);
    }

    public ParentsAndValue ensureInstAndSupported(PartialWorld w, 
						  ValueChooser chooser) {
	// TODO: handle case where this variable is not instantiated.
	return new ParentsAndValue(Collections.EMPTY_SET, getValue(w));
    }

    /**
     * Two GenFuncAppVar objects are equal if they have the same function
     * and the same argument.
     */
    public boolean equals(Object o) {
	if (o instanceof GenFuncAppVar) {
	    GenFuncAppVar other = (GenFuncAppVar) o;
	    if (f.equals(other.func()) && arg.equals(other.arg())) {
		return true;
	    }
	}
	return false;
    }

    public int hashCode() {
	return (f.hashCode() ^ arg.hashCode());
    }

    public String toString() {
	return (f.toString() + "(" + arg.toString() + ")");
    }

    GeneratingFunction f;
    ObjectIdentifier arg;
}
