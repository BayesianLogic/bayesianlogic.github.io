/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import common.Util;

/** Represents a statement that a certain term has a certain value. 
 * Such a statement is of the form <i>term</i> = <i>value</i>.
 * Currently the values are restricted to be zero-ary functions, so 
 * we don't have to worry about evaluating arguments on the righthand side.
 */
public class ValueEvidenceStatement {

    /**
     * Creates a ValueEvidenceStatement of the form:
     * <code>leftSide</code> = <code>output</code>.
     *
     * @param leftSide    the term whose value is being specified.  
     *                    Currently, function evidence statements cannot 
     *                    contain any free variables, so this must in fact 
     *                    be a FuncAppTerm
     *
     * @param output      a zero-ary function denoting the value
     */
    public ValueEvidenceStatement(Term leftSide, Function output) {

	this.funcAppTerm = (FuncAppTerm) leftSide;
	this.output =  output;

	if (output instanceof NonRandomFunction) {
	    // This statement is saying that a particular variable is equal to 
	    // the denotation of this nonrandom constant.
	    initObservedVar();
	    observedValue = ((NonRandomFunction) output).getValue
		(Collections.EMPTY_LIST);
	} else { 
	    // We need to let the observed variable be an equality 
	    // sentence, and the observed value be TRUE.
	    Term outputTerm = new FuncAppTerm(output, 
						 Collections.EMPTY_LIST);
	    Formula eq = new EqualityFormula(funcAppTerm, outputTerm);
	    observedVar = new DerivedVar(eq);
	    observedValue = Boolean.TRUE;
	}
    }

    private void initObservedVar() {
	List argValues = funcAppTerm.getArgValuesIfNonRandom
	    (new Assignment());
	if (argValues != null) { // arguments are non-random
	    Function f = funcAppTerm.getFunction();
	    if (f instanceof NonRandomFunction) {
		Object nonRandomValue 
		    = ((NonRandomFunction) f).getValue(argValues);
		if (nonRandomValue.equals(observedValue)) {
		    System.out.println("Note: evidence \""
				       + this + "\" is vacuous because "
				       + "both sides are non-random.");
		    observedVar = new DerivedVar(funcAppTerm);
		} else {
		    Util.fatalError("Error: evidence asserts "
				    + funcAppTerm + " has value "
				    + output + ", but it has the "
				    + "non-random value "
				    + nonRandomValue + ".", true, true);
		}
	    } else {
		// We can assert that a certain basic variable is equal 
		// to the output value.
		observedVar = new RandFuncAppVar((RandomFunction) f, argValues);
	    }
	} else { // arguments are random
	    // Need to create a derived variable
	    observedVar = new DerivedVar(funcAppTerm);
	}
    }

    public BayesNetVar getObservedVar() {
	return observedVar;
    }

    public Object getObservedValue() {
	return observedValue;
    }

    /**
     * Returns true if the given partial world is complete enough to 
     * determine whether this evidence statement is true or not.
     */
    public boolean isDetermined(PartialWorld w) {
	return observedVar.isDetermined(w);
    }

    /**
     * Returns true if, in this function evidence statement, the function 
     * application term and the output constant symbol have the same 
     * denotation in the given world.
     */
    public boolean isTrue(PartialWorld w) {
	return (observedVar.getValue(w).equals(observedValue));
    }

    public String toString() {
	return (funcAppTerm + " = " + output);
    }

    private FuncAppTerm funcAppTerm;
    private Function output;
		
    private BayesNetVar observedVar;
    private Object observedValue;

}
