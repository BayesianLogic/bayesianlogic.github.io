/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

/**
 * Data structure that facilitates iterating over the set of objects 
 * <i>x</i> such that a given formula <i>phi(x)</i> is true.  A 
 * CompiledSetSpec consists of a DNF version of <i>phi</i>, with an 
 * ObjGenGraph for each disjunct.  To iterate over the objects that 
 * satisfy <i>phi</i>, we create an iterator for each ObjGenGraph and 
 * get objects from these iterators in a round-robin fashion.  When we get 
 * an object from an ObjGenGraph, we return it if it satisfies the 
 * corresponding disjunct and no earlier disjuncts.  Thus, each object 
 * that satisfies <i>phi</i> is returned exactly once: when it is returned 
 * by the iterator for the <em>first</em> disjunct that it satisfies.  
 * The round-robin iteration over disjuncts ensures that even if the 
 * ObjGenGraph iterator for, say, the first disjunct returns infinitely 
 * many objects, we will still return objects that satisfy the other 
 * disjuncts after a finite amount of time.  
 */
public class CompiledSetSpec {
    /**
     * Creates a new CompiledSetSpec for iterating over all objects 
     * <code>var</code> of type <code>type</code> that satisfy 
     * <code>phi</code>.
     */
    public CompiledSetSpec(Type type, String var, Formula phi) {
	this.type = type;
	this.var = var;
	
	disjuncts = phi.getPropDNF().getDisjuncts();
	objGenGraphs = new ObjGenGraph[disjuncts.size()];
	for (int i = 0; i < disjuncts.size(); ++i) {
	    ConjFormula disjunct = (ConjFormula) disjuncts.get(i);
	    objGenGraphs[i] = new ObjGenGraph(type, var, 
					      disjunct.getConjuncts());
	}
    }

    /**
     * Returns a PartEnumSet representing the objects that, when bound 
     * to <code>var</code>, make <code>phi</code> true in the given 
     * partial world.  Adds to <code>parents</code> all the Bayes net 
     * variables that it looks at to determine this set.  If the given 
     * partial world is not complete enough to determine the element set, 
     * uses <code>chooser</code> to instantiate more variables.  If the 
     * world is not complete enough and <code>chooser</code> is null,
     * this method returns null.  
     *
     * <p>This method goes into an infinite loop if the set in question 
     * is infinite.  Thus, for cases where it may be possible to avoid 
     * determining all the elements of the set (e.g., in evaluating quantified 
     * formulas), one should use the <code>iterator</code> method instead.
     */
    public PartEnumSet elementSet(PartialWorld w, Assignment a, 
				  ValueChooser chooser, Set parents) {
	PartEnumSet s = new PartEnumSet(w);

	ObjectIterator iter = iterator(w, a, chooser);
	while (iter.hasNext()) {
	    Object obj = iter.next();
	    if (obj instanceof IdentifierHook) {
		IdentifierHook hook = (IdentifierHook) obj;
		if (hook.hasIdentifier()) {
		    s.add(hook.getIdentifier());
		} else {
		    s.addSubset(new RemainingObjSet
				(hook.getPOP(), 
				 hook.getGeneratingObjects(), w));
		}
	    } else {
		s.add(obj);
	    }
	}
	if (!iter.canComputeNext()) {
	    return null;
	}

	parents.addAll(iter.getParents());
	return s;
    }

    /**
     * Returns an iterator over objects that, when bound to <code>var</code>, 
     * make <code>phi</code> true in the given partial world.
     */
    public ObjectIterator iterator(PartialWorld w, Assignment a, 
				   ValueChooser chooser) {
	return new CompiledSetSpec.Iterator(w, a, chooser);
    }

    private class Iterator implements ObjectIterator {
	Iterator(PartialWorld w, Assignment a, ValueChooser chooser) {
	    this.w = w;
	    this.b = new Assignment(a);
	    this.chooser = chooser;

	    graphIterators = new ObjectIterator[objGenGraphs.length];
	    for (int i = 0; i < objGenGraphs.length; ++i) {
		graphIterators[i] = objGenGraphs[i].iterator(w, a, chooser);
		active.set(i);
	    }

	    loadNext();
	}

	public boolean hasNext() {
	    return (b != null);
	}

	public Object next() {
	    if (b == null) {
		throw new NoSuchElementException();
	    }
	    
	    Object toReturn = b.getVal(var);
	    loadNext();
	    return toReturn;
	}

	public void remove() {
	    throw new UnsupportedOperationException
		("Can't remove from CompiledSetSpec iterator.");
	}

	public Set getParents() {
	    Set parents = new HashSet(disjunctParents);
	    for (int i = 0; i < graphIterators.length; ++i) {
		parents.addAll(graphIterators[i].getParents());
	    }
	    return parents;
	}
	
	public boolean canComputeNext() {
	    return canComputeNext;
	}

	private void loadNext() {
	    while (active.cardinality() > 0) {
		int curIndex = nextDisjunctIndex;
		nextDisjunctIndex 
		    = (nextDisjunctIndex + 1) % graphIterators.length;

		if (!graphIterators[curIndex].canComputeNext()) {
		    canComputeNext = false;
		    break; // b will be set to null
		}

		if (graphIterators[curIndex].hasNext()) {
		    Object obj = graphIterators[curIndex].next();
		    b.add(var, obj);

		    Boolean isFirst = isFirstSatisfiedDisjunct(curIndex);
		    if (isFirst == null) {
			canComputeNext = false;
			break; // b will be set to null
		    }
		    if (isFirst.booleanValue()) {
			return;
		    }
		} else {
		    active.clear(curIndex);
		}
	    }

	    b = null;
	}

	private Boolean isFirstSatisfiedDisjunct(int index) {
	    ParentsAndValue info = ((Formula) disjuncts.get(index))
		.getParentsAndValue(w, b, chooser);
	    if (info == null) {
		return null;
	    }
	    disjunctParents.addAll(info.getParents());
	    if (!((Boolean) info.getValue()).booleanValue()) {
		return Boolean.FALSE;
	    }

	    for (int i = 0; i < index; ++i) {
		info = ((Formula) disjuncts.get(i))
		    .getParentsAndValue(w, b, chooser);
		if (info == null) {
		    return null;
		}
		disjunctParents.addAll(info.getParents());
		if (((Boolean) info.getValue()).booleanValue()) {
		    return Boolean.FALSE;
		}
	    }

	    return Boolean.TRUE;
	}

	PartialWorld w;
	Assignment b;
	ValueChooser chooser;

	ObjectIterator[] graphIterators;
	BitSet active = new BitSet(); 
	int nextDisjunctIndex = 0;

	Set disjunctParents = new HashSet();
	boolean canComputeNext = true;
    }

    Type type;
    String var;

    List disjuncts; // of ConjFormula
    ObjGenGraph[] objGenGraphs;
} 
