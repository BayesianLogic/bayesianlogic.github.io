/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

import common.Util;

/**
 * A basic random variable in a BLOG model.  There are two kinds of basic 
 * random variables: function application variables and number variables.  
 * These are represented by subclasses of the abstract class BasicVar.  
 *
 * The set of basic variables is defined implicitly by a BLOG model.
 * BasicVar objects are just a convenience for bundling together a
 * function and a tuple of arguments, or a POP and a tuple of
 * generating objects.
 */
public abstract class BasicVar implements BayesNetVar , Comparable {
    /**
     * Creates a new BasicVar with the given tuple of arguments or 
     * generating objects.
     */
    protected BasicVar(List args, List argTypes) {
	this.args = Collections.unmodifiableList(args);
	this.argTypes = Collections.unmodifiableList(argTypes);
    }

    /**
     * Returns the tuple of arguments if this is a function application
     * variable, or the tuple of generating objects if this is a
     * number variable.  The returned list is not modifiable.  
     */
    public List args() {
	return args;
    }

    /**
     * Returns the type of object that can be a value for this variable.
     */
    public abstract Type getType();

    /**
     * A basic random variable is determined if and only if it is 
     * instantiated.
     */
    public boolean isDetermined(PartialWorld w) {
	return w.isInstantiated(this);
    }

    /**
     * Returns the conditional probability that this variable takes on 
     * the value that it has in the given world, according to this 
     * variable's dependency model.  If this variable is not instantiated 
     * in the given world, returns 1 (because then this variable does not 
     * contribute to the joint probability).
     */
    public double getProbOfValue(PartialWorld w) {
	if (!w.isInstantiated(this)) {
	    return 1;
	}
	if (!w.areValidObjects(args())) {
	    if (w.getValue(this) == Model.NULL) {
		return 1;
	    }
	    return 0;
	}

	ParentsAndValue info 
	    = getParentsAndCPD(w, ValueChooser.NO_INSTANTIATION);
	List cpdAndArgs = (List) info.getValue();
	CondProbDistrib cpd = (CondProbDistrib) cpdAndArgs.get(0);
	List cpdArgs = cpdAndArgs.subList(1, cpdAndArgs.size());
	
	Object value = w.getValue(this);
	return Math.exp(cpd.getLogProb(cpdArgs, value));
    }

    /**
     * Returns the value of this basic variable in the given world.  
     */
    public Object getValue(PartialWorld w) {
	return w.getValue(this);
    }

    /**
     * Ensures that the given random variable is instantiated and
     * supported (that is, all its active ancestors are
     * instantiated) in the given world.  If new values are needed for 
     * variables, they are obtained by calling the <code>chooseValue</code> 
     * method on the given <code>ValueChooser</code> object.
     *
     * @return a ParentsAndValue object containing the active parent set 
     *         and (possibly new) value of this variable
     */
    public ParentsAndValue ensureInstAndSupported(PartialWorld w, 
						  ValueChooser chooser) {
	Set parentSet = new HashSet();
	for (Iterator iter = args.iterator(); iter.hasNext(); ) {
	    Object arg = iter.next();
	    if (arg instanceof NonGuaranteedObject) {
		parentSet.add(((NonGuaranteedObject) arg).getNumberVar());

		// Don't need to instantiate number variable because if 
		// we've decided to instantiate this BasicVar, we must 
		// already have instantiated the governing number variables.
	    }
	}

	ParentsAndValue info = getParentsAndCPD(w, chooser);
	parentSet.addAll(info.getParents());

	Object value;
	if (w.isInstantiated(this)) {
	    value = w.getValue(this);
	} else if (chooser != null) {
	    List cpdAndArgs = (List) info.getValue();
	    CondProbDistrib cpd = (CondProbDistrib) cpdAndArgs.get(0);
	    List cpdArgs = cpdAndArgs.subList(1, cpdAndArgs.size());
	    value = chooser.chooseValue(w, this, cpd, cpdArgs);
	    ((MutablePartialWorld) w).setValue(this, value);
	} else {
	    Util.fatalError("Basic var " + this + " needs to be instantiated "
			    + "and no ValueChooser was specified.", true,true);
	    value = null;
	}

	return new ParentsAndValue(parentSet, value);
    }
	
    /**
     * Computes the parent variables, applicable CPD, and CPD argument 
     * values for this variable in the given world.  This requires that 
     * this variable be <i>supported</i> in the given world.  If the 
     * variable is not supported but the <code>chooser</code> argument 
     * is non-null, then this method uses the given ValueChooser to 
     * ensure that this variable is supported.  If the variable is not 
     * supported and <code>chooser</code> is null, then this method 
     * returns null.  
     *
     * @return a ParentsAndValue object where the parents are the parents 
     *          of this basic variable, and the value is a List whose 
     *          first element is the applicable CPD, and whose remaining 
     *          elements are the CPD arguments.
     */
    public ParentsAndValue getParentsAndCPD(PartialWorld w, 
					    ValueChooser chooser) {
	Assignment a = new Assignment();
	a.addTupleBinding(getArgVars(), args);
	return getDepModel().getParentsAndCPD(w, a, chooser);
    }

    /**
     * Returns the dependency model for this basic random variable.
     */
    public abstract DependencyModel getDepModel();

    /**
     * Returns the variables that stand for the arguments in this basic 
     * variable's dependency model.
     *
     * @return a List of String objects representing the variables
     */
    public abstract List getArgVars();

    /**
     * Compares this BasicVar to another one.  The ordering is intended 
     * to be used for printing basic variables.  First, basic variables 
     * are compared based on the order in which their dependency models 
     * were created; this corresponds to the order of definition in the 
     * model file.  For basic variables with the same dependency model, 
     * we use a lexicographic ordering based on the arguments.  
     */
    public int compareTo(Object o) {
	BasicVar other = (BasicVar) o;
	int indexDiff = getDepModel().getCreationIndex() 
	    - other.getDepModel().getCreationIndex();
	if (indexDiff != 0) {
	    return indexDiff;
	}

	return Model.compareArgLists(args, other.args());
    }

    private List args; // of Object
    private List argTypes; // of Type
}
