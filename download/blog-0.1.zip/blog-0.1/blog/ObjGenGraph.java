/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import common.Util;
import common.DGraph;
import common.AbstractDGraph;
import common.TupleIterator;

/**
 * An object generation graph contains nodes that represent sets of
 * objects with certain generation histories.  A node in an object
 * generation graph is like a formula with a free variable: given a
 * particular world and a particular assignment of values to other
 * variables, we can say whether any given object <em>satisfies</em>
 * the node.  An object <i>o</i> satisfies a node <i>v</i> given 
 * a world <i>w</i> and a variable assignment <i>a</i> if:
 * <ul> 
 * <li> <i>v</i> is a <code>POPNode</code> for a POP <i>(tau, g1, ..., gk)</i> 
 *      and <i>o</i> satisfies a POP application 
 *      <i>(tau, (g1, o1), ..., (gk, ok))</i> such that <i>o1, ..., ok</i> 
 *      satisfy the parents of <i>v</i> given <i>(w, a)</i>;
 *
 * <li> <i>v</i> is an <code>OrNode</code> and <i>o</i> satisfies one of the 
 *      parents of <i>v</i> given <i>(w, a)</i> (we ensure that the parents 
 *      of an <code>OrNode</code> are satisfied by disjoint sets);
 *
 * <li> <i>v</i> is a <code>TermNode</code> for a term <i>t</i> and 
 *      <i>o</i> is the denotation of <i>t</i> given <i>(w, a)</i>;
 *
 * <li> <i>v</i> is an <code>IntegerNode</code> with lower bounds 
 *      <i>s1, ..., sj</i> and upper bounds <i>t1, ..., tk</i>, and <i>o</i> 
 *      is an integer that is &gt;= the denotations of <i>s1, ..., sj</i> and 
 *      &lt;= the denotations of <i>t1, ..., tk</i> given <i>(w, a)</i>;
 *
 * <li> <i>v</i> is a <code>GuaranteedNode</code> for type <i>tau</i> and 
 *      <i>o</i> is a guaranteed object of type <i>tau</i>.
 * </ul>
 *
 * <p>The arguments to the ObjGenGraph constructor describe a certain
 * set of objects.  The ObjGenGraph contains a distinguished
 * <em>target node</em> that is satisfied by all the described objects
 * (and possibly some other objects that exist).  The
 * <code>iterator</code> method returns an iterator over 
 * the objects that satisfy the target node.  This set may be
 * infinite, but we can still iterate over it.
 */

public class ObjGenGraph extends AbstractDGraph {
    /**
     * Creates an object generation graph where the target node is satisfied 
     * by all objects of the given type.
     */
    public ObjGenGraph(Type type) {
	this.var = null;
	targetNode = getTypeNode(type, null, Collections.EMPTY_LIST);
	recordAncestorGraph(targetNode);
    }

    /**
     * Creates an object generation graph where the target node is satisfied 
     * by all objects of the given type that satisfy all the given constraints 
     * when bound to <code>subjectVar</code>.
     *
     * @param constraints List of Formula objects.  Only literals are 
     *                    processed.  
     *
     * @param freeVars    Set of String objects representing variables 
     *                    that should not be used in the graph because 
     *                    they will not be assigned values when the graph 
     *                    is used.
     */
    public ObjGenGraph(Type type, String subjectVar, List constraints, 
		       Set freeVars) {
	this.var = subjectVar;
	this.freeVars = freeVars;

	//System.out.println("Creating ObjGenGraph for {" + type + " "
	//		   + subjectVar + " : " + constraints + "}");

	targetNode = getTypeNode(type, new VariableTerm(subjectVar), 
				 constraints);
	recordAncestorGraph(targetNode);

	//print(System.out);
    }

    /**
     * Creates an object generation graph where the set of free variables 
     * consists of just the subject variable.
     */
    public ObjGenGraph(Type type, String subjectVar, List constraints) {
	this(type, subjectVar, constraints, 
	     Collections.singleton(subjectVar));
    }

    public ObjectIterator iterator(PartialWorld w, Assignment a, 
				   ValueChooser chooser) {
	return new SatisfierIterator(w, a, chooser);
    }

    public Set nodes() {
	return Collections.unmodifiableSet(nodes);
    }

    public Set getParents(Object v) {
	if (nodes.contains(v)) {
	    return ((Node) v).getParents();
	}
	throw new IllegalArgumentException
	    ("Tried to get parents of non-node " + v + ".");
    }

    public Set getChildren(Object v) {
	if (nodes.contains(v)) {
	    return ((Node) v).getChildren();
	}
	throw new IllegalArgumentException
	    ("Tried to get children of non-node " + v + ".");
    }

    public static abstract class Node {	

	abstract Set getParents();

	Set getChildren() {
	    return Collections.unmodifiableSet(children);
	}

	/**
	 * Ensures that the given node is in this node's child set.
	 */
	void addChild(Node child) {
	    children.add(child);
	}

	/**
	 * Returns an iterator over the objects that satisfy this node in 
	 * world <code>w</code> under assignment <code>a</code>.  The 
	 * method uses <code>chooser</code> to instantiate RVs as needed,
	 * and adds all the RVs it looks at to <code>bnParents</code>.  
	 *
	 * <p>The obvious algorithm for enumerating objects that satisfy 
	 * a node is by recursion in the object generation graph.  But 
	 * that algorithm would get stuck in cycles.  Thus, we terminate 
	 * the recursion at the parents of POPNodes.  A non-root node's 
	 * <code>iterator</code> method will be called repeatedly, with 
	 * larger and larger lists of satisfying objects for the parents 
	 * of POP nodes.  
	 *
	 * <p>Since we're calling <code>iterator</code> repeatedly, we
	 * need a way to get distinct objects each time.  Thus, we
	 * specify a list of <em>desired</em> objects for each POP
	 * node parent.  All the returned objects must satisfy a POP
	 * application involving at least one of these desired objects
	 * and possibly some of the additional objects specified in
	 * <code>otherPOPParentObjs</code>.  The desired parent
	 * objects will always be objects that were not included in
	 * the previous calls to <code>iterator</code>, so the objects
	 * returned will be distinct from those returned previously.
	 *
	 * <p>As an exception, if <code>includeGuaranteed</code> is true, 
	 * then the returned objects may also be guaranteed objects,  
	 * objects that satisfy a POP application with an empty tuple of 
	 * generating objects, or the satisfiers of TermNodes.  
	 *
	 * @param desiredPOPParentObjs     Map from Node to List
	 * @param otherPOPParentObjs  Map from Node to List
	 */
	public abstract ObjectIterator iterator(PartialWorld w, 
						Assignment a, 
						ValueChooser chooser, 
						Set bnParents, 
						Map desiredPOPParentObjs, 
						Map otherPOPParentObjs, 
						boolean includeGuaranteed);

	/**
	 * Returns true if every call to this node's <code>iterator</code>
	 * method returns an iterator over a finite set.  
	 */
	public abstract boolean isFinite();

	Set children = new HashSet();
    }

    public static class OrNode extends Node {
	/**
	 * Creates a new OrNode with the given nodes as parents.
	 *
	 * @param parents Set of Node objects
	 */
	private OrNode(Set parents) {
	    this.parents = new HashSet(parents);
	}

	Set getParents() {
	    return Collections.unmodifiableSet(parents);
	}

	public ObjectIterator iterator(PartialWorld w, 
				       Assignment a, 
				       ValueChooser chooser, 
				       Set bnParents, 
				       Map desiredPOPParentObjs, 
				       Map otherPOPParentObjs, 
				       boolean includeGuaranteed) {
	    return new OrNodeIterator(w, a, chooser, bnParents, 
				      desiredPOPParentObjs, 
				      otherPOPParentObjs,
				      includeGuaranteed);
	}

	public boolean isFinite() {
	    return true; // assumes no IntegerNodes as parents
	}

	private class OrNodeIterator implements ObjectIterator {
	    OrNodeIterator(PartialWorld w, 
			   Assignment a, 
			   ValueChooser chooser, 
			   Set bnParents, 
			   Map desiredPOPParentObjs, 
			   Map otherPOPParentObjs, 
			   boolean includeGuaranteed) {
		this.w = w;
		this.a = a;
		this.chooser = chooser;
		this.bnParents = bnParents;
		this.desiredPOPParentObjs = desiredPOPParentObjs;
		this.otherPOPParentObjs = otherPOPParentObjs;
		this.includeGuaranteed = includeGuaranteed;

		parentsIter = parents.iterator();
		nextObj = findNext();
	    }

	    public boolean hasNext() {
		return (nextObj != null);
	    }

	    public Object next() {
		if (nextObj == null) {
		    throw new NoSuchElementException();
		}

		Object toReturn = nextObj;
		nextObj = findNext();
		return toReturn;
	    }

	    public void remove() {
		throw new UnsupportedOperationException
		    ("Can't remove from OrNodeIterator.");
	    }

	    public Set getParents() {
		return bnParents; // more parents than necessary
	    }

	    public boolean canComputeNext() {
		return canComputeNext;
	    }

	    private Object findNext() {
		while ((curParentIter == null) || !curParentIter.hasNext()) {
		    if ((curParentIter != null) 
			&& !curParentIter.canComputeNext()) {
			canComputeNext = false;
			return null;
		    }

		    // Move on to next parent
		    if (parentsIter.hasNext()) {
			Node parent = (Node) parentsIter.next();
			if (!parent.isFinite()) {
			    throw new IllegalStateException
				("Parent of OrNode returned iterator over "
				 + "infinite set.");
			}
			curParentIter = parent.iterator
			    (w, a, chooser, bnParents, 
			     desiredPOPParentObjs, otherPOPParentObjs, 
			     includeGuaranteed);
		    } else {
			return null;
		    }
		}

		return curParentIter.next();
	    }

	    PartialWorld w;
	    Assignment a;
	    ValueChooser chooser;
	    Set bnParents;
	    Map desiredPOPParentObjs;
	    Map otherPOPParentObjs;
	    boolean includeGuaranteed;

	    Iterator parentsIter;
	    ObjectIterator curParentIter = null;
	    Object nextObj;
	    boolean canComputeNext = true;
	}

	Set parents;
    }

    /**
     * Node satisfied by the set of objects that satisfy a given potential 
     * object pattern (POP).
     */
    public static class POPNode extends Node {
	private POPNode(POP pop, List parents) {
	    this.pop = pop;
	    this.parents = new ArrayList(parents);
	}

	public Set getParents() {
	    return new HashSet(parents);
	}

	public ObjectIterator iterator(PartialWorld w, 
				       Assignment a, 
				       ValueChooser chooser, 
				       Set bnParents, 
				       Map desiredPOPParentObjs, 
				       Map otherPOPParentObjs, 
				       boolean includeGuaranteed) {
	    return new POPNodeIterator(w, a, chooser, bnParents, 
				       desiredPOPParentObjs, 
				       otherPOPParentObjs,
				       includeGuaranteed);
	}

	public boolean isFinite() {
	    return true;
	}

	public String toString() {
	    return ("POP " + pop);
	}

	/**
	 * To return objects generated by POP applications 
	 * that involve at least one desired parent object, we iterate 
	 * over tuples of generating objects where the first position 
	 * with a desired object is position 1, then likewise for position 
	 * 2, and so on.  
	 */
	private class POPNodeIterator implements ObjectIterator {
	    POPNodeIterator(PartialWorld w, 
			    Assignment a, 
			    ValueChooser chooser, 
			    Set bnParents, 
			    Map desiredPOPParentObjs, 
			    Map otherPOPParentObjs, 
			    boolean includeGuaranteed) {
		this.w = w;
		this.a = a;
		this.chooser = chooser;
		this.bnParents = bnParents;
		this.desiredPOPParentObjs = desiredPOPParentObjs;
		this.otherPOPParentObjs = otherPOPParentObjs;
		this.includeGuaranteed = includeGuaranteed;

		nextObj = findNext();
	    }

	    public boolean hasNext() {
		return (nextObj != null);
	    }

	    public Object next() {
		if (nextObj == null) {
		    throw new NoSuchElementException();
		}

		Object toReturn = nextObj;
		nextObj = findNext();
		return toReturn;
	    }

	    public void remove() {
		throw new UnsupportedOperationException
		    ("Can't remove from OrNodeIterator.");
	    }

	    public Set getParents() {
		return bnParents; // more parents than necessary
	    }

	    public boolean canComputeNext() {
		return canComputeNext;
	    }

	    private Object findNext() {
		while ((satisfyingObjIter == null) 
		       || !satisfyingObjIter.hasNext()) {

		    // Need to move on to next parent tuple -- that is, 
		    // next tuple of generating objects
		    while ((parentTupleIter == null) 
			   || !parentTupleIter.hasNext()) {

			// Need to move on to next first-desired-object index
			if (parents.isEmpty() && !doneEmptyTuple) {
			    parentTupleIter = new TupleIterator
				(Collections.EMPTY_LIST);
			    doneEmptyTuple = true;
			} else if (firstDesiredObjIndex < parents.size()) {
			    parentTupleIter = new TupleIterator
				(getParentObjLists());
			    ++firstDesiredObjIndex;
			} else {
			    return null;
			}
		    }

		    // Have tuple of generating objects; 
		    // see what they generate 
		    List genObjs = (List) parentTupleIter.next();
		    NumberVar rv = new NumberVar(pop, genObjs);
		    if (!w.isInstantiated(rv)) {
			if (chooser == null) {
			    canComputeNext = false;
			    return null;
			}
			rv.ensureInstAndSupported(w, chooser);
		    }
		    bnParents.add(rv);
			
		    satisfyingObjIter 
			= w.getSatisfiers(pop, genObjs).iterator();
		}

		return satisfyingObjIter.next();
	    }

	    private List getParentObjLists() {
		List objLists = new ArrayList(); // List of Lists
		for (int i = 0; i < parents.size(); ++i) {
		    Node parent = (Node) parents.get(i);
		    if (i < firstDesiredObjIndex) {
			objLists.add(otherPOPParentObjs.get(parent));
		    } else if (i == firstDesiredObjIndex) {
			objLists.add(desiredPOPParentObjs.get(parent));
		    } else {
			objLists.add(Util.concat
				     ((List) desiredPOPParentObjs.get(parent), 
				      (List) otherPOPParentObjs.get(parent)));
		    }
		}
		return objLists;
	    }

	    PartialWorld w;
	    Assignment a;
	    ValueChooser chooser;
	    Set bnParents;
	    Map desiredPOPParentObjs;
	    Map otherPOPParentObjs;
	    boolean includeGuaranteed;

	    boolean doneEmptyTuple = false;
	    int firstDesiredObjIndex = 0;
	    Iterator parentTupleIter = null;
	    Iterator satisfyingObjIter = null;
	    Object nextObj;
	    boolean canComputeNext = true;
	}

	POP pop;
	List parents;
    }

    /**
     * Node satisfied only by the denotation of the given term.
     */
    public static class TermNode extends Node {
	private TermNode(Term term) {
	    this.term = term;
	}

	public Set getParents() {
	    return Collections.EMPTY_SET;
	}

	public ObjectIterator iterator(PartialWorld w, 
				       Assignment a, 
				       ValueChooser chooser, 
				       Set bnParents, 
				       Map desiredPOPParentObjs, 
				       Map otherPOPParentObjs, 
				       boolean includeGuaranteed) {
	    if (includeGuaranteed) {
		ParentsAndValue info = term.getParentsAndValue(w, a, chooser);
		if (info == null) {
		    return ObjectIterator.STUCK_ITER;
		}
		bnParents.addAll(info.getParents());
		if (info.getValue() != Model.NULL) {
		    Set s = Collections.singleton(info.getValue());
		    return new DefaultObjectIterator(s.iterator(), 
						     info.getParents());
		}
	    }
	    return new DefaultObjectIterator(Collections.EMPTY_SET.iterator(), 
					     Collections.EMPTY_SET);
	}

	public boolean isFinite() {
	    return true;
	}

	public String toString() {
	    return term.toString();
	}

	Term term;
    }

    public static class IntegerNode extends Node {
	private IntegerNode(List lowerBounds, List upperBounds) {
	    this.lowerBounds = lowerBounds;
	    this.upperBounds = upperBounds;
	}

	public Set getParents() {
	    return Collections.EMPTY_SET;
	}

	public ObjectIterator iterator(PartialWorld w, 
				       Assignment a, 
				       ValueChooser chooser, 
				       Set bnParents, 
				       Map desiredPOPParentObjs, 
				       Map otherPOPParentObjs, 
				       boolean includeGuaranteed) {
	    if (!includeGuaranteed) {
		return new DefaultObjectIterator
		    (Collections.EMPTY_LIST.iterator(), Collections.EMPTY_SET);
	    }

	    if (!lowerBounds.isEmpty()) {
		Integer l = getLowerBound(w, a, chooser, bnParents);
		if (l == null) {
		    return ObjectIterator.STUCK_ITER;
		}

		if (!upperBounds.isEmpty()) {
		    Integer u = getUpperBound(w, a, chooser, bnParents);
		    if (u == null) {
			return ObjectIterator.STUCK_ITER;
		    }

		    Iterator iter = Util.getIntegerRangeIterator
			(l.intValue(), u.intValue());
		    return new DefaultObjectIterator(iter, bnParents);
		}

		Iterator iter = Util.getAscendingIntegerIterator(l.intValue());
		return new DefaultObjectIterator(iter, bnParents);
	    }
	    if (!upperBounds.isEmpty()) {
		Integer u = getUpperBound(w, a, chooser, bnParents);
		if (u == null) {
		    return ObjectIterator.STUCK_ITER;
		}

		Iterator iter = Util.getDescendingIntegerIterator
		    (u.intValue());
		return new DefaultObjectIterator(iter, bnParents);
	    }

	    return new DefaultObjectIterator(Util.getIntegerIterator(), 
					     Collections.EMPTY_SET);
	}

	public boolean isFinite() {
	    return ((!lowerBounds.isEmpty()) && (!upperBounds.isEmpty()));
	}

	public String toString() {
	    StringBuffer buf = new StringBuffer();
	    buf.append("[(");
	    for (Iterator iter = lowerBounds.iterator(); iter.hasNext(); ) {
		buf.append(iter.next());
	    }
	    buf.append("), (");
	    for (Iterator iter = upperBounds.iterator(); iter.hasNext(); ) {
		buf.append(iter.next());
	    }
	    buf.append(")]");
	    return buf.toString();
	}

	Integer getLowerBound(PartialWorld w, Assignment a, 
			      ValueChooser chooser, Set bnParents) {
	    if (lowerBounds.isEmpty()) {
		throw new IllegalStateException
		    ("This IntegerNode has no lower bound.");
	    }

	    int lowerBound = 0;
	    for (int i = 0; i < lowerBounds.size(); ++i) {
		Term bound = (Term) lowerBounds.get(i);
		ParentsAndValue info = bound.getParentsAndValue(w, a, chooser);
		if (info == null) {
		    return null;
		}
		bnParents.addAll(info.getParents());
		int thisBound = ((Integer) info.getValue()).intValue();
		if ((i == 0) || (thisBound < lowerBound)) {
		    lowerBound = thisBound;
		}
	    }

	    return new Integer(lowerBound);
	}

	Integer getUpperBound(PartialWorld w, Assignment a, 
			      ValueChooser chooser, Set bnParents) {
	    if (upperBounds.isEmpty()) {
		throw new IllegalStateException
		    ("This IntegerNode has no upper bound.");
	    }

	    int upperBound = 0;
	    for (int i = 0; i < upperBounds.size(); ++i) {
		Term bound = (Term) upperBounds.get(i);
		ParentsAndValue info = bound.getParentsAndValue(w, a, chooser);
		if (info == null) {
		    return null;
		}
		bnParents.addAll(info.getParents());
		int thisBound = ((Integer) info.getValue()).intValue();
		if ((i == 0) || (thisBound > upperBound)) {
		   upperBound = thisBound;
		}
	    }

	    return new Integer(upperBound);
	}

	List lowerBounds; // of Term
	List upperBounds; // of Term
    }

    public static class GuaranteedNode extends Node {
	private GuaranteedNode(Type type) {
	    this.type = type;

	    if (type == BuiltInTypes.BOOLEAN) {
		satisfiers = new ArrayList();
		satisfiers.add(Boolean.FALSE);
		satisfiers.add(Boolean.TRUE);
	    } else if (type.isBuiltIn()) {
		satisfiers = null; // set that we won't enumerate
	    } else {
		// user-defined type
		satisfiers = type.getGuaranteedObjects();
	    }
	}

	public Set getParents() {
	    return Collections.EMPTY_SET;
	}

	public ObjectIterator iterator(PartialWorld w, 
				       Assignment a, 
				       ValueChooser chooser, 
				       Set bnParents, 
				       Map desiredPOPParentObjs, 
				       Map otherPOPParentObjs, 
				       boolean includeGuaranteed) {
	    if (includeGuaranteed) {
		if (satisfiers == null) {
		    throw new UnsupportedOperationException
			("Can't iterate over objects of type " + type);
		}

		return new DefaultObjectIterator(satisfiers.iterator(), 
						 Collections.EMPTY_SET);
	    }
	    return new DefaultObjectIterator(Collections.EMPTY_LIST.iterator(),
					     Collections.EMPTY_SET);
	}

	public boolean isFinite() {
	    return (satisfiers != null);
	}

	public String toString() {
	    return ("Guaranteed " + type);
	}

	List satisfiers;
	Type type;
    }

    private Node getTypeNode(Type type, Term subject, List constraints) {
	List relevantCons = new ArrayList();

	// First do processing that applies regardless of type
	for (Iterator iter = constraints.iterator(); iter.hasNext(); ) {
	    Formula constraint = (Formula) iter.next();
	    
	    if (constraint instanceof EqualityFormula) {
		EqualityFormula equality = (EqualityFormula) constraint;

		// If constraint says subject is null, return null
		if (equality.assertsNull(subject)) {
		    return null;
		}

		// If constraint says subject equals a term that does not 
		// contain any free vars, then return TermNode for that term
		Term equalTerm = equality.getEqualTerm(subject);
		if ((equalTerm != null) && !containsFreeVar(equalTerm)) {
		    return new TermNode(equalTerm);
		}
	    }
	    
	    // If constraint mentions subject, add it to relevant 
	    // constraints list
	    if (constraint.containsTerm(subject)) {
		relevantCons.add(constraint);
	    }
	}
	
	// Now do type-specific processing

	if (type == BuiltInTypes.INTEGER) {
	    return getIntegerNode(subject, constraints, false);
	} 
	else if (type == BuiltInTypes.NATURAL_NUM) {
	    return getIntegerNode(subject, constraints, true);
	}
	else if (type.isBuiltIn()) {
	    // Built-in type for which we don't recognize any constraints.
	    // None of the unprocessed constraints could be relevant.
	    return internNode(new GuaranteedNode(type), type);
	}

	return getUserDefTypeNode(type, subject, constraints);
    }

    private Node getIntegerNode(Term subject, List constraints, 
				boolean nonnegative) {
	List lowerBounds = new ArrayList(); // of terms
	List upperBounds = new ArrayList(); // of terms

	for (Iterator iter = constraints.iterator(); iter.hasNext(); ) {
	    addBound((Formula) iter.next(), subject, lowerBounds, upperBounds);
	}
	
	Type unconstrainedType = null;
	if (lowerBounds.isEmpty() && upperBounds.isEmpty()) {
	    unconstrainedType = nonnegative ? 
		BuiltInTypes.NATURAL_NUM : BuiltInTypes.INTEGER;
	}

	if (nonnegative) {
	    lowerBounds.add(new FuncAppTerm(BuiltInFunctions.ZERO));
	}
		
	Node node = new IntegerNode(lowerBounds, upperBounds);
	return internNode(node, unconstrainedType);
    }

    private Node getUserDefTypeNode(Type type, Term subject, 
				    List constraints) {
	// See what constraints are asserted about the values of generating 
	// functions on subject.  Here we find generating functions that 
	// are constrained to be non-null; generating functions that are 
	// constrained to be null will be discovered by getPOPNode 
	// (when it calls getTypeNode with the relevant gen func application 
	// as the subject).  
	Set nonNullGenFuncs = new HashSet();
	List genFuncConstraints = new ArrayList();
	for (Iterator iter = constraints.iterator(); iter.hasNext(); ) {
	    Formula constraint = (Formula) iter.next();
	    Set genFuncsApplied = constraint.getGenFuncsApplied(subject);
	    if (!genFuncsApplied.isEmpty()) {
		genFuncConstraints.add(constraint);
	    }
		
	    for (Iterator genFuncIter = genFuncsApplied.iterator(); 
		 genFuncIter.hasNext(); ) {
		GeneratingFunction g = (GeneratingFunction) genFuncIter.next();
		FuncAppTerm t = new FuncAppTerm
		    (g, Collections.singletonList(subject));
		if (impliesNonNull(constraint, t)) {
		    nonNullGenFuncs.add(g);
		}
	    }
	}

	// Before adding parents, check to see if we're creating an 
	// unconstrained type node, and if so, whether one already exists 
	// for this type.  Even if the object generation graph is cyclic, 
	// the type nodes that we need will eventually be unconstrained, 
	// since constraints can only be finitely deep.  
	Type unconstrainedType = null;
	if (genFuncConstraints.isEmpty()) {
	    Node existing = (Node) unconstrainedNodes.get(type);
	    if (existing != null) {
		return existing;
	    }
	    unconstrainedType = type; // first visit to unconstrained type node
	}
	
	// Create parents
	Set parents = new HashSet();
	
	if (nonNullGenFuncs.isEmpty()) {
	    // Guaranteed objects of this type might satisfy constraints
	    parents.add(new GuaranteedNode(type));
	}

	for (Iterator iter = type.getPOPs().iterator(); iter.hasNext(); ) {
	    POP pop = (POP) iter.next();
	    List popGenFuncs = pop.getGeneratingFunctions();
	    if (popGenFuncs.containsAll(nonNullGenFuncs)) {
		// this POP uses all the non-null gen funcs
		Node popNode = getPOPNode(pop, subject, genFuncConstraints);

		// popNode could be null, e.g., if there is a
		// constraint saying one of its gen funcs is null
		if (popNode != null) {
		    parents.add(popNode);
		}
	    }
	}

	return internNode(new OrNode(parents), unconstrainedType);
    }

    private Node getPOPNode(POP pop, Term subject, List constraints) {
	List parents = new ArrayList();
	for (Iterator iter = pop.getGeneratingFunctions().iterator(); 
	     iter.hasNext(); ) {
	    GeneratingFunction g = (GeneratingFunction) iter.next();
	    Term newSubject 
		= new FuncAppTerm(g, Collections.singletonList(subject));
	    Node typeNode = getTypeNode(g.getRetType(), newSubject, 
					constraints);
	    if (typeNode == null) {
		// constraints say newSubject couldn't be any object
		return null;
	    }
	    parents.add(typeNode);
	}
	return new POPNode(pop, parents);
    }

    /**
     * Adds a weak lower bound to the list lowerBounds, or a weak upper 
     * bound to the list upperBounds.
     */
    private void addBound(Formula phi, Term subject, List lowerBounds, 
			  List upperBounds) {
	// See if phi is an atomic formula or the negation thereof
	AtomicFormula psi = null;
	boolean positive = true;
	if (phi instanceof AtomicFormula) {
	    psi = (AtomicFormula) phi;
	} else if ((phi instanceof NegFormula)
		   && (((NegFormula) phi).getNeg() 
		       instanceof AtomicFormula)) {
	    psi = (AtomicFormula) ((NegFormula) phi).getNeg();
	    positive = false;
	}
	if (psi == null) {
	    return; // not an atomic formula or negation thereof
	}
	
	// See if it uses one of the functions we recognize, and if one 
	// of the arguments is <code>subject</code> and the other does not 
	// contain <code>var</code>.
	Term psiTerm = psi.getTerm();
	Function f = (psiTerm instanceof FuncAppTerm) ?
	    ((FuncAppTerm) psiTerm).getFunction() : null;
	boolean isFirstArg = true;
	Term bound = null;
	if ((f == BuiltInFunctions.LT) 
	    || (f == BuiltInFunctions.LEQ)
	    || (f == BuiltInFunctions.GT) 
	    || (f == BuiltInFunctions.GEQ)) {
	    List args = ((FuncAppTerm) psiTerm).getArgs();
	    if (subject.equals(args.get(0))) {
		bound = (Term) args.get(1);
	    } else if (subject.equals(args.get(1))) {
		isFirstArg = false;
		bound = (Term) args.get(0);
	    }
	}
	if ((bound == null) || containsFreeVar(bound)) {
	    return; // not a formula we can interpret
	}
	
	// Go through the logic of what's being asserted
	boolean strict = ((f == BuiltInFunctions.LT) 
			  || (f == BuiltInFunctions.GT));
	boolean upper = ((f == BuiltInFunctions.LT)
			 || (f == BuiltInFunctions.LEQ));
	if (!positive) {
	    upper = !upper;
	}
	if (!isFirstArg) {
	    upper = !upper;
	}
	
	if (strict) {
	    Term one = new FuncAppTerm(BuiltInFunctions.ONE);
	    List args = new ArrayList();
	    args.add(bound);
	    args.add(one);
	    
	    if (upper) {
		// Strictly upper-bounded by other, so weakly 
		// upper-bounded by (other - 1).
		bound = new FuncAppTerm(BuiltInFunctions.MINUS, args);
	    } else {
		// Strictly lower-bounded by other, so weakly 
		// lower-bounded by (other + 1).
		bound = new FuncAppTerm(BuiltInFunctions.PLUS, args);
	    }
	}
	
	if (upper) {
	    if (!upperBounds.contains(bound)) {
		upperBounds.add(bound);
	    }
	} else {
	    if (!lowerBounds.contains(bound)) {
		lowerBounds.add(bound);
	    }
	}
    }

    private boolean containsFreeVar(Term term) {
	return !Util.intersection(term.getVariables(), freeVars).isEmpty();
    }

    private Node internNode(Node node, Type unconstrainedType) {
	if (unconstrainedType != null) {
	    // See if we already have a node for this unconstrained type 
	    // in the graph.
	    Node existing = (Node) unconstrainedNodes.get(unconstrainedType);
	    if (existing != null) {
		return existing;
	    }
	    unconstrainedNodes.put(unconstrainedType, node);
	}

	return node;
    }
	
    private void recordAncestorGraph(Node v) {
	if (!nodes.contains(v)) {
	    nodes.add(v);

	    for (Iterator iter = v.getParents().iterator(); iter.hasNext(); ) {
		Node parent = (Node) iter.next();
		parent.addChild(v);
		recordAncestorGraph(parent);
	    }
	}
    }

    /**
     * Returns true if phi being true implies that t is not null.  Assumes 
     * phi is a literal.  
     */
    private static boolean impliesNonNull(Formula phi, Term t) {
	if (!phi.containsTerm(t)) {
	    return false;
	}

	if (phi instanceof AtomicFormula) {
	    // If phi is true than its top-level function returns true, 
	    // which means all its arguments are non-null
	    return true;
	}

	if (phi instanceof EqualityFormula) {
	    // Return true if one of the terms in the equality contains t, 
	    // and the other term is always non-null.  This assumes that 
	    // any function returns null when applied to a null argument --
	    // there's no special case that says Boolean functions return 
	    // false.  
	    EqualityFormula equality = (EqualityFormula) phi;
	    return ((equality.getTerm1().containsTerm(t) && 
		     isNonNullTerm(equality.getTerm2()))
		    || (equality.getTerm2().containsTerm(t) &&
			isNonNullTerm(equality.getTerm1())));
	}

	if (phi instanceof NegFormula) {
	    // Return true if phi is the negation of an equality formula 
	    // that asserts t is null
	    NegFormula negation = (NegFormula) phi;
	    return ((negation.getNeg() instanceof EqualityFormula) 
		    && ((EqualityFormula) negation.getNeg()).assertsNull(t));
	}

	return false;
    }

    /**
     * Returns true if t is a term that cannot evaluate to null, namely a 
     * VariableTerm or a NonRandomConstant whose value is not null.
     */
    private static boolean isNonNullTerm(Term t) {
	if (t instanceof VariableTerm) {
	    return true;
	}
	if (t instanceof FuncAppTerm) {
	    Function f = ((FuncAppTerm) t).getFunction();
	    return ((f instanceof NonRandomConstant)
		    && (((NonRandomConstant) f).getValue() != Model.NULL));
	}
	return false;
    }

    private class SatisfierIterator implements ObjectIterator {
	SatisfierIterator(PartialWorld w, Assignment a, ValueChooser chooser) {
	    this.w = w;
	    this.a = a;
	    this.chooser = chooser;

	    // For each POPNode, add its parents to the POP parent maps, 
	    // associated with empty lists
	    for (Iterator nodeIter = nodes.iterator(); nodeIter.hasNext(); ) {
		Node node = (Node) nodeIter.next();
		if (node instanceof POPNode) {
		    for (Iterator parentIter = node.getParents().iterator(); 
			 parentIter.hasNext(); ) {
			Node parent = (Node) parentIter.next();
			popParentCurRoundObjs.put(parent, new ArrayList());
			popParentPrevRoundObjs.put(parent, new ArrayList());
			popParentEarlierRoundObjs.put(parent, new ArrayList());
		    }
		}
	    }

	    targetIter = getNodeIterator(targetNode);
	    nextObj = findNext();
	}

	public boolean hasNext() {
	    return (nextObj != null);
	}

	public Object next() {
	    if (nextObj == null) {
		throw new NoSuchElementException();
	    }

	    Object toReturn = nextObj;
	    nextObj = findNext();
	    return toReturn;
	}

	public void remove() {
	    throw new UnsupportedOperationException
		("Can't remove from ObjGenGraph iterator.");
	}

	public Set getParents() {
	    return Collections.unmodifiableSet(bnParents);
	}

	public boolean canComputeNext() {
	    return canComputeNext;
	}

	Object findNext() {
	    // If the target iterator has no more elements, we need to
	    // finish this round and start a new one.  Do this
	    // repeatedly until the target node iterator has a next
	    // element, or until we complete a round where no objects
	    // are added for any POP parents.
	    while (!targetIter.hasNext()) {
		if (!targetIter.canComputeNext()) {
		    canComputeNext = false;
		    return null;
		}

		// Process all the other POP parents in this round.  
		// Note that within a round, the order in which nodes 
		// are processed doesn't matter.  
		for (Iterator iter = popParentCurRoundObjs.keySet()
			 .iterator(); iter.hasNext(); ) {
		    Node popParent = (Node) iter.next();
		    if (popParent != targetNode) {
			if (!processPOPParent(popParent)) {
			    return null;
			}
		    }
		}

		// Try to start new round.  
		if (!startNewRound()) {
		    return null;
		}

		// Don't include guaranteed objects in new iterators after 
		// the first round
		includeGuaranteed = false;

		// We will process the target node first in the new round
		targetIter = getNodeIterator(targetNode);
	    }

	    // Continue processing the target node in the current round
	    Object newObj = targetIter.next();
	    if (popParentCurRoundObjs.containsKey(targetNode)) {
		((List) popParentCurRoundObjs.get(targetNode)).add(newObj);
	    }
	    return newObj;
	}

	private boolean startNewRound() {
	    // TODO: limit ourselves to parents of POPs that are still 
	    // active, i.e., POPs that don't have a permanently empty 
	    // parent.  A node is permanently empty if it has no 
	    // objects and none of its ancestors generated any objects 
	    // in the current round.  
	    
	    boolean haveNewObjs = false;
	    for (Iterator iter = popParentCurRoundObjs.entrySet().iterator(); 
		 iter.hasNext(); ) {
		Map.Entry entry = (Map.Entry) iter.next();
		Node popParent = (Node) entry.getKey();
		List curRoundObjs = (List) entry.getValue();
		if (!curRoundObjs.isEmpty()) {
		    haveNewObjs = true;
		}
		
		List prevRoundObjs 
		    = (List) popParentPrevRoundObjs.get(popParent);
		List earlierRoundObjs 
		    = (List) popParentEarlierRoundObjs.get(popParent);
		earlierRoundObjs.addAll(prevRoundObjs);
		
		prevRoundObjs.clear();
		prevRoundObjs.addAll(curRoundObjs);
		curRoundObjs.clear();
	    }

	    return haveNewObjs;
	}

	private boolean processPOPParent(Node node) {
	    List curRoundObjs = (List) popParentCurRoundObjs.get(node);
	    ObjectIterator iter = getNodeIterator(node);
	    if (node.isFinite()) {
		// Get all objects from iterator
		while (iter.hasNext()) {
		    curRoundObjs.add(iter.next());
		}
	    } else {
		// Get only one object from iterator
		if (iter.hasNext()) {
		    curRoundObjs.add(iter.next());
		}
	    }

	    if (!iter.canComputeNext()) {
		canComputeNext = false;
		return false;
	    }
	    return true;
	}

	private ObjectIterator getNodeIterator(Node node) {
	    if (rootIters.containsKey(node)) {
		return (ObjectIterator) rootIters.get(node);
	    }

	    ObjectIterator iter = node.iterator(w, a, chooser, bnParents, 
						popParentPrevRoundObjs, 
						popParentEarlierRoundObjs,
						includeGuaranteed);
	    if (node.getParents().isEmpty()) {
		rootIters.put(node, iter);
	    }
	    return iter;
	}

	PartialWorld w;
	Assignment a;
	ValueChooser chooser;

	boolean includeGuaranteed = true;
	Map popParentCurRoundObjs = new HashMap();     // from Node to List
	Map popParentPrevRoundObjs = new HashMap();    // from Node to List
	Map popParentEarlierRoundObjs = new HashMap(); // from Node to List
	Map rootIters = new HashMap(); // from Node to ObjectIterator

	ObjectIterator targetIter;

	Object nextObj;
	Set bnParents = new HashSet();
	boolean canComputeNext = true;
    }
    
    private Set nodes = new HashSet(); // of Node
    private Map unconstrainedNodes = new HashMap(); // from Type to Node
    
    private Node targetNode;

    private String var;
    private Set freeVars;
}
