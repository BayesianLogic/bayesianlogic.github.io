/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

import common.MapDiff;
import common.HashMapDiff;
import common.MultiMap;
import common.HashMultiMap;
import common.MultiMapDiff;
import common.HashMultiMapDiff;
import common.DGraph;
import common.MutableDGraph;
import common.ParentUpdateDGraph;

/**
 * Implementation of the PartialWorld interface that includes public 
 * methods for adding and removing identifiers; instantiating, uninstantiating 
 * and changing variables; and adding and removing derived variables in the 
 * Bayes net.  
 *
 * <p>MutablePartialWorld also includes methods for saving a partial
 * world, efficiently enumerating the differences between the current
 * world and the saved world, and reverting back to the saved world.
 * When a version has been saved, editing the MutablePartialWorld is
 * like editing a document that is open in a text editor: it doesn't
 * change the saved version.  (This is just an analogy --
 * MutablePartialWorld doesn't write the saved version to disk.)
 */
public class MutablePartialWorld extends AbstractPartialWorld {

    /**
     * Creates a new partial world for the given model.  Initially, the 
     * saved version is an empty world: no identifiers, no instantiated 
     * variables, no nodes in the Bayes net.  
     *
     * @param idTypes Set of Type objects for types that will be represented 
     *                with object identifiers
     */
    public MutablePartialWorld(Model model, Set idTypes) {
	super(model, idTypes);

	savedWorld = new SavedPartialWorld(model, idTypes);
    }

    /**
     * Creates a new partial world for the given model.  The saved version 
     * is empty, but the current version is initialized to equal the given 
     * world.
     */
    public MutablePartialWorld(Model model, Set idTypes, PartialWorld orig) {
	super(model, idTypes);
	savedWorld = new SavedPartialWorld(model, idTypes);

	for (Iterator iter = orig.getIdentifiers().iterator(); 
	     iter.hasNext(); ) {
	    addIdentifier((ObjectIdentifier) iter.next());
	}

	for (Iterator iter = orig.getInstantiatedVars().iterator(); 
	     iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    setValue(var, orig.getValue(var));
	}

	for (Iterator iter = orig.getBayesNet().nodes().iterator(); 
	     iter.hasNext(); ) {
	    BayesNetVar node = (BayesNetVar) iter.next();
	    if (node instanceof DerivedVar) {
		addDerivedVar((DerivedVar) node);
	    }
	}
    }

    /**
     * Adds the given identifier to the set of object identifiers in this 
     * partial world.  Does nothing if the identifier is already present.  
     */
    public void addIdentifier(ObjectIdentifier id) {
	idToNumberVar.put(id, null); // just null for the moment
	updateIdentifierOrigin(id);
    }

    /**
     * Adds a new identifier to the given world and sets its generating 
     * function values so that it satisfies the given POP applied to 
     * the given tuple of generating objects.  Returns the added identifier.  
     */
    public ObjectIdentifier addIdentifierForPOPApp(POP pop, List genObjs) {
	ObjectIdentifier newId = new ObjectIdentifier(pop.getType());
	addIdentifier(newId);
	
	for (int i = 0; i < pop.getGeneratingFunctions().size(); ++i) {
	    GeneratingFunction f 
		= (GeneratingFunction) pop.getGeneratingFunctions().get(i);
	    GenFuncAppVar var = new GenFuncAppVar(f, newId);
	    setValue(var, genObjs.get(i));
	}

	return newId;
    }

    /**
     * Removes the given identifier from the set of object identifiers in this 
     * partial world.  Does nothing if the identifier was not present.  
     */
    public void removeIdentifier(ObjectIdentifier id) {
	// remove from number var if applicable
	NumberVar oldNumberVar = (NumberVar) idToNumberVar.get(id);
	if (oldNumberVar != null) {
	    numberVarToIds.remove(oldNumberVar, id);
	}

	// remove from unsourced identifier set if applicable
	unsourcedIds.remove(id.getType(), id);

	idToNumberVar.remove(id);
    }

    /**
     * Instantiates the given variable to the given value (replacing
     * any previous value).  This method instantiates the variable even if 
     * some of its arguments do not necessarily exist in this world.  
     *
     * TODO: if var is a NumberVar, uninstantiate variables parameterized by 
     * removed objects.
     *
     * @throws IllegalArgumentException      if <code>var</code> is not a 
     *                                       BasicVar or GenFuncAppVar
     *
     * @throws IllegalArgumentException      if any arguments of 
     *                                       <code>var</code> are identifiers 
     *                                       that do not exist in this world
     *
     * @throws IllegalArgumentException      if <code>value</code> is an 
     *                                       ObjectIdentifier that does not 
     *                                       exist in this PartialWorld
     */
    public void setValue(BayesNetVar var, Object value) {
	if ((value instanceof ObjectIdentifier) 
	    && !getIdentifiers().contains(value)) {
	    throw new IllegalArgumentException("Invalid identifier: " + value);
	}

	Object oldValue = varValues.get(var);

	if (var instanceof BasicVar) {
	    for (Iterator iter = ((BasicVar) var).args().iterator(); 
		 iter.hasNext(); ) {
		Object arg = iter.next();
		if ((arg instanceof ObjectIdentifier) && !isValidObject(arg)) {
		    throw new IllegalArgumentException
			("Invalid identifier: " + arg);
		}
	    }

	    varValues.put(var, value);
	    updateGraphForChange(var);
	    updateUsageForChange(var, oldValue, value);
	}
	else if (var instanceof GenFuncAppVar) {
	    GenFuncAppVar genFuncAppVar = (GenFuncAppVar) var;
	    if (isValidObject(genFuncAppVar.arg())) {
		varValues.put(genFuncAppVar, value);
		updateIdentifierOrigin(genFuncAppVar.arg());
		updateGraphForChange(genFuncAppVar);
		updateUsageForChange(var, oldValue, value);
	    } else {
		throw new IllegalArgumentException
		    ("Invalid identifier: " + genFuncAppVar.arg());
	    }
	}
	else {
	    throw new IllegalArgumentException
		("Cannot instantiate variable: " + var);
	}
    }

    /**
     * Uninstantiates the given variable.  Does nothing if the variable 
     * was not instantiated.  
     */
    public void uninstantiate(BayesNetVar var) {
	Object oldValue = varValues.get(var);
	if (oldValue == null) {
	    return; // wasn't instantiated
	}

	varValues.remove(var);

	if (var instanceof GenFuncAppVar) {
	    updateIdentifierOrigin(((GenFuncAppVar) var).arg());
	}

	// Uninstantiating a variable can't change the parents of any other 
	// variable (although it may mean that some variables' parents 
	// aren't all instantiated anymore).  So all we have to do is 
	// remove var from the graph.
	bayesNet.removeNode(var);
	varsWithDirtyParentSets.remove(var);
	updateUsageForRemoval(var, oldValue);
    }
    
    /**
     * Adds the given derived variable to the Bayes net.
     */
    public void addDerivedVar(DerivedVar var) {
	bayesNet.addNode(var);
	varsWithDirtyParentSets.add(var); // parent set needs to be computed
    }

    /**
     * Removes the given derived variable from the Bayes net.
     */
    public void removeDerivedVar(DerivedVar var) {
	bayesNet.removeNode(var);
	varsWithDirtyParentSets.remove(var);
    }

    /**
     * Changes the saved version of this world to equal the current version.
     */
    public void save() {
	updateParentSets();
	
	varValues.changeUnderlying();
	idToNumberVar.changeUnderlying();
	numberVarToIds.changeUnderlying();
	unsourcedIds.changeUnderlying();
	bayesNet.changeUnderlying();
	
	idToUsesAsValue.changeUnderlying();
	idToUsesAsArg.changeUnderlying();
    }

    /**
     * Changes this world to equal the saved version.
     */
    public void revert() {
	varValues.clearChanges();
	idToNumberVar.clearChanges();
	numberVarToIds.clearChanges();
	unsourcedIds.clearChanges();
	bayesNet.clearChanges();

	idToUsesAsValue.clearChanges();
	idToUsesAsArg.clearChanges();
    }

    /**
     * Returns the saved version of this world.  The returned PartialWorld 
     * object is updated as new versions are saved.  
     */
    public PartialWorld getSaved() {
	return savedWorld;
    }

    /**
     * Returns the set of variables that have different values in the 
     * current world than they do in the saved world.  This includes 
     * variables that are instantiated in this world and not the saved 
     * world.
     *
     * @return unmodifiable Set of BayesNetVar
     */
    public Set getChangedVars() {
	return varValues.getChangedKeys();
    }

    /**
     * Returns the set of variables that are instantiated in the saved 
     * world but not in this world.
     */
    public Set getUninstantiatedVars() {
	return varValues.getRemovedKeys();
    }

    

    /**
     * Returns the Set of BayesNetVar objects V such that the probability
     * P(V | parents(V)) is not the same in this world as
     * in the saved world.  This may be because the value of V has
     * changed or because the values of some of V's parents have
     * changed. Note that it doesn't really make sense to talk about the
     * probability of a derived variable, however we are including these
     * in order to detect when a world does not satisfy the evidence.
     *
     * @return unmodifiable Set of BayesNetVar
     */
    public Set getVarsWithChangedProbs() {

	HashSet results = new HashSet();

	// Process all of 'varsWithDirtyParentSet'.
	updateParentSets();

	// 1. Include all variables that have had newly proposed values,
	//    which includes all newly instantiated variables.
	results.addAll(varValues.getChangedKeys());

	// 2. Include all variables whose parents have had newly proposed
	//       values. This trivially includes all variables whose
	//       parent set has changed, since the only way a parent set
	//       can change is if a parent (pivot) value has changed.
	Iterator parentsIter = varValues.getChangedKeys().iterator();
	while(parentsIter.hasNext()) {
	    BayesNetVar parent = (BayesNetVar) parentsIter.next();
	    Set children = bayesNet.getChildren(parent);
	    results.addAll(children);
	}

	// 3. Include all newly uninstantiated variables.
	results.addAll(varValues.getRemovedKeys());
	
	return results;
    }

    /**
     * Returns the set of variables that are barren in this world but 
     * either are not in the graph or are not barren in the saved world.  
     * A barren variable is one with no children.
     *
     * @return unmodifiable Set of BayesNetVar
     */
    public Set getNewlyBarrenVars() {
	updateParentSets();
	return bayesNet.getNewlyBarrenNodes();
    }

    /**
     * Returns the set of identifiers that are unsourced (i.e., it is not 
     * determined what POP application they satisfy) in this world, but 
     * do not exist or or are not unsourced in the saved world.
     *
     * @return unmodifiable Set of ObjectIdentifier
     */
    public Set getNewlyUnsourcedIds() {
	Set newlyUnsourced = new HashSet();

	// Iterate over types with identifiers added to their unsourced sets
	for (Iterator iter = unsourcedIds.getKeysWithAdditions().iterator(); 
	     iter.hasNext(); ) {
	    Set added = unsourcedIds.getAddedValues(iter.next());
	    newlyUnsourced.addAll(added);
	}

	return newlyUnsourced;
    }

    /**
     * Returns the set of identifiers that are impossible (i.e., it is 
     * determined that they satisfy no POP application) in this world, but 
     * do not exist or are not impossible in the saved world.
     *
     * @return unmodifiable Set of ObjectIdentifier
     */
    public Set getNewlyImpossibleIds() {
	Set newlyImpossible = new HashSet();

	// Iterate over identifiers with new or changed number variables
	for (Iterator iter = idToNumberVar.getChangedKeys().iterator(); 
	     iter.hasNext(); ) {
	    ObjectIdentifier id = (ObjectIdentifier) iter.next();
	    if ((idToNumberVar.get(id) == null)
		&& ((!getSaved().isValidObject(id))
		    || (getSaved().getPOPAppSatisfied(id) != null))) {
		newlyImpossible.add(id);
	    }
	}

	return newlyImpossible;
    }

    /**
     * Returns the set of identifiers that are present in this world and 
     * are not the value of any basic variable, but do not exist or are 
     * the value of some basic variable in the saved world.
     *
     * @return unmodifiable Set of ObjectIdentifier
     */
    public Set getNewlyFloatingIds() {
	Set newlyFloating = new HashSet();

	// Find added identifiers that are floating
	for (Iterator iter = idToNumberVar.getChangedKeys().iterator(); 
	     iter.hasNext(); ) { 
	    ObjectIdentifier id = (ObjectIdentifier) iter.next();
	    if ((!getSaved().isValidObject(id)) // if newly added... 
		&& isFloatingId(this, id)) {
		newlyFloating.add(id);
	    }
	}

	// Find identifiers that are floating because a basic variable 
	// was uninstantiated
	for (Iterator iter = varValues.getRemovedKeys().iterator(); 
	     iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    if (var instanceof BasicVar) {
		Object oldValue = getSaved().getValue(var);
		if ((oldValue instanceof ObjectIdentifier)
		    && isFloatingId(this, (ObjectIdentifier) oldValue)
		    && !isFloatingId(getSaved(), 
				     (ObjectIdentifier) oldValue)) {
		    newlyFloating.add(oldValue);
		}
	    }
	}

	return Collections.unmodifiableSet(newlyFloating);
    }

    private static boolean isFloatingId(PartialWorld w, 
					ObjectIdentifier id) {
	if (!w.isValidObject(id)) {
	    return false;
	}

	for (Iterator iter = w.getVarsWithValue(id).iterator(); 
	     iter.hasNext(); ) {
	    if (iter.next() instanceof BasicVar) {
		return false;
	    }
	}
	return true;
    }

    /**
     * Returns the set of number variables that are missing in this world but 
     * not the saved world.  A number variable is missing if some identifiers 
     * satisfy it, but it is not instantiated.
     *
     * @return unmodifiable Set of NumberVar
     */
    public Set getNewlyMissingNumberVars() {
	Set newlyMissing = new HashSet();

	// Iterate over number variables with added satisfiers
	for (Iterator iter = numberVarToIds.getKeysWithAdditions().iterator(); 
	     iter.hasNext(); ) {
	    NumberVar var = (NumberVar) iter.next();
	    if ((!isInstantiated(var))
		&& (getSaved().isInstantiated(var)
		    || ((Set) savedNumberVarToIds.get(var)).isEmpty())) {
		newlyMissing.add(var);
	    }
	}

	// Iterate over uninstantiated variables, look for number vars
	for (Iterator iter = varValues.getRemovedKeys().iterator(); 
	     iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    if (var instanceof NumberVar) {
		NumberVar numberVar = (NumberVar) var;
		if (!((Set) numberVarToIds.get(numberVar)).isEmpty()) {
		    newlyMissing.add(numberVar);
		}
	    }
	}

	return newlyMissing;
    }
		    
    /**
     * Returns the set of number variables that yield different probability 
     * multipliers in this world than they do in the saved world.  These 
     * are the number variables that have different values or different 
     * numbers of satisfying identifiers in this world and the saved world, 
     * and are satisfied by at least one identifier in this world or the 
     * saved world.
     *
     * @return unmodifiable Set of NumberVar
     */
    public Set getVarsWithChangedMultipliers() {
	Set changedMultipliers = new HashSet();

	// Iterate over variables whose values changed, look for number vars
	for (Iterator iter = varValues.getChangedKeys().iterator(); 
	     iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    if (var instanceof NumberVar) {
		NumberVar numVar = (NumberVar) var;
		if ((!((Set) numberVarToIds.get(numVar)).isEmpty())
		    || (!((Set) savedNumberVarToIds.get(numVar)).isEmpty())) {
		    changedMultipliers.add(numVar);
		}
	    }
	}

	// Iterate over uninstantiated variables, look for number vars
	for (Iterator iter = varValues.getRemovedKeys().iterator(); 
	     iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    if (var instanceof NumberVar) {
		NumberVar numVar = (NumberVar) var;
		if ((!((Set) numberVarToIds.get(numVar)).isEmpty())
		    || (!((Set) savedNumberVarToIds.get(numVar)).isEmpty())) {
		    changedMultipliers.add(numVar);
		}
	    }
	}

	// Iterate over number variables whose set of satisfying identifiers
	// changed
	for (Iterator iter = numberVarToIds.getKeysWithAdditions().iterator();
	     iter.hasNext(); ) {
	    changedMultipliers.add(iter.next());
	}
	for (Iterator iter = numberVarToIds.getKeysWithRemovals().iterator(); 
	     iter.hasNext(); ) {
	    changedMultipliers.add(iter.next());
	}

	return changedMultipliers;
    }

    /**
     * Returns a BitSet where the ith bit is set if the ith generating 
     * function for <code>obj</code>'s type has a non-null value on 
     * <code>obj</code>.  Returns null if <code>obj</code> is an identifier 
     * and not all the generating functions are instantiated on 
     * <code>obj</code>.
     *
     * @throws IllegalArgumentException if <code>obj</code> does not exist 
     *                                  in this partial world
     */
    BitSet getNonNullGenFuncs(ObjectIdentifier id) {
	Type type = id.getType();
	List typeGenFuncs = type.getGeneratingFunctions();
	BitSet nonNullGenFuncs = new BitSet(typeGenFuncs.size());
	
	for (int i = 0; i < typeGenFuncs.size(); ++i) {
	    GeneratingFunction f = (GeneratingFunction) typeGenFuncs.get(i);
	    GenFuncAppVar var = new GenFuncAppVar(f, id);
	    if (isInstantiated(var)) {
		if (getValue(var) != Model.NULL) {
		    nonNullGenFuncs.set(i);
		}
	    } else {
		return null; // not all generating functions instantiated
	    }
	}
	
	return nonNullGenFuncs;
    }

    void updateIdentifierOrigin(ObjectIdentifier id) {
	// Remove from old number var, if any
	NumberVar oldNumberVar = (NumberVar) idToNumberVar.get(id);
	if (oldNumberVar != null) {
	    numberVarToIds.remove(oldNumberVar, id);
	    satisfierRemoved(oldNumberVar, id);
	}

	// Figure out where this identifier goes now

	BitSet nonNullGenFuncs = getNonNullGenFuncs(id);
	if (nonNullGenFuncs == null) {
	    // Not all generating functions instantiated.
	    // Add to set of unsourced identifiers
	    unsourcedIds.add(id.getType(), id);
	    idToNumberVar.put(id, null);
	    return;
	} 

	// All generating functions are instantiated; 
	POP pop = id.getType().getPOPWithGenFuncs(nonNullGenFuncs);
	if (pop == null) {
	    // Doesn't satisfy any POP
	    idToNumberVar.put(id, null); 
	    return;
	} 
	
	// Identifier satisfies a POP; just need to determine
	// generating objects.  We can't reuse the sequence of objects
	// obtained inside getNonNullGenFuncs (even if we could access
	// it) because the order of generating functions may be
	// different.
	List genObjs = new ArrayList();
	for (Iterator iter = pop.getGeneratingFunctions().iterator(); 
	     iter.hasNext(); ) {
	    GeneratingFunction genFunc = (GeneratingFunction) iter.next();
	    GenFuncAppVar genVar = new GenFuncAppVar(genFunc, id);
	    genObjs.add(getValue(genVar));
	}
	
	NumberVar newNumberVar = new NumberVar(pop, genObjs);
	numberVarToIds.add(newNumberVar, id);
	idToNumberVar.put(id, newNumberVar);
	satisfierAdded(newNumberVar, id);
    }

    void updateGraphForChange(BayesNetVar changedVar) {
	if (!bayesNet.nodes().contains(changedVar)) {
	    // changedVar is newly instantiated
	    bayesNet.addNode(changedVar);
	    varsWithDirtyParentSets.add(changedVar);
	}

	// Mark all of changedVar's children as having dirty parent sets.
	
	// Note that we use the existing child set in the following
	// loop, even though this child set may be out of date if some
	// parent sets are already dirty.  This is safe because in a
	// contingent Bayes net, a variable can only join a child set
	// -- that is, gain a parent -- when one of its existing
	// parents gets a new value.  When that happens, we mark the
	// variable as having a dirty parent set; we don't need to
	// mark it again when a new parent changes.
	
	for (Iterator iter = bayesNet.getChildren(changedVar).iterator(); 
	     iter.hasNext(); ) {
	    varsWithDirtyParentSets.add(iter.next());
	}
    }

    // Update the parent sets of all variables marked as dirty.  We do this 
    // in batch because recomputing parent sets is somewhat expensive, 
    // and a variable might be marked dirty several times before we 
    // actually update the parent sets.  
    void updateParentSets() {
	for (Iterator iter = varsWithDirtyParentSets.iterator(); 
	     iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    ParentsAndValue pav = var.ensureInstAndSupported(this, null);
	    bayesNet.setParents(var, pav.getParents());
	}
	varsWithDirtyParentSets.clear();
    }

    void updateUsageForChange(BayesNetVar var, Object oldValue, 
			      Object newValue) {
	// Any identifier that is an argument to var is now used that way
	if (var instanceof BasicVar) {
	    for (Iterator iter = ((BasicVar) var).args().iterator(); 
		 iter.hasNext(); ) {
		Object arg = iter.next();
		if (arg instanceof ObjectIdentifier) {
		    idToUsesAsArg.add(arg, var);
		}
	    }
	} else if (var instanceof GenFuncAppVar) {
	    Object arg = ((GenFuncAppVar) var).arg();
	    if (arg instanceof ObjectIdentifier) {
		idToUsesAsArg.add(arg, var);
	    }
	}

	// If oldValue is not null and not equal to the new value, then it 
	// is no longer used as a value for var
	if ((oldValue instanceof ObjectIdentifier) 
	    && (oldValue != null) && !oldValue.equals(newValue)) {
	    idToUsesAsValue.remove(oldValue, var);
	}

	// newValue is used as a value for var
	if ((newValue instanceof ObjectIdentifier) && (newValue != null)) {
	    idToUsesAsValue.add(newValue, var);
	}
    }

    void updateUsageForRemoval(BayesNetVar var, Object oldValue) {
	// Arguments are no longer used as arguments to var
	if (var instanceof BasicVar) {
	    for (Iterator iter = ((BasicVar) var).args().iterator(); 
		 iter.hasNext(); ) {
		Object arg = iter.next();
		if (arg instanceof ObjectIdentifier) {
		    idToUsesAsArg.remove(arg, var);
		}
	    }
	} else if (var instanceof GenFuncAppVar) {
	    Object arg = ((GenFuncAppVar) var).arg();
	    if (arg instanceof ObjectIdentifier) {
		idToUsesAsArg.remove(arg, var);
	    }
	}

	// Value is no longer used as value for var
	idToUsesAsValue.remove(oldValue, var);
    }

    /**
     * Ensures that the given variable is supported in this partial world 
     * (that is, all its active parents are instantiated) and if it is 
     * a BasicVar, it is instantiated as well.  If this process requires 
     * choosing new values for some variables, the given ValueChooser object 
     * is used to get the necessary values.  
     *
     * <p>Unless the given variable is an unrepresented derived
     * variable, this method also determines the active parents of the
     * given variable and updates the graph so that edges come into
     * this variable from exactly those parents.
     *
     * @return the (possibly new) value of the given variable in this partial 
     *         world
     *
     * @throws UnsupportedOperationException if this partial world is not 
     *                                       modifiable
     */
    /*
    public Object ensureInstAndSupported(BayesNetVar var, 
					 ValueChooser chooser) {
	ParentsAndValue pAndV = var.ensureInstAndSupported(this, chooser);
	Set newParents = pAndV.getParents();

	if (nodeInfo.containsKey(var)) {
	    // Variable is in the graph, have to update parents
	    NodeInfo varInfo = (NodeInfo) nodeInfo.get(var);
	    
	    // Disconnect from former parents
	    for (Iterator iter = varInfo.parents.iterator(); 
		 iter.hasNext(); ) {
		BayesNetVar parent = (BayesNetVar) iter.next();
		if (!newParents.contains(parent)) {
		    ((NodeInfo) nodeInfo.get(parent)).children.remove(var);
		}
	    }

	    // Connect to new parents
	    for (Iterator iter = newParents.iterator(); iter.hasNext(); ) {
		BayesNetVar parent = (BayesNetVar) iter.next();
		if (!varInfo.parents.contains(parent)) {
		    ((NodeInfo) nodeInfo.get(parent)).children.add(var);
		}
	    }

	    // Change parent set
	    varInfo.parents = newParents;
	}

	return pAndV.getValue();
    }
    */

    public DGraph getBayesNet() {
	updateParentSets();
	return bayesNet;
    }

    /**
     * Returns a Map from the instantiated BayesNetVar objects to the values 
     * of those variables.
     */
    protected Map getVarValues() {
	return varValues;
    }

    /**
     * Returns a Map from the ObjectIdentifiers that are used in this 
     * partial world to the NumberVar objects that they 
     * necessarily satisfy.  An identifier is mapped to null if it does not 
     * necessarily satisfy any number variable.
     */
    protected Map getIdToNumberVarMap() {
	return idToNumberVar;
    }

    /**
     * Returns a MultiMap from NumberVar objects to the identifiers 
     * (ObjectIdentifier objects) that necessarily satisfy them in 
     * this partial world.  
     */
    protected MultiMap getNumberVarToIdsMap() {
	return numberVarToIds;
    }

    /**
     * Returns a map from Type objects to the identifiers
     * (ObjectIdentifier objects) of that type that may satisfy some
     * number variable, but do not necessarily satisfy any particular
     * number variable because some of their generating functions are
     * not instantiated.
     */
    protected MultiMap getUnsourcedIdsMap() {
	return unsourcedIds;
    }

    /**
     * Returns a MultiMap from ObjectIdentifier to the BayesNetVars that 
     * have this identifier as a value.
     */
    protected MultiMap getIdToUsesAsValueMap() {
	return idToUsesAsValue;
    }

    /**
     * Returns a MultiMap from ObjectIdentifier to BayesNetVars that 
     * have this identifier as an argument.
     */
    protected MultiMap getIdToUsesAsArgMap() {
	return idToUsesAsArg;
    }

    // Private inner class for the object returned by getSaved()
    private class SavedPartialWorld extends AbstractPartialWorld {

	SavedPartialWorld(Model model, Set idTypes) {
	    super(model, idTypes);
	}

	public DGraph getBayesNet() {
	    return savedBayesNet;
	}

	protected Map getVarValues() {
	    return savedVarValues;
	}

	protected Map getIdToNumberVarMap() {
	    return savedIdToNumberVar;
	}

	protected MultiMap getNumberVarToIdsMap() {
	    return savedNumberVarToIds;
	}

	protected MultiMap getUnsourcedIdsMap() {
	    return savedUnsourcedIds;
	}

	protected MultiMap getIdToUsesAsValueMap() {
	    return savedIdToUsesAsValue;
	}

	protected MultiMap getIdToUsesAsArgMap() {
	    return savedIdToUsesAsArg;
	}
    }

    // Data structures holding saved version of world.  
    // See AbstractPartialWorld for descriptions of these maps

    Map savedVarValues = new HashMap(); 
    Map savedIdToNumberVar = new HashMap(); 
    MultiMap savedNumberVarToIds = new HashMultiMap();
    MultiMap savedUnsourcedIds = new HashMultiMap();
    MutableDGraph savedBayesNet = new MutableDGraph();

    // Data structures holding current version of world, 
    // represented as a collection of changes to saved version
    
    MapDiff varValues = new HashMapDiff(savedVarValues);
    MapDiff idToNumberVar = new HashMapDiff(savedIdToNumberVar);
    MultiMapDiff numberVarToIds 
	= new HashMultiMapDiff(savedNumberVarToIds);
    MultiMapDiff unsourcedIds = new HashMultiMapDiff(savedUnsourcedIds);
    ParentUpdateDGraph bayesNet = new ParentUpdateDGraph(savedBayesNet);

    SavedPartialWorld savedWorld;

    // Data structure to facilitate batched updating of parent sets
    Set varsWithDirtyParentSets = new HashSet();

    // Data structures to facilitate detecting unused identifiers
    // Map object identifiers to BayesNetVar objects where they're used 
    // as a value and BayesNetVar objects where they're used as an argument
    MultiMap savedIdToUsesAsValue = new HashMultiMap();
    MultiMap savedIdToUsesAsArg = new HashMultiMap();

    MultiMapDiff idToUsesAsValue = new HashMultiMapDiff(savedIdToUsesAsValue);
    MultiMapDiff idToUsesAsArg = new HashMultiMapDiff(savedIdToUsesAsArg);
}
