/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import java.io.PrintStream;
import common.Util;

/** Stores the information extracted from evidence file. The evidence is of 
 * 2 kinds:
 * <ul>
 *      <li> symbol evidence statements, which introduce the objects of the 
 *           specified type that satisfy the stated condition;
 *      <li> value evidence statements, which specify the value of a term.
 * </ul>
 *
 * An Evidence object serves two purposes.  First, it defines a set of 
 * Skolem constants, which are additional constant symbols that can be used 
 * in the evidence and query files.  Second, it defines a set of evidence 
 * variables and an observed value for each of these variables.  The evidence 
 * variables may be basic variables or other random variables created to 
 * represent the evidence.  For example, if we have a value evidence 
 * statement:
 * <blockquote>
 * height(mother(John)) = 13.7
 * </blockquote>
 * then the evidence object creates a new random variable whose value is 
 * the value of the term height(mother(John)).  
 *
 * @see   blog.SymbolEvidenceStatement
 * @see   blog.ValueEvidenceStatement
 */ 
public class Evidence{ 


    /**
     * Creates a new Evidence object with no evidence.
     */
    public Evidence( ){

    }


    public void addSymbolEvidence( SymbolEvidenceStatement sevid ){
	symbol_evidence.add( sevid );
	for (Iterator iter = sevid.getSkolemConstants().iterator(); 
	     iter.hasNext(); ) {
	    SkolemConstant c = (SkolemConstant) iter.next();
	    skolemConstants.put(c.getName(), c);
	}

	recordEvidence(sevid.getObservedVar(), sevid.getObservedValue(), 
		       sevid);
    }

    /**
     * Returns an unmodifiable Collection of SymbolEvidenceStatement objects.
     */
    public Collection getSymbolEvidence( ){
	return Collections.unmodifiableCollection(symbol_evidence);
    }


    public void addValueEvidence( ValueEvidenceStatement evid ){

	value_evidence.add( evid );
	recordEvidence(evid.getObservedVar(), evid.getObservedValue(), 
		       evid);
    }
   

    /**
     * Returns an unmodifiable Collection of ValueEvidenceStatement objects.
     */
    public Collection getValueEvidence( ){
	return Collections.unmodifiableCollection(value_evidence);
    }

    /**
     * Returns the SkolemConstant object for the given symbol, or null if 
     * no such Skolem constant has been introduced.
     */
    public SkolemConstant getSkolemConstant(String name) {
	return (SkolemConstant) skolemConstants.get(name);
    }

    /**
     * Returns the set of evidence variables for which the user has 
     * observed values.
     *
     * @return an unmodifiable Set of BayesNetVar objects
     */
    public Set getEvidenceVars() {
	return Collections.unmodifiableSet(observedValues.keySet());
    }

    /**
     * Returns the observed value of the given variable.  
     *
     * @throws IllegalArgumentException if no value has been observed 
     *                                  for the given variable
     */
    public Object getObservedValue(BayesNetVar var) {
	if (!observedValues.containsKey(var)) {
	    throw new IllegalArgumentException("No observed value for " + var);
	}
	
	return observedValues.get(var);
    }

    /**
     * Returns true if the given partial world is complete enough to 
     * determine whether this evidence is true or false.
     */
    public boolean isDetermined(PartialWorld w) {
	for (Iterator iter = symbol_evidence.iterator(); iter.hasNext(); ) {
	    SymbolEvidenceStatement stmt 
		= (SymbolEvidenceStatement) iter.next();
	    if (!stmt.isDetermined(w)) {
		return false;
	    }
	}

	for (Iterator iter = value_evidence.iterator(); iter.hasNext(); ) {
	    ValueEvidenceStatement stmt
		= (ValueEvidenceStatement) iter.next();
	    if (!stmt.isDetermined(w)) {
		return false;
	    }
	}

	return true;
    }

    /**
     * Returns true if this evidence is true in the given world; otherwise 
     * false.
     */
    public boolean isTrue(PartialWorld w) {
	for (Iterator iter = symbol_evidence.iterator(); iter.hasNext(); ) {
	    SymbolEvidenceStatement stmt 
		= (SymbolEvidenceStatement) iter.next();
	    if (!stmt.isTrue(w)) {
		return false;
	    }
	}

	for (Iterator iter = value_evidence.iterator(); iter.hasNext(); ) {
	    ValueEvidenceStatement stmt
		= (ValueEvidenceStatement) iter.next();
	    if (!stmt.isTrue(w)) {
		return false;
	    }
	}

	return true;
    }

    /**
     * Prints the evidence to the given stream.
     */
    public void print(PrintStream s) {
	for (Iterator iter = observedValues.entrySet().iterator(); 
	     iter.hasNext(); ) {
	    Map.Entry entry = (Map.Entry) iter.next();
	    System.out.println(entry.getKey() + ": " + entry.getValue());
	}
    }

    private void recordEvidence(BayesNetVar observedVar, Object observedValue, 
				Object source) {
	if (observedValues.containsKey(observedVar)) {
	    Object existingValue = observedValues.get(observedVar);
	    if (!existingValue.equals(observedValue)) {
		Util.fatalError("Evidence \"" + source + "\" contradicts "
				+ "earlier evidence.", true, true);
	    }
	} else {
	    observedValues.put(observedVar, observedValue);
	}
    }

    public double getEvidenceProb(PartialWorld curWorld) {
	double evidenceProbProduct = 1;
	Set evidenceVars = getEvidenceVars();
	for( Iterator iter = evidenceVars.iterator(); iter.hasNext(); ){
	    BayesNetVar var = (BayesNetVar) iter.next();
	    if (getObservedValue(var).equals(var.getValue(curWorld))) {
		evidenceProbProduct *= var.getProbOfValue(curWorld);
	    } else {
		// The value of this variable in curWorld is not the
		// observed value.
		evidenceProbProduct *= 0;
	    }
	}
	return evidenceProbProduct;
    }

    public double getEvidenceLogProb(PartialWorld curWorld) {
	double evidenceLogSum = 0;
	Set evidenceVars = getEvidenceVars();
	for( Iterator iter = evidenceVars.iterator(); iter.hasNext(); ){
	    BayesNetVar var = (BayesNetVar) iter.next();
	    if (getObservedValue(var).equals(var.getValue(curWorld))) {
		evidenceLogSum += Math.log(var.getProbOfValue(curWorld));
	    } else {
		// The value of this variable in curWorld is not the
		// observed value.
		evidenceLogSum += Double.NEGATIVE_INFINITY; 
		//implies that the actual probability is 0 
	    }
	}
	return evidenceLogSum;
    }

    // List of SymbolEvidenceStatement
    private List symbol_evidence = new ArrayList();
 
    // List of ValueEvidenceStatement
    private List value_evidence = new ArrayList();  
    
    // map from String to SkolemConstant
    private Map skolemConstants = new HashMap(); 

    // map from BayesNetVar to Object
    private Map observedValues = new HashMap();
}


