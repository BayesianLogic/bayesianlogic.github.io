/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

/**
 * Data structure that stores the set of active parents of a random variable, 
 * as well as the variable's value.  The random variable may be a basic 
 * random variable or a derived variable like a formula or argument 
 * specification.
 *
 * <p>We have this class because for a derived random variable, the algorithm 
 * for finding its active parents is essentially the same as the algorithm 
 * for determining its value.  Thus, it makes sense to have one function 
 * determine both pieces of information and return them in a ParentsAndValue 
 * object.  
 */
public class ParentsAndValue {
    /**
     * Creates a new ParentsAndValue object with the given parent set and 
     * value.
     *
     * @param parents a Set of BasicVar objects
     * @param value   an arbitrary object representing the value
     */
    public ParentsAndValue(Set parents, Object value) {
	this.parents = parents;
	this.value = value;
    }

    /**
     * Returns the set of active parents of the random variable in question.
     *
     * @return a Set of BasicVar objects
     */
    public Set getParents() {
	return parents;
    }

    /**
     * Returns the value of the random variable in question.
     */
    public Object getValue() {
	return value;
    }

    private Set parents;
    private Object value;
}
