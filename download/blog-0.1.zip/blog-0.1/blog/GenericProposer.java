/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import common.Util;
import common.MultiMap;
import common.HashMultiMap;

/**
 * Implements a generic MCMC proposal algorithm.  Each step changes
 * the value of exactly one instantiated RV (selected uniformly at
 * random from the instantiated RVs), then samples values for 
 * previously uninstantiated RVs to make the resulting instantiation
 * self-supporting.  It also uninstantiates any RVs that become barren.  
 *
 * <p>Without identifiers, the forward proposal probability is just the 
 * probability of choosing the selected variable to change, times the 
 * product of the probabilities of values sampled (for that variable 
 * and any other variables that must be instantiated to make the 
 * instantiation self-supporting).  The backward probability is the 
 * probability of choosing the same variable again, choosing its old 
 * value, and re-instantiating all the newly uninstantiated variables 
 * to their old values.  No other moves can yield the same proposed 
 * world because each move changes the value of exactly one instantiated 
 * variable (it just instantiates and uninstantiates other variables).  
 *
 * <p>Each variable is sampled from its prior distribution given its parents.  
 * GenericProposer cannot handle settings where identifiers are used for 
 * a type with generating functions, because generating function application 
 * variables do not have probability models, and thus cannot be sampled 
 * in a straightforward way.  
 *
 * <p>Computing the forward and backward proposal probabilities also
 * becomes more complicated with identifiers.  We assume that in the
 * world passed to <code>proposeNextState</code>, each identifier is
 * the value of some ground term; the GenericProposer maintains this
 * property (otherwise things would get extremely complicated).
 * GenericProposer adds a new identifier to the proposed world when it
 * calls <code>sampleVal</code> on a CPD and gets a
 * <code>RemainingObjSet</code> back.  The probability of this
 * happening depends on the size of the <code>RemainingObjSet</code>.
 * Also, sampling a new identifier is equivalent (i.e., yields an
 * equivalent partial world) to sampling an existing identifier that is 
 * only used as a value for that same variable or variables that will 
 * be uninstantiated.  
 *
 * <p>To take into account this effect without worrying about the order in 
 * which variables are instantiated, we maintain sets of identifiers that 
 * have uses added or removed.  We then multiply adjustment factors into 
 * the forward and backward probabilities to take into account the 
 * probabilities of sampling something equivalent to these identifiers.  
 *
 * <p>The GenericProposer constructor looks at the following properties 
 * in the properties table that is passed in:
 * <dl>
 * <dt>idTypes
 * <dd>Comma-separated list of names of types.  Non-guaranteed objects 
 *     of these types will be represented by interchangeable identifiers 
 *     rather than by tuples.  The value can also be "none", indicating 
 *     that no objects should be represented by identifiers, or "all", 
 *     indicating that all non-guaranteed objects should be represented 
 *     by identifiers.  Default: "none".  
 * </dl>
 * The properties table is also passed to the constructor for the 
 * sampler that generates the initial state, which is an LWSampler.  
 */
public class GenericProposer implements Proposer {

    /**
     * Creates a new GenericProposer that proposes possible worlds for the 
     * given model.  The properties table specifies configuration 
     * parameters.  
     */
    public GenericProposer(Model model, Properties properties) {
	this.model = model;

	String idTypesString = properties.getProperty("idTypes", "none");
	idTypes = model.getListedTypes(idTypesString);
	if (idTypes == null) {
	    Util.fatalError("Fatal error: invalid idTypes list.", false, true);
	}

	if (!idTypes.isEmpty()) {
	    System.out.print("Using identifiers for types:");
	    for (Iterator iter = idTypes.iterator(); iter.hasNext(); ) {
		Type type = (Type) iter.next();
		System.out.print(" " + type);
	    }
	    System.out.println();
	}

	initialStateSampler = new LWSampler(model, properties);
    }

    /**
     * Set up the initial state.  We repeatedly sample a world until we 
     * get one where the observed values of the evidence variables have 
     * positive probability.  
     */
    public MutablePartialWorld getInitialState(Evidence evidence, 
					       List queries) {
	this.evidence = evidence;
	evidenceVars = evidence.getEvidenceVars();
	numBasicEvidenceVars = 0;
	for (Iterator iter = evidenceVars.iterator(); iter.hasNext(); ) {
	    if (iter.next() instanceof BasicVar) {
		numBasicEvidenceVars++;
	    }
	}

	this.queries = queries;
	queryVars = new HashSet();
	for(Iterator iter=queries.iterator(); iter.hasNext(); ) {
	    queryVars.add(((Query)iter.next()).getVariable());
	}

	++numTrials;
	numInitialStateTriesThisTrial = 0;
	initialStateSampler.initialize(evidence, queries);

	while (true) {
	    initialStateSampler.nextSample();
	    PartialWorld initWorld = initialStateSampler.getLatestWorld();
	    ++totalNumInitialStateTries;
	    ++numInitialStateTriesThisTrial;

	    if (initialStateSampler.getLatestWeight() > 0) {
		if (Main.verbose()) {
		    System.out.println("Probability of " +
				       numInitialStateTriesThisTrial +
				       "th initial state = " +
				       initialStateSampler.getLatestWeight());
		    initWorld.print(System.out);
		}

		return new MutablePartialWorld(model, idTypes, initWorld);
	    } else {  // world is inconsistent with evidence, try again
		if (Main.verbose()) {
		    System.out.println(numInitialStateTriesThisTrial + 
				       "th initial world rejected.");
		}
	    }
	}
    }

    /**
     * Proposes a next state for the Markov chain given the current state.  
     * The proposedWorld argument is a MutablePartialWorld that the proposer 
     * can modify to create the proposal; the saved version stored within 
     * this MutablePartialWorld is the state before the proposal.  Returns 
     * the log proposal ratio:
     *    log (q(x | x') / q(x' | x))
     */
    public double proposeNextState(MutablePartialWorld world) {
	if (evidence == null) {
	    throw new IllegalStateException
		("getInitialState has not been called on proposer.");
	}

	Set eligibleVars = new HashSet(world.getInstantiatedVars());
	eligibleVars.removeAll(evidenceVars);

	logProbForward = 0;
	logProbBackward = 0;
	idsWithUsesAdded.clear();
	idsWithUsesRemoved.clear();
	
	// Uniformly sample a random variable from the support network.
	BasicVar varToSample = (BasicVar) Util.uniformSample(eligibleVars);

	// Multiply in the probability of this uniform sample.
	logProbForward += (-Math.log(eligibleVars.size()));

	// Sample value for variable and update forward and backward probs
	sampleValue(varToSample, world);
	
	// Remove barren variables
	LinkedList newlyBarren = new LinkedList(world.getNewlyBarrenVars());
	while (!newlyBarren.isEmpty()) {
	    BayesNetVar var = (BayesNetVar) newlyBarren.removeFirst();
	    if(!evidenceVars.contains(var) && !queryVars.contains(var)) {

		// Remember its parents.
		Set parentSet = world.getBayesNet().getParents(var);

		// Multiply in the probability of sampling this
		// variable again. Since the parent value may have
		// changed, must use the old world.
		logProbBackward 
		    += Math.log(var.getProbOfValue(world.getSaved()));
		useRemoved(world, world.getValue(var));

		// Uninstantiate
		world.uninstantiate(var);

		// Check to see if its parents are now barren.
		for(Iterator parentIter = parentSet.iterator();
		    parentIter.hasNext(); ) {

		    // If parent is barren, add to the end of this
		    // linked list. Note that if a parent has two
		    // barren children, it will only be added to the
		    // end of the list once, when the last child is
		    // considered.
		    BayesNetVar parent = (BayesNetVar) parentIter.next();
		    if(world.getBayesNet().getChildren(parent).isEmpty())
			newlyBarren.addLast(parent);
		}
	    }
	}

	// Remove any identifiers that are no longer used in new world
	removeUnusedIdentifiers(world);
	
	// Adjust for sampling identifiers
	logProbForward += getIdSamplingLogAdjust(world, 
						 world.getSaved(), world, 
						 idsWithUsesAdded);
	logProbBackward += getIdSamplingLogAdjust(world, 
						  world, world.getSaved(), 
						  idsWithUsesRemoved);

	// Uniform sampling from new world.
	logProbBackward += (-Math.log(world.getInstantiatedVars().size()
				      - numBasicEvidenceVars));
	return (logProbBackward - logProbForward);
    }
    
    public void printStats() {
	System.out.println("===== GenericProposer Stats ====");
	System.out.println("Initial world attempts: " 
			   + numInitialStateTriesThisTrial);
	if (numTrials > 0) {
	    System.out.println
		("\tRunning average (for trials so far): " +
		 (totalNumInitialStateTries / (double) numTrials));
	}
    }

    // Samples a new value for the given variable (which must be
    // supported in <code>world</code>) and sets this new value as the
    // value of the variable in <code>world</code>.  Then ensures that
    // <code>world</code> is self-supporting by calling
    // ensureInstAndSupported on each of the variable's children.  Also 
    // updates the logProbForward and logProbBackward variables.  
    private void sampleValue(BasicVar varToSample, 
			     MutablePartialWorld world) {
	// Save child set before graph becomes out of date
	Set children = world.getBayesNet().getChildren(varToSample);

	ParentsAndValue info = varToSample.getParentsAndCPD
	    (world, ValueChooser.NO_INSTANTIATION);

	List cpdAndArgs = (List) info.getValue();
	CondProbDistrib cpd = (CondProbDistrib) cpdAndArgs.get(0);
	List cpdArgs = cpdAndArgs.subList(1, cpdAndArgs.size());

	Object oldValue = world.getValue(varToSample);
	logProbBackward += Math.log(cpd.getProb(cpdArgs, oldValue));
	useRemoved(world, oldValue);

	Object newValue = cpd.sampleVal(cpdArgs, varToSample.getType());
	if (newValue instanceof RemainingObjSet) {
	    RemainingObjSet s = (RemainingObjSet) newValue;
	    newValue = world.addIdentifierForPOPApp
		(s.getPOP(), s.getGenObjs());
	}
	world.setValue(varToSample, newValue);
	logProbForward += Math.log(cpd.getProb(cpdArgs, newValue));
	useAdded(world, newValue);

	// Make the world self-supporting.  The only variables whose active 
	// parent sets could have changed are the children of varToSample.
	ConditionalSampler chooser = new ConditionalSampler();
     
	for (Iterator childrenIter = children.iterator(); 
	     childrenIter.hasNext(); ) {
	    BayesNetVar child = (BayesNetVar) childrenIter.next();
	    child.ensureInstAndSupported(world, chooser);

	}
	
	logProbForward += chooser.getLogProbability();
	for (Iterator iter = chooser.getObjsWithUsesAdded().iterator();
	     iter.hasNext(); ) {
	    useAdded(world, iter.next());
	}
    }

    private void removeUnusedIdentifiers(MutablePartialWorld world) {
	for (Iterator iter = world.getChangedVars().iterator(); 
	     iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    if (world.getSaved().isInstantiated(var)) {
		removeIfUnused(world, world.getSaved().getValue(var));
	    }
	}

	for (Iterator iter = world.getUninstantiatedVars().iterator(); 
	     iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    removeIfUnused(world, world.getSaved().getValue(var));
	}
    }
	
    void removeIfUnused(MutablePartialWorld world, Object o) {
	if ((o instanceof ObjectIdentifier)
	    && world.isValidObject(o)
	    && world.getVarsWithValue(o).isEmpty()) {
	    world.removeIdentifier((ObjectIdentifier) o);
	    if (Main.verbose()) {
		System.out.println("Removed unused identifier " + o);
	    }
	}
    }

    private double getIdSamplingLogAdjust(MutablePartialWorld proposal, 
					  PartialWorld from, 
					  PartialWorld to, 
					  MultiMap maybeNewIds) {
	double logAdjust = 0;
	for (Iterator popAppIter = maybeNewIds.entrySet().iterator(); 
	     popAppIter.hasNext(); ) {
	    Map.Entry entry = (Map.Entry) popAppIter.next();
	    NumberVar nv = (NumberVar) entry.getKey();
	    Set ids = (Set) entry.getValue();
	    
	    // An ID is new if it is not used by any variable in "from" 
	    // that remains unchanged.
	    int numNew = 0;
	    for (Iterator idIter = ids.iterator(); idIter.hasNext(); ) {
		ObjectIdentifier id = (ObjectIdentifier) idIter.next();
		if (!isUsedByUnchangedVar(proposal, id)) {
		    ++numNew;
		}
	    }

	    // Figure out the number of ways to choose something equivalent 
	    // to the first new ID.
	    int numPersistentIds 
		= (to.getSatisfyingIds(nv.pop(), nv.args()).size() - numNew);
	    int numWithoutPersistentId 
		= Math.max(0, (to.getNumSatisfiers(nv.pop(), nv.args()) 
			       - numPersistentIds));
	    
	    // Add in the log adjustment
	    logAdjust += Util.logPartialFactorial(numWithoutPersistentId, 
						  numNew);
	}

	if (Main.verbose()) {
	    System.out.println("Identifier sampling adjustment: " + 
			       Math.exp(logAdjust));
	}
	return logAdjust;
    }

    private boolean isUsedByUnchangedVar(MutablePartialWorld world, 
					 ObjectIdentifier id) {
	Set vars = world.getVarsWithValue(id);
	for (Iterator iter = vars.iterator(); iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    if (world.isInstantiated(var) 
		&& world.getSaved().isInstantiated(var)
		&& (world.getValue(var).equals
		    (world.getSaved().getValue(var)))) {
		return true; // var is unchanged and has id as value
	    }
	}
	return false;
    }

    private void useAdded(PartialWorld world, Object val) {
	if (val instanceof ObjectIdentifier) {
	    ObjectIdentifier id = (ObjectIdentifier) val;

	    NumberVar popApp = world.getPOPAppSatisfied(id);
	    if (popApp == null) {
		throw new IllegalStateException
		    ("Identifier satisfies no POP app: " + id);
	    }
	    idsWithUsesAdded.add(popApp, id);
	}
    }

    private void useRemoved(PartialWorld world, Object val) {
	if (val instanceof ObjectIdentifier) {
	    ObjectIdentifier id = (ObjectIdentifier) val;

	    NumberVar popApp = world.getPOPAppSatisfied(id);
	    if (popApp == null) {
		throw new IllegalStateException
		    ("Identifier satisfies no POP app: " + id);
	    }
	    idsWithUsesRemoved.add(popApp, id);
	}
    }

    private Model model;
    private Set idTypes;
    private Sampler initialStateSampler;

    private Evidence evidence = null;
    private List queries; // of Query

    private Set evidenceVars;
    private int numBasicEvidenceVars;
    private Set queryVars;

    private double logProbForward;
    private double logProbBackward;

    // MultiMaps from NumberVar to ObjectIdentifiers
    private MultiMap idsWithUsesAdded = new HashMultiMap();
    private MultiMap idsWithUsesRemoved = new HashMultiMap();

    private int numTrials = 0;
    private int totalNumInitialStateTries = 0;
    private int numInitialStateTriesThisTrial = 0;
}
