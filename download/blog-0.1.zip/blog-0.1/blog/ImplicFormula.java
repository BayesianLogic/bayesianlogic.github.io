/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

/**
 * An implication formula alpha -> beta.  It is true if alpha is false or 
 * beta is true.  
 */
public class ImplicFormula extends Formula {

    /**
     * Creates a new ImplicFormula of the form antecedent -> consequent.
     */
    public ImplicFormula(Formula antecedent, Formula consequent) {
	this.antecedent = antecedent;
	this.consequent = consequent;
    }

    /**
     * Returns the antecedent (lefthand side) of this formula.
     */
    public Formula getAntecedent() {
	return antecedent;
    }

    /**
     * Returns the consequent (righthand side) of this formula.
     */
    public Formula getConsequent() {
	return consequent;
    }

    /**
     * Returns the active parents and value of this formula in the 
     * given partial world.  If the world is not complete enough to 
     * evaluate this formula, uses the given ValueChooser object to 
     * instantiate the necessary basic variables.  If the world is 
     * not complete enough and the ValueChooser is null, this method 
     * returns null. 
     */
    public ParentsAndValue getParentsAndValue(PartialWorld w, 
					      Assignment a, 
					      ValueChooser chooser) {
	Set parentSet = new HashSet();
	
	ParentsAndValue anteInfo 
	    = antecedent.getParentsAndValue(w, a, chooser);
	if (anteInfo == null) {
	    return null;
	}
	parentSet.addAll(anteInfo.getParents());
	if (((Boolean) anteInfo.getValue()).booleanValue()) {
	    // antecedent is true
	    // in this case, implication is true iff consequent is true
	    ParentsAndValue consInfo
		= consequent.getParentsAndValue(w, a, chooser);
	    if (consInfo == null) {
		return null;
	    }
	    parentSet.addAll(consInfo.getParents());
	    return new ParentsAndValue(parentSet, consInfo.getValue());
	}

	// antecedent is false
	// implication is vacuously true
	return new ParentsAndValue(parentSet, Boolean.TRUE);
    }

    /**
     * The standard form of an implication formula phi -> psi is 
     * the standard form of the equivalent formula !phi | psi.
     */
    public Formula getStandardForm() {
	Formula equiv = new DisjFormula(new NegFormula(antecedent), 
					consequent);
	return equiv.getStandardForm();
    }

    /**
     * The formula equivalent to the negation of phi -> psi is phi & !psi.
     */
    public Formula getEquivToNegation() {
	return new ConjFormula(antecedent, new NegFormula(consequent));
    }

    public List getSubFormulas() {
	List subFormulas = new ArrayList();
	subFormulas.add(antecedent);
	subFormulas.add(consequent);
	return Collections.unmodifiableList(subFormulas);
    }

    /**
     * The CNF form of an implication phi -> psi is the CNF form of 
     * the equivalent formula !phi | psi.
     */
    public ConjFormula getPropCNF() {
	Formula equiv = new DisjFormula(new NegFormula(antecedent), 
					consequent);
	return equiv.getPropCNF();
    }

    /**
     * The DNF form of an implication phi -> psi is the DNF form of 
     * the equivalent formula !phi | psi.
     */
    public DisjFormula getPropDNF() {
	Formula equiv = new DisjFormula(new NegFormula(antecedent), 
					consequent);
	return equiv.getPropDNF();
    }	

    public boolean equals(Object o) {
	if (o instanceof ImplicFormula) {
	    ImplicFormula other = (ImplicFormula) o;
	    return (antecedent.equals(other.getAntecedent())
		    && consequent.equals(other.getConsequent()));
	}
	return false;
    }

    public int hashCode() {
	return (getClass().hashCode() ^ antecedent.hashCode() 
		^ consequent.hashCode());
    }

    public String toString() {
	return (antecedent + " -> " + consequent);
    }

    public boolean checkTypesAndScope(Map scope) {
	return (antecedent.checkTypesAndScope(scope) 
		&& consequent.checkTypesAndScope(scope));
    }

    private Formula antecedent;
    private Formula consequent;
}
