/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

/**
 * Iterates over objects that satisfy some condition in a partial
 * world.  If the partial world is not complete enough to determine
 * what object should be returned next (or whether there are any more
 * objects left to return), the ObjectIterator instantiates the
 * necessary random variables.  For this reason, implementations of
 * ObjectIterator will typically take a ValueChooser object as an
 * argument to their constructors.
 *
 * <p>Ideally, if the set of objects being iterated over is finite with 
 * probability 1 (under the current BLOG model), then with probability 1 this 
 * iterator's <code>hasNext</code> method will eventually return false.  
 * However, if we're trying to iterate over the objects that satisfy some 
 * complicated condition, it may be difficult to enumerate all these objects 
 * without internally enumerating all the objects in some larger, possibly 
 * infinite set (and selecting the ones that satisfy the condition).  So all 
 * we require is that implementations make an effort to avoid infinite 
 * loops when the desired set is finite.  
 */
public interface ObjectIterator extends Iterator {

    /**
     * Returns the set of basic variables which, if they changed, might 
     * cause this iterator to behave differently than it has so far.  
     * In other words, if the parent variables had different values, 
     * this iterator might return different values for the sequence of 
     * calls to <code>next</code> and <code>hasNext</code> that have 
     * been made so far.
     *
     * @return a Set of BasicVar objects
     */
    Set getParents();

    /**
     * Returns true if this ObjectIterator is running on a partial world 
     * this is complete enough to determine what the next object is, 
     * or if the ObjectIterator has a non-null ValueChooser to instantiate 
     * the necessary random variables.  If <code>hasNext</code> is called 
     * when <code>canComputeNext</code> would return false, then 
     * <code>hasNext</code> returns false.  
     */
    boolean canComputeNext();

    /**
     * Dummy ObjectIterator whose <code>canComputeNext</code> and 
     * <code>hasNext</code> methods always return false.  Can be used as 
     * an error indicator.
     */
    public static final ObjectIterator STUCK_ITER = new ObjectIterator() {
	    public boolean hasNext() {
		return false;
	    }

	    public Object next() {
		throw new NoSuchElementException();
	    }

	    public void remove() {
		throw new UnsupportedOperationException();
	    }

	    public Set getParents() {
		return Collections.EMPTY_SET;
	    }

	    public boolean canComputeNext() {
		return false;
	    }
	};

}
