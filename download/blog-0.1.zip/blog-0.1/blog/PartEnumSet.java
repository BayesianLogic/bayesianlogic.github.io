/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import common.Util;

/**
 * A partially enumerated set.  It consists of a set of explicitly 
 * enumerated elements, plus a set of RemainingObjSet objects representing 
 * unenumerated subsets.  
 */
public class PartEnumSet implements PartialWorld.IdentifierListener {
    /**
     * Creates a new, empty PartEnumSet.
     */
    public PartEnumSet(PartialWorld w) {
	this.w = w;
    }

    /**
     * Returns true if the given object is in this set.  Of course, in 
     * order to be passed in, <code>o</code> must be explicitly represented.
     */
    public boolean contains(Object o) {
	return elements.contains(o);
    }

    /**
     * Returns true if the given partially enumerated set is a subset of 
     * this one.
     */
    public boolean isSubset(PartEnumSet subset) {
	Iterator subIter = subset.iterator();
	while (subIter.hasNext()) {
	    Object o = subIter.next();
	    if (!contains(o)) {
		return false;  // Same RemainingObjSet is also required
	    }
	}

	return true;

    }

    /** 
     * Returns the total number of objects in this set, both explicitly 
     * enumerated and implicitly represented.
     */
    public int size() {
	return totalSize;
    }

    /**
     * Returns true if this set has size zero.
     */
    public boolean isEmpty() {
	return (totalSize == 0);
    }

    /**
     * Returns true if the given object is a PartEnumSet with the same 
     * elements as this one.
     */
    public boolean equals(Object o) {
	if (o instanceof PartEnumSet) {
	    PartEnumSet other = (PartEnumSet) o;
	    return (isSubset(other) && other.isSubset(this));
	}
	return false;
    }

    /**
     * Adds a single object to this set.
     */
    public void add(Object o) {
	elements.add(o);
	totalSize++;
    }

    /**
     * Adds a subset to this set.  
     */
    public void addSubset(RemainingObjSet s) {
	elements.add(s);
	totalSize += s.size();
	w.addIdentifierListener(s.getPOP(), s.getGenObjs(), this);
    }

    /**
     * Returns an iterator over the explicitly enumerated objects in this 
     * set and the RemainingObjSet objects representing subsets.
     */
    private Iterator iterator() {
	return elements.iterator();
    }

    /**
     * Returns a representation of an element sampled uniformly at
     * random from this set.  The object returned may be an actual
     * element, or a RemainingObjSet indicating that an arbitrary
     * element of that RemainingObjSet was chosen.  If this set is
     * empty, returns null.
     */
    public Object sample() {
	int r = Util.randInt(totalSize);
	
	for (Iterator iter = elements.iterator(); iter.hasNext(); ) {
	    Object elt = iter.next();
	    int size = (elt instanceof RemainingObjSet) ? 
		((RemainingObjSet) elt).size() : 1;
	    r -= size;
	    if (r < 0) {
		return elt;
	    }
	}

	return null;
    }

    public void identifierAdded(ObjectIdentifier id) {
	elements.add(id);
	totalSize++;
    }

    public void identifierRemoved(ObjectIdentifier id) {
	elements.remove(id);
	totalSize--;
    }

    public String toString() {
	return elements.toString();
    }

    int totalSize = 0;
    Set elements = new HashSet();
    PartialWorld w;
}
