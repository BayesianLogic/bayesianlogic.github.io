/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

/**
 * Class with static methods and constants for built-in non-random 
 * functions (including built-in constants).  This class cannot be 
 * instantiated.
 */
public class BuiltInFunctions {
    /**
     * Constant that always denotes Model.NULL.
     */
    public static final NonRandomConstant NULL
	= new NonRandomConstant("null", BuiltInTypes.NULL, Model.NULL);

    /**
     * Constant that denotes the natural number 0.  The parser 
     * creates NonRandomConstant objects as needed to represent numeric 
     * constants that it actually encounters in a file, but some internal 
     * compilation code may need to use this constant even if it doesn't 
     * occur in a file.  
     */
    public static final NonRandomConstant ZERO 
	= new NonRandomConstant("0", BuiltInTypes.NATURAL_NUM, new Integer(0));

    /**
     * Constant that denotes the natural number 1.  The parser 
     * creates NonRandomConstant objects as needed to represent numeric 
     * constants that it actually encounters in a file, but some internal 
     * compilation code may need to use this constant even if it doesn't 
     * occur in a file.  
     */
    public static final NonRandomConstant ONE
	= new NonRandomConstant("1", BuiltInTypes.NATURAL_NUM, new Integer(1));

    /**
     * The LessThan relation on integers.
     */
    public static NonRandomFunction LT;

    /**
     * The LessThanOrEqual relation on integers.
     */
     public static NonRandomFunction LEQ;

    /**
     * The GreaterThan relation on integers.
     */
    public static NonRandomFunction GT;

    /**
     * The GreaterThanOrEqual relation on integers.
     */
    public static NonRandomFunction GEQ;

    /**
     * The function on integers <code>x<code>, <code>y</code> that returns 
     * x + y.
     */
    public static NonRandomFunction PLUS;

    /**
     * The function on integers <code>x<code>, <code>y</code> that returns 
     * x - y.
     */
    public static NonRandomFunction MINUS;


    private BuiltInFunctions() {
	// prevent instantiation
    }

    /**
     * Returns the built-in function (or constant) with the given name.  
     * Returns null if there is no such built-in function, or if the given 
     * name is a numeric, character, or string literal that is only 
     * created as needed by the parser.  
     */
    public static Function getFunction(String name) {
	return (Function) functions.get(name);
    }

    /**
     * Returns true if there is a built-in function (or constant with the 
     * given name).  Returns false if there is no such built-in function, 
     * or if the name is a numeric, character, or string literal that is 
     * only created as needed by the parser.
     */
    public static boolean exists(String name) {
	return functions.containsKey(name);
    }

    private static void addFunction(Function f) {
	functions.put(f.getName(), f);
    }

    static Map functions = new HashMap(); // from String to Function

    static {
	// Add non-random constants
	addFunction(NULL);
	addFunction(ZERO);
	addFunction(ONE);

	// Add non-random functions from integer x integer to Boolean
	List argTypes = new ArrayList();
	argTypes.add(BuiltInTypes.INTEGER);
	argTypes.add(BuiltInTypes.INTEGER);
	Type retType = BuiltInTypes.BOOLEAN;

	LT = new NonRandomFunction("LessThan", argTypes, retType) {
		public Object getValue(List args) {
		    Integer arg1 = (Integer) args.get(0);
		    Integer arg2 = (Integer) args.get(1);
		    return (arg1.intValue() < arg2.intValue()) ?
			Boolean.TRUE : Boolean.FALSE;
		}
	    };
	addFunction(LT);

	LEQ = new NonRandomFunction("LessThanOrEqual", argTypes, retType) {
		public Object getValue(List args) {
		    Integer arg1 = (Integer) args.get(0);
		    Integer arg2 = (Integer) args.get(1);
		    return (arg1.intValue() <= arg2.intValue()) ?
			Boolean.TRUE : Boolean.FALSE;
		}
	    };
	addFunction(LEQ);

	GT = new NonRandomFunction("GreaterThan", argTypes, retType) {
		public Object getValue(List args) {
		    Integer arg1 = (Integer) args.get(0);
		    Integer arg2 = (Integer) args.get(1);
		    return (arg1.intValue() > arg2.intValue()) ?
			Boolean.TRUE : Boolean.FALSE;
		}
	    };
	addFunction(GT);

	GEQ = new NonRandomFunction("GreaterThanOrEqual", argTypes, retType) {
		public Object getValue(List args) {
		    Integer arg1 = (Integer) args.get(0);
		    Integer arg2 = (Integer) args.get(1);
		    return (arg1.intValue() >= arg2.intValue()) ?
			Boolean.TRUE : Boolean.FALSE;
		}
	    };
	addFunction(GEQ);

	// Add non-random functions from integer x integer to integer
	retType = BuiltInTypes.INTEGER;

	PLUS = new NonRandomFunction("Sum", argTypes, retType) {
		public Object getValue(List args) {
		    Integer arg1 = (Integer) args.get(0);
		    Integer arg2 = (Integer) args.get(1);
		    return new Integer(arg1.intValue() + arg2.intValue());
		}
	    };
	addFunction(PLUS);

	MINUS = new NonRandomFunction("Diff", argTypes, retType) {
		public Object getValue(List args) {
		    Integer arg1 = (Integer) args.get(0);
		    Integer arg2 = (Integer) args.get(1);
		    return new Integer(arg1.intValue() - arg2.intValue());
		}
	    };
	addFunction(MINUS);
    }
}
