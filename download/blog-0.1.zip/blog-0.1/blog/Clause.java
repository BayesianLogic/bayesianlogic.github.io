/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;


/** Represents a clause in dependency statements and number statements. 
 *
 * Each clause has a predicate, a conditional probability distribution (CPD), 
 * and a list of arguments to this conditional probability distribution. Each
 * argument is assumed to be of class ArgSpec. If the condition is checked and 
 * turns out to be true, then the arguments are evaluated and the CPD is used
 * to sample a value for these arguments.
 *
 * @see blog.WrappedClass
 */
public class Clause extends WrappedClass{

    /**
     * @param cpdArgs List of ArgSpec objects passed to the CPD
     */
    public Clause( List cpdArgs, Formula cond, CondProbDistrib cpd ){

	this.cond = cond;
	this.cpd = cpd;
	this.cpdArgs = cpdArgs;
    }

    /**
     * @return List of ArgSpec objects
     */
    public List getArgs( ){

	return cpdArgs;

    }


    public Formula getCond( ){

	return cond;

    }


    public CondProbDistrib getCPD( ){

	return cpd;

    }

    /**
     * Returns the active parent set, CPD, and CPD argument values for this 
     * clause in the given partial world.  The parent set is the union 
     * of the active parent sets of all the CPD arguments.  If the given 
     * partial world is not complete enough to determine the values of the 
     * CPD arguments, then <code>chooser</code>'s 
     * <code>chooseValue</code> method will be called to get values for the 
     * necessary variables; if <code>chooser</code> is null, then this 
     * method returns null.  
     *
     * @return a ParentsAndValue object where the parents are the parents 
     *          of the CPD arguments, and the value is a List whose 
     *          first element is the CPD, and whose remaining 
     *          elements are the CPD argument values.
     */
    public ParentsAndValue getParentsAndCPD(PartialWorld w, 
					    Assignment a,
					    ValueChooser chooser) {
	Set parentSet = new HashSet();
	List cpdAndArgs = new ArrayList();
	cpdAndArgs.add(cpd);

	for (Iterator iter = cpdArgs.iterator(); iter.hasNext(); ) {
	    ArgSpec argSpec = (ArgSpec) iter.next();
	    ParentsAndValue argInfo 
		= argSpec.getParentsAndValue(w, a, chooser);
	    if (argInfo == null) {
		return null; // CPD arg not determined
	    }
	    parentSet.addAll(argInfo.getParents());
	    cpdAndArgs.add(argInfo.getValue());
	}
	
	return new ParentsAndValue(parentSet, cpdAndArgs);
    }

    public boolean checkTypesAndScope(Map scope, Type childType) {
	boolean correct = true;

	if (!cond.checkTypesAndScope(scope)) {
	    correct = false;
	}

	for (Iterator iter = cpdArgs.iterator(); iter.hasNext(); ) {
	    if (!((ArgSpec) iter.next()).checkTypesAndScope(scope)) {
		correct = false;
	    }
	}

	// The only CPD we can type-check is EqualsCPD
	if (cpd instanceof EqualsCPD) {
	    if (cpdArgs.size() == 1) {
		ArgSpec arg = (ArgSpec) cpdArgs.get(0);
		if (arg instanceof Term) {
		    Type argType = ((Term) arg).getType(scope);
		    if (!argType.isSubtypeOf(childType)) {
			typeError("Value for deterministic distribution has "
				  + "wrong type (expected " + childType
				  + ", got " + argType + ")");
			correct = false;
		    }
		} else {
		    typeError("Argument to EqualsCPD must be a term");
		}
	    } else {
		typeError("EqualsCPD takes exactly one argument");
		correct = false;
	    }
	}

	return correct;
    }

    private Formula cond;
    private CondProbDistrib cpd;        
    private List cpdArgs; // of ArgSpec
}


