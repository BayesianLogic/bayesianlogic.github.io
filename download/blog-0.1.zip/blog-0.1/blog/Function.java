/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;
import java.util.*;


/** Represents a BLOG function. A function is specified by its name, 
 * return type, and argument types.
 */

public abstract class Function extends WrappedClass {


    public Function( String fname, List arg_types, Type ret_type ){

	this.fname = fname;
	this.arg_types = arg_types;
	this.ret_type = ret_type;

    }


    public String getName( ) {

	return fname;          

    }


    public List getArgTypes( ) {

	return arg_types;

    }


    public Type getRetType( ) {

	return ret_type;

    }

    /**
     * Returns the value of this function applied to the given tuple of 
     * arguments in the given partial world.  If the given partial world 
     * is not complete enough to determine the function value, this 
     * method uses the given ValueChooser to extend the world.  Any 
     * random variables used to determine the function value are added 
     * to the given parent set.
     *
     * @param parents  modifiable Set of BayesNetVar.  May be null, in 
     *                 which case no parents are added.  
     *
     * @throws IllegalArgumentException if some of the given arguments 
     *                                  do not exist in the given partial 
     *                                  world
     */
    public abstract Object getValueInWorld(List args, PartialWorld w, 
					   ValueChooser chooser, Set parents);

    /**
     * Returns a list where each IdentifierHook in the given argument
     * list has been replaced with the identifier it corresponds to.
     * If the list contains IdentifierHooks without identifiers, this
     * method uses the given ValueChooser to add identifiers to the
     * world.  If this occurs when the ValueChooser is null, this method 
     * returns null.  
     */
    protected static List getSpecificArgs(List args, PartialWorld w, 
					  ValueChooser chooser) {
	List specArgs = new ArrayList(args);
	for (ListIterator iter = specArgs.listIterator(); iter.hasNext(); ) {
	    Object arg = iter.next();
	    if (arg instanceof IdentifierHook) {
		IdentifierHook hook = (IdentifierHook) arg;
		if (hook.getIdentifier() == null) {
		    if (chooser == null) {
			return null;
		    }
		    chooser.addIdentifierForHook(w, hook);
		}
		iter.set(hook.getIdentifier());
	    }
	}
	return specArgs;
    }

    /**
     * Returns the value that this function returns when one of its 
     * arguments is null.  This is Boolean.FALSE for Boolean functions, and 
     * Model.NULL for all other functions.
     */
    public Object getDefaultValue() {
	if (ret_type == BuiltInTypes.BOOLEAN) {
	    return Boolean.FALSE;
	}
	return Model.NULL;
    }

    /**
     * Two functions are equal if they have the same name and the same 
     * argument types.
     */
    public boolean equals(Object o) {
	if (o instanceof Function) {
	    Function other = (Function) o;
	    return (fname.equals(other.getName()) 
		    && arg_types.equals(other.getArgTypes()));
	}
	return false;
    }

    public int hashCode() {
	return (fname.hashCode() ^ arg_types.hashCode());
    }

    /**
     * Returns this function's name.
     */
    public String toString() {
	return fname;
    }

    private String fname;
    private List arg_types;
    private Type ret_type;

}

