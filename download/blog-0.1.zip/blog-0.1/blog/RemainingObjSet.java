/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

/**
 * Represents the set of objects that satisfy a particular POP application in 
 * a world, but are not pointed to by any identifiers in that world.  
 * RemainingObjSet does not implement the Set interface because it doesn't 
 * support iteration.  However, you can get the size of a RemainingObjSet, 
 * and you can see whether it equals another RemainingObjSet (that is, 
 * whether it has the same size and corresponds to the same POP application).  
 * Any two RemainingObjSets that are not equal are disjoint. 
 */
public class RemainingObjSet {
    public RemainingObjSet(POP pop, List genObjs, PartialWorld w) {
	this.pop = pop;
	this.genObjs = genObjs;
	this.w = w;
    }

    public Type getType() {
	return pop.getType();
    }

    public POP getPOP() {
	return pop;
    }

    public List getGenObjs() {
	return genObjs;
    }

    public int size() {
	return w.getNumSatisfiersWithoutIds(pop, genObjs);
    }

    /**
     * Returns the value of the given generating function on the objects 
     * in this set.
     */
    public Object getGenFuncValue(GeneratingFunction genFunc) {
	int index = pop.getGenFuncIndex(genFunc);
	if (index >= 0) {
	    return genObjs.get(index);
	}

	// genFunc is not used in POP that generated these objects
	return Model.NULL; 
    }

    public boolean equals(Object o) {
	if (o instanceof RemainingObjSet) {
	    RemainingObjSet other = (RemainingObjSet) o;
	    return (pop.equals(other.getPOP())
		    && genObjs.equals(other.getGenObjs())
		    && (size() == other.size()));
	}
	return false;
    }

    public int hashCode() {
	return (pop.hashCode() ^ genObjs.hashCode());
    }

    public String toString() {
	StringBuffer buf = new StringBuffer();
	buf.append("[" + size() + " " + pop.getType() + " : ");

	for (int i = 0; i < genObjs.size(); ++i) {
	    buf.append(pop.getGeneratingFunctions().get(i));
	    buf.append(" -> ");
	    buf.append(genObjs.get(i));
	    if (i < genObjs.size() - 1) {
		buf.append(", ");
	    }
	}

	buf.append("]");
	return buf.toString();
    }

    POP pop;
    List genObjs;
    PartialWorld w;
}
