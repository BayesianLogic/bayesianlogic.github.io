/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import java.io.PrintStream;


/** Represents dependency statements for functions and number
 * statements for potential object patterns. It consists of a list of
 * clauses the dependency/number statement consists of.  Each
 * DependencyModel also has a default value: if none of the clauses
 * are satisfied, then the child variable has the default value with
 * probability 1.  The default value is Boolean.FALSE for Boolean
 * functions, null for all other functions, and Integer(0) for POPs.
 *
 * @see blog.Function
 * @see blog.POP
 */
public class DependencyModel {


    public DependencyModel(List cl, Object defaultVal ){

	clause_lst = cl;
	this.defaultVal = defaultVal;

    }


    public List getClauseList( ) {

	return clause_lst;

    }

    public Object getDefaultValue() {
	return defaultVal;
    }

    /**
     * Ensures that this dependency model applied to the given tuple of 
     * child argument values is <i>supported</i> in the given 
     * partial world: that is, enough variables are instantiated so that we 
     * can tell which clause of this dependency model is applicable and 
     * determine the values of the CPD arguments in that clause.  If new 
     * variables need to be instantiated, this method uses the given 
     * ValueChooser object to do so.  If the dependency model is 
     * not supported and the ValueChooser is null, then this method 
     * returns null.  
     *
     * @return a ParentsAndValue object where the parents are the parents 
     *          of the dependency model, and the value is a List whose 
     *          first element is the applicable CPD, and whose remaining 
     *          elements are the CPD arguments.
     */
    public ParentsAndValue getParentsAndCPD(PartialWorld w, 
					    Assignment a, 
					    ValueChooser chooser) {
	Set parentSet = new HashSet();

	for (Iterator iter = clause_lst.iterator(); iter.hasNext(); ) {
	    Clause clause = (Clause) iter.next();
	    ParentsAndValue condInfo 
		= clause.getCond().getParentsAndValue(w, a, chooser);
	    if (condInfo == null) {
		return null; // condition's truth value not determined
	    }
	    parentSet.addAll(condInfo.getParents());

	    if (((Boolean) condInfo.getValue()).booleanValue()) {
		// This is the first satisfied clause
		ParentsAndValue clauseInfo 
		    = clause.getParentsAndCPD(w, a, chooser);
		if (clauseInfo == null) {
		    return null; // CPD args not determined
		}
		parentSet.addAll(clauseInfo.getParents());
		return new ParentsAndValue(parentSet, clauseInfo.getValue());
	    }
	}

	// None of the clauses are satisfied.
	List cpdAndArgs = new ArrayList();
	cpdAndArgs.add(new EqualsCPD());
	cpdAndArgs.add(Collections.singletonList(defaultVal));
	return new ParentsAndValue(parentSet, cpdAndArgs);	
    }

    /**
     * Prints this dependency model to the given stream.  Each clause is 
     * printed on a separate line, and each line is indented 1 tab.  The 
     * first clause begins with "if"; all subsequent clauses begin with 
     * "elseif".
     */
    public void print(PrintStream s) {
	for (int i = 0; i < clause_lst.size(); ++i) {
	    Clause c = (Clause) clause_lst.get(i);
	    s.print("\t");
	    if (i > 0) {
		s.print("else");
	    }
	    s.print("if ");
	    s.print(c.getCond());
	    s.print(" then ~ ");
	    s.print(c.getCPD().getClass());
	    s.print("(");

	    Iterator argsIter = c.getArgs().iterator();
	    if (argsIter.hasNext()) {
		s.print(argsIter.next());
		while (argsIter.hasNext()) {
		    s.print(", ");
		    s.print(argsIter.next());
		}
	    }

	    s.println(")");
	}
    }

    public boolean checkTypesAndScope(Map scope, Type childType) {
	Iterator iter = clause_lst.iterator();
	while (iter.hasNext()) {
	    Clause c = (Clause) iter.next();
	    if (!c.checkTypesAndScope(scope, childType)) {
		return false;
	    }
	}
	return true;
    }

    /**
     * Returns the number of DependencyModel objects created before this one.  
     */
    public int getCreationIndex() {
	return creationIndex;
    }

    private List clause_lst; // of Clause
    private Object defaultVal;
    private int creationIndex = DependencyModel.numCreated++;

    private static int numCreated = 0;
}

