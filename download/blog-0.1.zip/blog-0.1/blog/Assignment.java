/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;


/** Assignment is a reference frame with respect to which Formulas and Terms 
 * are evaluated. It contains a map from variable identifiers to values. 
 */
public class Assignment {

    /**
     * Creates an empty assignment.
     */
    public Assignment() {
	this.var_val = new HashMap();
    }

    /** Initializes the map. */
    public Assignment( Map var_val ){

	this.var_val = var_val;

    }

    /**
     * Creates a copy of the given assignment.
     */
    public Assignment(Assignment a) {
	var_val = new HashMap();
	for (Iterator iter = a.iterator(); iter.hasNext(); ) {
	    Map.Entry e = (Map.Entry) iter.next();
	    var_val.put(e.getKey(), e.getValue());
	}
    }

    /** 
     * Adds an identifier-value pair to the map. If this Assignment already 
     * contains a value for var, the old value is overwritten.  
     */
    public void add( String var, Object val ){

	var_val.put( var, val );

    }     

    /**
     * Adds mappings from each identifier in <code>vars</code> to the 
     * corresponding value in <code>vals</code>.  If this Assignment 
     * already contains a value for some of <code>vars</code>, the 
     * old values are overwritten.
     *
     * @throws IllegalArgumentException if <code>vars</code> and 
     *                                  <code>vals</code> have different sizes
     */
    public void addTupleBinding(List vars, List vals) {
	if (vars.size() != vals.size()) {
	    throw new IllegalArgumentException
		("Arguments to Assignment.addTupleBinding must be of equal "
		 + "sizes.");
	}
		
	for (int i = 0; i < vars.size(); ++i) {
	    add((String) vars.get(i), vals.get(i));
	}
    }

    /** Retrieves the value bound to the specified identifier. 
     *
     * @throws IllegalArgumentException if no value is assigned to the 
     *                                  given identifier.
     **/ 
    public Object getVal( String a ){

	if( var_val.containsKey( a ) )
	    return var_val.get(a);
	else{
	    throw new IllegalArgumentException
		("No value assigned to variable " + a + ".");
	}
    }

    /**
     * Returns an iterator over Map.Entry objects representing the elements 
     * of this Assignment.  The key of each entry is a String representing 
     * a variable name, and the value is an object.
     */
    public Iterator iterator() {
	return var_val.entrySet().iterator();
    }

    public String toString() {
	return var_val.toString();
    }

    /** The map containing the arguments. */
    private Map var_val;

}



