/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import java.io.PrintStream;

import common.MultiMap;
import common.WeakHashSet;

/**
 * An implementation of the PartialWorld interface that relies on some 
 * basic data structures returned by protected methods (which a concrete 
 * subclass must implement).  A concrete subclass must also implement the 
 * public <code>getBayesNet</code> method, which returns a DGraph.  
 */
public abstract class AbstractPartialWorld implements PartialWorld {
    /**
     * Creates a new partial world for the given model.  Identifiers 
     * will be used to represent the user-defined types in the set 
     * idTypes.
     *
     * @param idTypes  Set of Type objects
     */
    public AbstractPartialWorld(Model model, Set idTypes) {
	this.model = model;
	this.idTypes = idTypes;
    }

    public Model getModel(){
	return model;
    }

    /**
     * Returns the set of object identifiers used in this PartialWorld.
     *
     * @return unmodifiable Set of ObjectIdentifier objects
     */
    public Set getIdentifiers() {
	return Collections.unmodifiableSet(getIdToNumberVarMap().keySet());
    }

    /**
     * Returns true if the given variable is instantiated in this 
     * partial world.  If the given variable refers to objects that do 
     * not necessarily exist in this partial world, the method just 
     * returns false.
     */
    public boolean isInstantiated(BayesNetVar var) {
	return getVarValues().containsKey(var);
    }

    /**
     * Returns an unmodifiable Set representing the set of variables that 
     * are instantiated in this world.
     */
    public Set getInstantiatedVars() {
	return Collections.unmodifiableSet(getVarValues().keySet());
    }

    /**
     * Returns the value of the given variable in this partial world.  
     *
     * @throws IllegalArgumentException if the given variable is not 
     *                                  instantiated in this world
     */
    public Object getValue(BayesNetVar var) {
	if (!getVarValues().containsKey(var)) {
	    throw new IllegalArgumentException
		("Variable not instantiated: " + var);
	}
	return getVarValues().get(var);
    }

    /**
     * Returns the value of the given function applied to the given 
     * tuple of objects in this world.  Returns null if some of the 
     * given arguments do not exist in this world.  
     *
     * @throws IllegalArgumentException if this PartialWorld is not complete 
     *                                  enough to specify the desired value
     */
    public Object getFuncValue(Function func, List args) {
	if (!areValidObjects(args)) {
	    return null;
	}

	if (func instanceof NonRandomFunction) {
	    return ((NonRandomFunction) func).getValue(args);
	} else if (func instanceof GeneratingFunction) {
	    Object singleArg = args.get(0);
	    if (singleArg instanceof NonGuaranteedObject) {
		return ((NonGuaranteedObject) singleArg).
		    getGenFuncValue((GeneratingFunction) func);
	    } else if (singleArg instanceof ObjectIdentifier) {
		GenFuncAppVar var 
		    = new GenFuncAppVar((GeneratingFunction) func, 
					(ObjectIdentifier) singleArg);
		return getValue(var); 
	    } else {
		return Model.NULL; // guaranteed object
	    }
	}

	// Default case: random function
	RandFuncAppVar var = new RandFuncAppVar((RandomFunction) func, args);
	return getValue(var);
    }

    /**
     * Returns the number of objects that satisfy the given POP
     * application in this world.  This is the value of the
     * corresponding number variable, not the number of identifiers in
     * the world that satisfy this POP.  If some of the given
     * generating objects do not exist, then the return value is zero.
     *
     * @param pop               a potential object pattern
     * @param generatingObjects a List of Objects
     *
     * @throws IllegalStateException if all the given generating objects 
     *                               exist in this world, but the 
     *                               corresponding number variable is 
     *                               not instantiated
     */
    public int getNumSatisfiers(POP pop, List generatingObjects) {
	if (!areValidObjects(generatingObjects)) {
	    return 0;
	}

	// Create the NumberVar object for this POP and gen. objects.
	BasicVar var = new NumberVar(pop, generatingObjects);

	// Get the value from this world and return the integer value.
	return ((Integer) getValue(var)).intValue();
    }

    /**
     * Returns the set of objects that satisfy the given POP in this
     * world.  The objects may be represented as actual objects or
     * identifiers, depending on the way this PartialWorld
     * implementation handles objects of the relevant type.  If the
     * objects are represented as identifiers and the number of
     * identifiers in the world that satisfy the POP is less than the
     * value of the corresponding number variable, then the returned 
     * set contains an IdentifierHook object representing the remaining 
     * objects.  
     *
     * <p>The set returned by this method will remain correct if new 
     * identifiers are added or new random variables are instantiated.  
     * It will not remain correct if identifiers are removed or 
     * already-instantiated random variables are changed.  
     *
     * @param pop                a potential object pattern
     * @param generatingObjects  a List of Objects
     *
     * @throws IllegalStateException if all the given generating objects 
     *                               exist in the world, but the corresponding 
     *                               number variable is not instantiated
     */
    public Set getSatisfiers(POP pop, List generatingObjects) {
	Set unsourcedIds = (Set) getUnsourcedIdsMap().get(pop.getType());
	if (!unsourcedIds.isEmpty()) {
	    throw new IllegalStateException
		("Some identifiers of type " + pop.getType() + " do not have "
		 + "all their generating functions instantiated.");
	}

	if (!areValidObjects(generatingObjects)) {
	    return Collections.EMPTY_SET;
	}

	if (generatingObjects.contains(Model.NULL)) {
	    return Collections.EMPTY_SET;
	}

	NumberVar var = new NumberVar(pop, generatingObjects);
	if (!isInstantiated(var)) {
	    throw new IllegalStateException
		("Number variable not instantiated: " + var);
	}

	if (idTypes.contains(pop.getType())) {
	    return new SatisfierSet(pop, generatingObjects);
	}    
	return new NonGuarObjSet(pop, generatingObjects);
    }

    /**
     * Returns the set of identifiers that satisfy the given POP application 
     * in this world.  This is an empty set if some of the given generating 
     * objects do not exist, or if this partial world does not use 
     * identifiers for the relevant type of object.  
     *
     * @param pop               a potential object pattern
     * @param generatingObjects a List of Objects
     *
     * @return unmodifiable Set of ObjectIdentifier
     *
     * @throws IllegalStateException if there are some identifiers of the 
     *                               type generated by this POP that do 
     *                               not have all their generating functions 
     *                               instantiated, and thus may or may not 
     *                               satisfy this POP application
     */
    public Set getSatisfyingIds(POP pop, List generatingObjects) {
	Set unsourcedIds = (Set) getUnsourcedIdsMap().get(pop.getType());
	if (!unsourcedIds.isEmpty()) {
	    throw new IllegalStateException
		("Some identifiers of type " + pop.getType() + " do not have "
		 + "all their generating functions instantiated.");
	}

	NumberVar var = new NumberVar(pop, generatingObjects);
	return (Set) getNumberVarToIdsMap().get(var);
    }

    public int getNumSatisfiersWithoutIds(POP pop, List genObjs) {
	return Math.max(0, (getNumSatisfiers(pop, genObjs) 
			    - getSatisfyingIds(pop, genObjs).size()));
    }

    /**
     * Returns true if this PartialWorld determines what POP application 
     * (if any) the given object satisfies.
     *
     * @throws IllegalArgumentException if the given object does not exist 
     *                                  in this world
     */
    public boolean isPOPAppDetermined(Object obj) {
	if (!isValidObject(obj)) {
	    throw new IllegalArgumentException
		("Object " + obj + " does not exist in world.");
	}

	if (obj instanceof NonGuaranteedObject) {
	    return true; // POP app determined by identity of object
	} 

	if (obj instanceof ObjectIdentifier) {
	    Type type = ((ObjectIdentifier) obj).getType();
	    return (!((Set) getUnsourcedIdsMap().get(type)).contains(obj));
	}

	// Must be guaranteed object, so we know it satisfies no POP app
	return true;
    }
	

    /**
     * Returns the NumberVar (i.e., POP and generating objects) such that 
     * the given objects satisfies that POP applied to those generating 
     * objects in this world.  Returns null if the given object does not 
     * satisfy any POP application.  
     *
     * @throws IllegalArgumentException if the given object does not exist 
     *                                  in this world
     *
     * @throws IllegalStateException    if the given object is an identifier 
     *                                  and this PartialWorld does not 
     *                                  specify the values of generating 
     *                                  functions on it 
     */
    public NumberVar getPOPAppSatisfied(Object obj) {
	if (!isValidObject(obj)) {
	    throw new IllegalArgumentException
		("Object " + obj + " does not exist in world.");
	}

	if (obj instanceof NonGuaranteedObject) {
	    return ((NonGuaranteedObject) obj).getNumberVar();
	} 

	if (obj instanceof ObjectIdentifier) {
	    Type type = ((ObjectIdentifier) obj).getType();
	    if (((Set) getUnsourcedIdsMap().get(type)).contains(obj)) {
		throw new IllegalStateException
		    ("Some generating functions not instantiated on " + obj);
	    }
	    return (NumberVar) getIdToNumberVarMap().get(obj);
	}

	// Must be guaranteed object, so not generated by any number var
	return null;
    }		

    public boolean isValidObject(Object obj) {
	if (obj instanceof NonGuaranteedObject) {
	    
	    NonGuaranteedObject ngObj = (NonGuaranteedObject) obj;
	    int actualNumb =
		getNumSatisfiers(ngObj.getPOP(),
				 ngObj.getGeneratingObjs());
	    
	    if(ngObj.getNumber() > actualNumb)
		return false;
	} else if (obj instanceof ObjectIdentifier) {
	    return getIdentifiers().contains(obj);
	}

	return true; // assume it's guaranteed object
    }

    public boolean areValidObjects(List objects) {
	Iterator objsIter = objects.iterator();
	while(objsIter.hasNext()) {
	    Object obj = objsIter.next( );	    	    
	    if(!isValidObject(obj)){
		return false;
	    }
	}
	return true;
    }

    /**
     * Returns the set of variables that have the given object as their 
     * value in this world.  This is done efficiently if the object is an 
     * ObjectIdentifier, and slowly (by iterating over all instantiated 
     * variables) otherwise.
     *
     * @return unmodifiable Set of BayesNetVar
     */
    public Set getVarsWithValue(Object value) {
	Set vars;

	if (value instanceof ObjectIdentifier) {
	    vars = (Set) getIdToUsesAsValueMap().get(value);
	} else {
	    vars = new HashSet();
	    for (Iterator iter = getVarValues().entrySet().iterator(); 
		 iter.hasNext(); ) {
		Map.Entry entry = (Map.Entry) iter.next();
		if (entry.getValue().equals(value)) {
		    vars.add(entry.getKey());
		}
	    }
	}

	return Collections.unmodifiableSet(vars);
    }

    /**
     * Returns the set of instantiated variables that have the given
     * object as an argument.  This is done efficiently if the object
     * is an ObjectIdentifier, and slowly (by iterating over all
     * instantiated variables) otherwise.
     *
     * @return unmodifiable Set of BayesNetVar
     */
    public Set getVarsWithArg(Object arg) {
	Set vars;

	if (arg instanceof ObjectIdentifier) {
	    vars = (Set) getIdToUsesAsArgMap().get(arg);
	} else {
	    vars = new HashSet();
	    for (Iterator iter = getVarValues().entrySet().iterator(); 
		 iter.hasNext(); ) {
		Map.Entry entry = (Map.Entry) iter.next();
		BayesNetVar var = (BayesNetVar) entry.getValue();
		if ((var instanceof BasicVar)
		    && ((BasicVar) var).args().contains(arg)) {
		    vars.add(entry.getKey());
		} else if ((var instanceof GenFuncAppVar)
			   && ((GenFuncAppVar) var).arg().equals(arg)) {
		    vars.add(entry.getKey());
		}
	    }
	}

	return Collections.unmodifiableSet(vars);
    }    

    /**
     * Prints this partial world to the given stream.
     */
    public void print(PrintStream s) {
	if (!getIdToNumberVarMap().isEmpty()) {
	    s.print("Identifiers:");
	    for (Iterator iter = getIdToNumberVarMap().keySet().iterator();
		 iter.hasNext(); ) {
		s.print(" " + iter.next());
	    }
	    s.println();
	}

	List vars = new ArrayList(getInstantiatedVars());
	Collections.sort(vars);
	for (Iterator iter = vars.iterator(); iter.hasNext(); ) {
	    BayesNetVar var = (BayesNetVar) iter.next();
	    s.println(var + " = " + getValue(var));
	    
	    //	    Set parents = getBayesNet().getParents(var);
	    //	    for (Iterator parentIter = parents.iterator(); 
	    //		 parentIter.hasNext(); ) {
	    //		s.println("\t<- " + parentIter.next());
	    //	    }
	}
    }

    /**
     * Adds the given listener to a set of weak references to objects 
     * that should be notified when an identifier begins or ceases 
     * to satisfy the given POP application.  
     *
     * <p>Currently there is no removeIdentifierListener method; a 
     * listener is removed from the listener set automatically when it 
     * is garbage-collected.  
     */ 
    public void addIdentifierListener(POP pop, List genObjs, 
				      IdentifierListener listener) {
	NumberVar var = new NumberVar(pop, genObjs);
	Set listeners = (Set) popAppListeners.get(var);
	if (listeners == null) {
	    listeners = new WeakHashSet();
	    popAppListeners.put(var, listeners);
	}
	listeners.add(listener);
    }

    /**
     * Method that a subclass should call when an identifer has just begun 
     * to satisfy a particular POP application.
     */
    protected void satisfierAdded(NumberVar popApp, ObjectIdentifier id) {
	Set listeners = (Set) popAppListeners.get(popApp);
	if (listeners != null) {
	    for (Iterator iter = listeners.iterator(); iter.hasNext(); ) {
		((IdentifierListener) iter.next()).identifierAdded(id);
	    }
	}
    }

    /**
     * Method that a subclass should call when an identifer has just ceased 
     * to satisfy a particular POP application.
     */
    protected void satisfierRemoved(NumberVar popApp, ObjectIdentifier id) {
	Set listeners = (Set) popAppListeners.get(popApp);
	if (listeners != null) {
	    for (Iterator iter = listeners.iterator(); iter.hasNext(); ) {
		((IdentifierListener) iter.next()).identifierRemoved(id);
	    }
	}
    }

    /**
     * Returns a Map from the instantiated BayesNetVar objects to the values 
     * of those variables.
     */
    abstract protected Map getVarValues();

    /**
     * Returns a Map from the ObjectIdentifiers that are used in this 
     * partial world to the NumberVar objects that they 
     * necessarily satisfy.  An identifier is mapped to null if it does not 
     * necessarily satisfy any number variable.
     *
     * <p>The default implementation returns an empty map, which is 
     * appropriate for classes that don't support identifiers.
     */
    protected Map getIdToNumberVarMap() {
	return Collections.EMPTY_MAP;
    }

    /**
     * Returns a MultiMap from NumberVar objects to the identifiers 
     * (ObjectIdentifier objects) that necessarily satisfy them in 
     * this partial world.  
     *
     * <p>The default implementation returns a multi-map that maps all 
     * keys to the empty set, which is appropriate for classes that don't 
     * support identifiers.  
     */
    protected MultiMap getNumberVarToIdsMap() {
	return MultiMap.EMPTY_MULTI_MAP;
    }

    /**
     * Returns a map from Type objects to the identifiers
     * (ObjectIdentifier objects) of that type that may satisfy some
     * number variable, but do not necessarily satisfy any particular
     * number variable because some of their generating functions are
     * not instantiated.
     *
     * <p>The default implementation returns a multi-map that maps all 
     * keys to the empty set, which is appropriate for classes that don't 
     * support identifiers.
     */
    protected MultiMap getUnsourcedIdsMap() {
	return MultiMap.EMPTY_MULTI_MAP;
    }

    /**
     * Returns a MultiMap from ObjectIdentifier to the BayesNetVars that 
     * have this identifier as a value.
      *
     * <p>The default implementation returns a multi-map that maps all 
     * keys to the empty set, which is appropriate for classes that don't 
     * support identifiers.
     */
    protected MultiMap getIdToUsesAsValueMap() {
	return MultiMap.EMPTY_MULTI_MAP;
    }

    /**
     * Returns a MultiMap from ObjectIdentifier to BayesNetVars that 
     * have this identifier as an argument.
      *
     * <p>The default implementation returns a multi-map that maps all 
     * keys to the empty set, which is appropriate for classes that don't 
     * support identifiers.
     */
    protected MultiMap getIdToUsesAsArgMap() {
	return MultiMap.EMPTY_MULTI_MAP;
    }

    /**
     * Inner class representing the set of identifiers, and objects
     * with no identifier, that satisfy a particular POP application.
     * This set is backed by the partial world, so it changes when the
     * set of objects that satisfy the POP application changes.
     */
    private class SatisfierSet extends AbstractSet {
	SatisfierSet(POP pop, List genObjs) {
	    this.pop = pop;
	    this.genObjs = genObjs;
	}

	/**
	 * Returns either the number of identifiers in the world that 
	 * satisfy the relevant POP application, or the value of the 
	 * number variable for the relevant POP application, whichever 
	 * is larger.
	 */
	public int size() {
	    return Math.max(getSatisfyingIds(pop, genObjs).size(), 
			    getNumSatisfiers(pop, genObjs));
	}

	public Iterator iterator() {
	    return new SatisfierSetIterator();
	}

	public boolean contains(Object o) {
	    return (getSatisfyingIds(pop, genObjs).contains(o));
	}

	private class SatisfierSetIterator implements Iterator, 
                                                      IdentifierListener {
	    SatisfierSetIterator() {
		identifiers = new ArrayList(getSatisfyingIds(pop, genObjs));
		AbstractPartialWorld.this.addIdentifierListener(pop, genObjs, 
								this);
	    }

	    public boolean hasNext() {
		if (!valid) {
		    throw new ConcurrentModificationException
			("Satisfier removed from POP app during iteration.");
		}

		if (nextIndex < identifiers.size()) {
		    return true;
		}
		return isIdHookNeeded();
	    }

	    public Object next() {
		if (!hasNext()) {
		    throw new NoSuchElementException();
		}

		if (nextIndex < identifiers.size()) {
		    return identifiers.get(nextIndex++);
		}

		// If hasNext() returns true but there are no more 
		// identifiers, we must need to return an identifier hook
		returnedIdHookSinceLastAddition = true;
		IdentifierHook hook = new IdentifierHook(pop, genObjs);
		AbstractPartialWorld.this.addIdentifierListener(pop, genObjs, 
								hook);
		return hook;
	    }

	    public void remove() {
		throw new UnsupportedOperationException
		    ("Can't remove from SatisfierSet iterator.");
	    }

	    public void identifierAdded(ObjectIdentifier id) {
		identifiers.add(id);
		returnedIdHookSinceLastAddition = false;
	    }

	    public void identifierRemoved(ObjectIdentifier id) {
		valid = false;
	    }

	    private boolean isIdHookNeeded() {
		return ((getNumSatisfiers(pop, genObjs) 
			 > getSatisfyingIds(pop, genObjs).size())
			&& !returnedIdHookSinceLastAddition);
	    }

	    List identifiers;
	    int nextIndex = 0;
	    boolean returnedIdHookSinceLastAddition = false;
	    boolean valid = true;
	}

	private POP pop;
	private List genObjs;
    }

    /**
     * Inner class representing the set of non-guaranteed objects (tuple 
     * representations) that satisfy a particular POP application.  It is 
     * backed by the partial world, so it changes if the relevant 
     * number variable changes.  
     */
    private class NonGuarObjSet extends AbstractSet {
	NonGuarObjSet(POP pop, List genObjs) {
	    this.pop = pop;
	    this.genObjs = genObjs;
	}

	public int size() {
	    return getNumSatisfiers(pop, genObjs);
	}

	public Iterator iterator() {
	    return new NonGuarObjIterator();
	}

	public boolean contains(Object o) {
	    if (o instanceof NonGuaranteedObject) {
		NonGuaranteedObject obj = (NonGuaranteedObject) o;
		return (obj.getPOP().equals(pop)
			&& obj.getGeneratingObjs().equals(genObjs)
			&& (obj.getNumber() 
			    <= getNumSatisfiers(pop, genObjs)));
	    }
	    return false;
	}

	private class NonGuarObjIterator implements Iterator {
	    public boolean hasNext() {
		return (nextIndex <= n);
	    }

	    public Object next() {
		if (!hasNext()) {
		    throw new NoSuchElementException();
		}

		return new NonGuaranteedObject(pop, genObjs, nextIndex++);
	    }

	    public void remove() {
		throw new UnsupportedOperationException
		    ("Can't remove from NonGuarObjSet iterator.");
	    }
	    
	    int nextIndex = 1;
	    int n = getNumSatisfiers(pop, genObjs);
	}

	private POP pop;
	private List genObjs;
    }

    protected Model model;
    private Set idTypes;

    // from NumberVar to WeakHashSet of IdentifierListeners
    private Map popAppListeners = new HashMap(); 
}
