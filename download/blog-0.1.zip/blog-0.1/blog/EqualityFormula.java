/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

/** Represents an equality test on 2 expressions, each of which is a 
 * non-boolean-valued Term.
 *
 * @see blog.Formula
 */
public class EqualityFormula extends Formula{

    
    public EqualityFormula( Term eq1, Term eq2 ){
	
	this.eq1 = eq1;
	this.eq2 = eq2;

    }


    public Term getTerm1( ){

	return eq1;

    }


    public Term getTerm2( ){

	return eq2;

    }


    /**
     * Returns the active parents and value of this formula in the 
     * given partial world.  If the world is not complete enough to 
     * evaluate this formula, uses the given ValueChooser object to 
     * instantiate the necessary basic variables.  If the world is 
     * not complete enough and the ValueChooser is null, this method 
     * returns null. 
     */
    public ParentsAndValue getParentsAndValue(PartialWorld w, 
					      Assignment a, 
					      ValueChooser chooser) {
	Set parentSet = new HashSet();

	ParentsAndValue t1Info = eq1.getParentsAndValue(w, a, chooser);
	if (t1Info == null) {
	    return null;
	}
	parentSet.addAll(t1Info.getParents());
	
	ParentsAndValue t2Info = eq2.getParentsAndValue(w, a, chooser);
	if (t2Info == null) {
	    return null;
	}
	parentSet.addAll(t2Info.getParents());

	// Handle IdentifierHooks
	Object specific1 = t1Info.getValue();
	if (specific1 instanceof IdentifierHook) {
	    specific1 = ((IdentifierHook) specific1).getIdentifier();
	}
	Object specific2 = t2Info.getValue();
	if (specific2 instanceof IdentifierHook) {
	    specific2 = ((IdentifierHook) specific2).getIdentifier();
	}
	
	// Ensure that we have a specific value for at least one of the 
	// two terms in the equality formula
	if ((specific1 == null) && (specific2 == null)) {
	    IdentifierHook hook1 = (IdentifierHook) t1Info.getValue();
	    if (chooser == null) {
		return null;
	    }
	    chooser.addIdentifierForHook(w, hook1);
	    specific1 = hook1.getIdentifier();
	    
	    // second hook might have caught this new identifier
	    specific2 = ((IdentifierHook) t2Info.getValue()).getIdentifier();
	}

	// At this point specific1 and specific2 cannot both be null
	if ((specific1 == null) || (specific2 == null)) {
	    // One term denotes guaranteed object or identifier, and the 
	    // other denotes a non-guaranteed object with no identifier.  
	    // They can't be equal.
	    return new ParentsAndValue(parentSet, Boolean.FALSE);
	}

	Boolean value = Boolean.valueOf(specific1.equals(specific2));
	return new ParentsAndValue(parentSet, value);
    }

    /**
     * Returns true.
     */
    public boolean isLiteral() {
	return true;
    }

    public List getTopLevelTerms() {
	List terms = new ArrayList();
	terms.add(eq1);
	terms.add(eq2);
	return Collections.unmodifiableList(terms);
    }

    /**
     * Returns the term that, according to this equality formula, has the 
     * same denotation as <code>subject</code>.  Returns null if 
     * <code>subject</code> is not one of the terms in this equality.
     */  
    public Term getEqualTerm(Term subject) {
	if (eq1.equals(subject)) { 
	    return eq2;
	}
	if (eq2.equals(subject)) {
	    return eq1;
	}
	return null;
    }

    /**
     * Returns true if this equality formula asserts that <code>subject</code> 
     * has the same denotation as the constant "null".
     */
    public boolean assertsNull(Term subject) {
	return ((eq1.equals(subject) && eq2.isConstantNull())
		|| (eq2.equals(subject) && eq1.isConstantNull()));
    }

    /**
     * Two EqualityFormulas are equal if they have the same pair of terms.
     */
    public boolean equals(Object o) {
	if (o instanceof EqualityFormula) {
	    EqualityFormula other = (EqualityFormula) o;
	    return (eq1.equals(other.getTerm1())
		    && eq2.equals(other.getTerm2()));
	}
	return false;
    }

    public int hashCode() {
	return (getClass().hashCode() ^ eq1.hashCode() ^ eq2.hashCode());
    }

    /**
     * Returns a string of the form (t1 = t2) where t1 and t2 are the terms 
     * being compared in this EqualityFormula.
     */
    public String toString() {
	return ("(" + eq1 + " = " + eq2 + ")");
    }

    /**
     * An equality formula is properly typed if the type of one term is a 
     * subtype of the type of the other term.
     */
    public boolean checkTypesAndScope(Map scope) {
	if (eq1.checkTypesAndScope(scope) && eq2.checkTypesAndScope(scope)) {
	    Type t1 = eq1.getType(scope);
	    Type t2 = eq2.getType(scope);
	    if (t1.isSubtypeOf(t2) || t2.isSubtypeOf(t1)) {
		return true;
	    } else {
		typeError("Terms in equality formula are of disjoint types");
		return false;
	    }
	}
	return false;
    }	

    private Term eq1;
    private Term eq2;
}
