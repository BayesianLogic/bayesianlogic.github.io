/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import java.io.PrintStream;

/** Represents a POP number statement, consisting of the name (assumed to 
 * coincide with the name of the type for which this POP is to be used), a list
 * of types for the objects in a "generating tuple", a list of generating 
 * functions, and the number statement.
 */
public class POP extends WrappedClass {  


    public POP( ){

	argtypes = new ArrayList( );
	type = null;
	generatingFunctions = new ArrayList( );
	numberst = null;

    }

    /**
     * Creates a new potential object pattern for the given type and the 
     * given tuple of generating functions, with the given dependency 
     * model.  
     *
     * @param type                the type of object generated
     * @param generatingFunctions  List of Function objects for the generating 
     *                            functions
     * @param numberst            dependency model for this POP
     */
    public POP(Type type, List generatingFunctions, 
	       DependencyModel numberst) {

	this.type = type;
	this.generatingFunctions = generatingFunctions;
	this.numberst = numberst;
        argtypes = new ArrayList( );
	for( int i = 0; i < generatingFunctions.size( ); i++ ){
	    argtypes.add( ((Function) generatingFunctions.get( i )).getRetType( ) );
	}

    }


    public Type getType( ) {

	return type; 

    }


    public List getArgTypes( ) {

	return argtypes;

    }


    /**
     * Returns the variables that stand for the generating objects in this 
     * POP's dependency model.
     *
     * @return List of String objects representing the variables.
     */
    public List getGenObjVars() {
	if (genObjVars == null) {
	    throw new IllegalStateException
		("Generating object variables not set for " + this);
	}
	return genObjVars;
    }

    /**
     * Sets the variables that will stand for the generating objects in 
     * this POP's dependency model.
     *
     * @param vars List of String objects representing the variables
     */
    public void setGenObjVars(List vars) {
	genObjVars = vars;
    }

    public DependencyModel getDepModel( ) {   

	return numberst;

    }

    public void setDepModel(DependencyModel depModel) {
	numberst = depModel;
    }

    public List getGeneratingFunctions( ){
	
	return generatingFunctions;

    }

    /**
     * Returns the index of <code>f</code> in this POP's generating function 
     * list, or -1 if it is not in the list.
     */
    public int getGenFuncIndex(GeneratingFunction f) {
	return generatingFunctions.indexOf(f);
    }

    /**
     * Returns a BitSet where the ith bit is true if this POP uses the ith 
     * generating function in the list of generating functions for its type.
     */
    public BitSet getGenFuncSet() {
	List typeGenFuncs = type.getGeneratingFunctions();
	BitSet genFuncSet = new BitSet(typeGenFuncs.size());
	for (int i = 0; i < typeGenFuncs.size(); ++i) {
	    if (generatingFunctions.contains(typeGenFuncs.get(i))) {
		genFuncSet.set(i);
	    }
	}
	return genFuncSet;
    }

    /**
     * Prints the number statement for this POP to the given stream.
     */
    public void printNumberStatement(PrintStream s) {
	s.print("#{" + type + " : ");
	if (!generatingFunctions.isEmpty()) {
	    s.print(generatingFunctions.get(0) + " -> " + genObjVars.get(0));
	    for (int i = 1; i < generatingFunctions.size(); ++i) {
		s.print(", ");
		s.print(generatingFunctions.get(i) + " -> " 
			+ genObjVars.get(i));
	    }
	}
	s.println("}:");

	numberst.print(s); 
    }
			

    /**
     * Two POPs are equal if they have the same generated type and the 
     * same tuple of generating functions.
     */
    public boolean equals(Object o) {
	if (o instanceof POP) {
	    POP other = (POP) o;
	    return (type.equals(other.getType())
		    && generatingFunctions.equals(other.getGeneratingFunctions()));
	}
	return false;
    }

    public int hashCode() {
	return (type.hashCode() ^ generatingFunctions.hashCode());
    }

    /**
     * Returns a string of the form #{Type : f1, ..., fK} where Type is the 
     * type of object generated and f1, ..., fK are the generating functions.
     */
    public String toString() {
	StringBuffer buf = new StringBuffer();
	buf.append("#{");
	buf.append(type);
		
	if (!generatingFunctions.isEmpty()) {
	    buf.append(" : ");
	    buf.append(generatingFunctions.get(0));
	    for (int i = 1; i < generatingFunctions.size(); ++i) {
		buf.append(", ");
		buf.append(generatingFunctions.get(i));
	    }
	}

	buf.append("}");
	return buf.toString();
    }

    private List argtypes;
    private Type type;
    private List generatingFunctions; // of Function
    private List genObjVars; // of String
    private DependencyModel numberst;


}

