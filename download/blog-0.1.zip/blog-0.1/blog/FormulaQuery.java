/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.io.PrintStream;
import java.util.*;

public class FormulaQuery extends WrappedClass implements Query {


    public FormulaQuery( Formula formula ){
	this.formula = formula;

	if (Main.outputPath() != null) {
	    outputFile = Main.filePrintStream(Main.outputPath() +
					      "-trial" + trialNum + ".data");
	    /*
	    probArray = new double[Main.numSamples()/Main.outputInterval()];
	    squareProbArray =
		new double[Main.numSamples()/Main.outputInterval()];
	    for (int i = 0 ; i < probArray.length ; i++) {
		probArray[i] = 0.0;
		squareProbArray[i] = 0.0;
	    }
	    */
	}
    }

    public void printResults(PrintStream s) {
	s.println("Probability of " + formula + " is " + calculateResult());
    }

    public void outputResults(int sampleNum) {
	outputFile.println("\t" + sampleNum + "\t" + calculateResult());
    }

    /**
     * Returns the (basic or derived) variable whose value is being queried.
     */
    public BayesNetVar getVariable() {
	return formula.getVariable(new Assignment());
    }

    /**
     * Updates the within-run statistics for this query to reflect the
     * given world sampled with the given weight.
     */
    public void updateStats(PartialWorld world, double weight) {
	if (formula.isTrue(world, new Assignment())) {
	    trueSum += weight;
	} 
	totalSum += weight;
    }

    public void zeroOut(){
	runningVarSum += calculateResult();
	runningVarSumSquares += (calculateResult()*calculateResult());
	trialNum++;

	if ((outputFile != null) && (trialNum != Main.numTrials())) {
	    outputFile = Main.filePrintStream(Main.outputPath() +
					      "-trial" + trialNum + ".data");
	}

	trueSum = 0;
	totalSum = 0; 	
    }

    private double calculateResult(){
	return trueSum / totalSum;
    }

    //CAREFUL: zeroOut() must be called before using this method
    public void printVarianceResults(PrintStream s){
 
	double mean = runningVarSum / trialNum;
	s.println("Mean of " + formula + " query results is " + mean);
	s.println("Std dev of " + formula + " query results is " + 
		  Math.sqrt(runningVarSumSquares/trialNum - (mean * mean)));

    }

    /**
     * If outputting files is enabled, create a datafile with tab-separated
     * values of sample number, mean, and variance.
     *
    public void outputResults(int sampleNum) {
	probArray[sampleNum/Main.outputInterval() - 1] += calculateResult();
	squareProbArray[sampleNum/Main.outputInterval() - 1] +=
	    calculateResult() * calculateResult();
	if (numRuns == Main.numTrials()) {
	    outputFile.println("\t" + sampleNum +
			       "\t" + calculateMean(sampleNum) +
			       "\t" + calculateVariance(sampleNum));
	}
    }

    /**
     * Calculate the mean of the probability of the query at i samples.
     *
    private double calculateMean(int i) {
	return probArray[i/Main.outputInterval() - 1] / numRuns;
    }

    /**
     * Calculate the variance for the probability of the query at i samples.
     *
    private double calculateVariance(int i) {
	int sampleIndex = i/Main.outputInterval() - 1;
        return
	    squareProbArray[sampleIndex] -
	    (probArray[sampleIndex] * probArray[sampleIndex]);
    }
    */

    private Formula formula;
    private double trueSum = 0;
    private double totalSum = 0;

    private double runningVarSum = 0;
    private double runningVarSumSquares = 0;
    private int trialNum = 0;

    PrintStream outputFile = null;
    //    double[] probArray = null;
    //    double[] squareProbArray = null;
}
