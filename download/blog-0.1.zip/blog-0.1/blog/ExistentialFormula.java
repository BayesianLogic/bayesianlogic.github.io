/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import common.HashMapDiff;

/** Represents an existential instantiation for one variable satisfying 
 * an expression of type Formula.
 */
public class ExistentialFormula extends Formula{

    public ExistentialFormula( String var, Type varType, Formula cond ){

	this.var = var;
	this.varType = varType;
	this.cond = cond;

	witnessSpec = new CompiledSetSpec(varType, var, cond);
    }

    /**
     * Returns the logical variable governed by the existential quantifier 
     * in this formula.
     */
    public String getVariable() {
	return var;
    }

    /**
     * Returns the type that the existential quantifier in this formula 
     * ranges over.
     */
    public Type getType() {
	return varType;
    }

    /**
     * Returns the formula inside the existential quantifier.
     */
    public Formula getCond() {
	return cond;
    }

    /**
     * Returns the active parents and value of this formula in the 
     * given partial world.  If the world is not complete enough to 
     * evaluate this formula, uses the given ValueChooser object to 
     * instantiate the necessary basic variables.  If the world is 
     * not complete enough and the ValueChooser is null, this method 
     * returns null. 
     */
    public ParentsAndValue getParentsAndValue(PartialWorld w,
					      Assignment a,
					      ValueChooser chooser) {
	ObjectIterator iter = witnessSpec.iterator(w, a, chooser);
	if (!iter.canComputeNext()) {
	    return null;
	}
	if (iter.hasNext()) {
	    // there is a witness
	    return new ParentsAndValue(iter.getParents(), Boolean.TRUE);
	}
	return new ParentsAndValue(iter.getParents(), Boolean.FALSE);
    }

    public boolean checkTypesAndScope(Map scope) {
	Map extendedScope = new HashMapDiff(scope);
	extendedScope.put(var, varType);
	return cond.checkTypesAndScope(extendedScope);
    }

    /**
     * The standard form of an existential formula (exists x psi) is 
     * (exists x psi'), where psi' is the standard form of psi. 
     */
    public Formula getStandardForm() {
	return new ExistentialFormula(var, varType, cond.getStandardForm());
    }

    /**
     * A formula equivalent to the negation of an exisential formula 
     * (exists x psi) is (forall x !psi).
     */
    public Formula getEquivToNegation() {
	return new UniversalFormula(var, varType, new NegFormula(cond));
    }

    public List getSubformulas() {
	return Collections.singletonList(cond);
    }

    public boolean isQuantified() {
	return true;
    }

    public String toString() {
	return ("exists " + varType + " " + var + " (" + cond + ")");
    }

    public boolean equals(Object o) {
	if (o instanceof ExistentialFormula) {
	    ExistentialFormula other = (ExistentialFormula) o;
	    return (var.equals(other.getVariable())
		    && varType.equals(other.getType())
		    && cond.equals(other.getCond()));
	}
	return false;
    }

    public int hashCode() {
	return (getClass().hashCode() ^ var.hashCode() ^ varType.hashCode() 
		^ cond.hashCode());
    }

    String var;
    Type varType;
    Formula cond;

    CompiledSetSpec witnessSpec;
} 
