/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.io.*;
import java.util.*;
import java_cup.runtime.Symbol;
import common.Util;
import common.Timer;
import common.cmdline.*;

/**
 * Main program for the BLOG (Bayesian Logic) inference engine.  
 *
 * Usage:
 * <blockquote>
 * java blog.Main <i>file1 ... fileN</i>
 * </blockquote>
 *
 * Each file contains a sequence of BLOG statements.  These may be
 * declarations (specifying the model itself), evidence statements, or
 * queries.  The convention is to use one file for the model (with the
 * "mblog" suffix), one file for the evidence (with the "eblog"
 * suffix), and one file for the queries (with the "qblog" suffix).
 * The files are loaded in the order specified, so the first file must
 * be a model file.
 *
 * Optional flags:
 * <dl>
 * <dt>-r, --randomize
 * <dd>Initialize the random seed based on the clock time.  If this flag 
 *     is not given, the program uses a fixed random seed so its behavior 
 *     is reproducible.
 *     Default: false
 *
 * <dt>-e <i>classname</i>, --engine=<i>classname</i>
 * <dd>Use <i>classname</i> as the inference engine.  
 *     Default: blog.SamplingEngine
 * 
 * <dt>-n <i>num</i>, --num_samples=<i>num</i>
 * <dd>Run the sampling engine for <i>num</i> samples.  
 *     Default: 10000 samples.
 * 
 * <dt>-s <i>classname</i> --sampler=<i>classname</i>
 * <dd>Use <i>classname</i> to generate each sample.  
 *     Default: blog.LWSampler (a likelihood weighting sampler)
 *
 * <dt>-p <i>classname</i>, --proposer=<i>classname</i>
 * <dd>Use <i>classname</i> as the proposal distribution for the 
 *     Metropolis-Hastings sampler.  
 *     Default: blog.GenericProposer (samples each var given its parents)
 *
 * <dt>-g, --parser_debug
 * <dd>Print debugging messages while parsing input files.  
 *     Default: false
 *
 * <dt>-t, <i>num</i>, --num_trials=<i>num</i>
 * <dd>Do <i>num</i> independent runs (trials) of the inference algorithm.
 *     Default: 1
 *
 * <dt>--generate
 * <dd>Rather than answering queries, just sample possible worlds from the 
 *     prior distribution defined by the model, and print them out.  
 *     Default: false
 *
 * <dt>-k <i>package</i>, --package <i>package</i>
 * <dd>Look in <i>package</i> (e.g., "blog.distrib") when resolving the 
 *     names of CondProbDistrib and NonRandomFunction classes in the 
 *     model file.  This option can be included several times with different 
 *     packages; the packages are searched in the order given.  The last 
 *     places searched are the top-level package ("") and finally the 
 *     default package blog.distrib.  Note that you still need to set 
 *     the Java classpath so that it includes all these packages.  
 *
 * <dt>-v, --verbose
 * <dd>Print information about the world generated at each iteration.  Off by 
 *     default (for perfomance reasons, consider leaving this option off).
 *
 * <dt>-w <i>file-prefix</i>, --write=<i>file-prefix</i>
 * <dd>Write sampling results to file specified by this argument.  Use with the
 *     -i flag.
 *
 * <dt>-i, --interval
 * <dd>To be used with the -w option, specify the interval at which output is
 *     written.  Note that if -i and -n are the same, output is written only
 *     once, at the last iteration.
 *
 * <dt>-h <i>file-prefix</i>, --histogram_output=<i>file-prefix</i>
 * <dd>Output the histogram of an ArgSpecQuery to a file.  The results are 
 * taken after the final sample completes.
 *
 * <dt>-P<i>key</i>=<i>value</i>
 * <dd>Include the entry <i>key</i>=<i>value</i> in the properties table 
 *     that is passed to the inference engine.  This feature can be used 
 *     to set configuration parameters for various inference engines 
 *     (and the components they use, such as samplers).  See the individual 
 *     inference classes for documentation.  Note: The -P option cannot be 
 *     used to specify values for properties for which there exist 
 *     special-purpose options, such as --engine or --num_samples.      
 *
 * </dl>
 */
public class Main {
	
    public static void main(String[] args) {
	parseOptions (args);
	Util.initRandom (randomize);

	for(Iterator iter = filenames.iterator(); iter.hasNext(); ) {
	    String filename = (String) iter.next();
	    try {
		parseFile(model, evidence, queries, filename);
	    } catch (Exception e) {
		System.err.println("Error parsing file: " + filename);
		Util.fatalError(e, true, true);
	    }
	}

	// Check whether every random function has a definition
	int prelimErrors = 0;
	for( Iterator i = model.getFunctions().iterator(); i.hasNext(); ){
	    Function func = (Function) i.next();
	    if ( func instanceof RandomFunction ){
		if ( !((RandomFunction) func).hasDepModel() ){		   
		    Util.fatalError( "Random function " 
					+ func.getName() 
					+ " is missing a dependency model", 
				     false, false );
		    prelimErrors++;
	    
		}
	    }
	}

	if (Main.verbose()) {
	    // Print model for debugging
	    System.out.println("............................................");
	    model.print(System.out);
	    System.out.println("............................................");
	}

	// Run semantic check on model.  This is actually redundant now 
	// that the parser does both type-checking and scope-checking.  
	boolean semanticsCorrect = model.semanticCheck();
	if ((prelimErrors > 0) || !semanticsCorrect){
	    System.out.println("The model failed one or more checks.");
	    System.out.println("Quitting...");
	    System.exit(1);
	}

	if (Main.verbose()) {
	    // Print evidence for debugging
	    System.out.println("\nEvidence:"); 
	    evidence.print(System.out);
	}

	System.out.println("............................................");
	if (generate) {
	    generateWorlds();
	} else {
	    // Run inference for the specified number of trials
	    InferenceEngine engine 
		= InferenceEngine.constructEngine(model, inferenceProps);
	    for(int i = 0; i < numStatSamples; i++){
		printTimes(System.out, "-", 80);
		System.out.print("Trial " + i + ": ");
		
		engine.setEvidence(evidence);
		engine.setQueries(queries);
		engine.answerQueries();
		
		// Print query results
		System.out.println("======== Query Results =========");
		for (Iterator iter = queries.iterator(); iter.hasNext(); ) {
		    Query q = (Query) iter.next();
		    q.printResults(System.out);
		    q.zeroOut();
		}
		
		System.out.println();
	    }
	    
	    if (numStatSamples > 1) {
		printTimes(System.out, "=", 80);
		System.out.println("Summary of statistics for all trials:");
		for (Iterator iter = queries.iterator(); iter.hasNext(); ) {
		    Query q = (Query) iter.next();
		    q.printVarianceResults(System.out);
		}
	    }
	}

	Timer.printAllTimers();
    }

    private static void parseFile(Model model, Evidence evidence, 
				  List queries, String filename) 
	throws Exception {

	BLOGLexer lexer = new BLOGLexer(new FileReader(filename));
	lexer.set_filename(filename);
	boolean error = false;

	System.out.println("Parsing file: " + filename);
	BLOGParser parser = new BLOGParser(lexer);
	parser.setModel(model);
	parser.setEvidence(evidence);
	parser.setQueries(queries);
			
	Symbol result = doDebugParse ? parser.debug_parse() : parser.parse();
	error = (parser.omerrs > 0);
		
	if (error) {
	    System.err.println("File interpretation halted due to "
			       + "lex and parse errors");
	    System.exit(1);
	}
    }							  

    private static void generateWorlds() {
	RejectionSampler sampler = new RejectionSampler(model, inferenceProps);
	sampler.initializeCompleteSampling();

	System.out.println("Sampling " + numSamples + " worlds from prior...");
	System.out.println();
	for (int i = 0; i < numSamples; ++i) {
	    sampler.nextSample();
	    sampler.getLatestWorld().print(System.out);
	    System.out.println();
	}
    }

    private static void parseOptions (String[] args) {
	Map specialOptions = new HashMap(); // from String to Option

	BooleanOption optRandomize 
	    = new BooleanOption("r", "randomize", false, 
				"Use clock time as random seed");

	StringOption optEngine
	    = new StringOption("e", "engine", "blog.SamplingEngine", 
			       "Use inference engine class <s>");
	specialOptions.put("engineClass", optEngine);

	IntOption optNumSamples
	    = new IntOption("n", "num_samples", 10000, 
			    "Run inference engine for <n> samples");
	specialOptions.put("numSamples", optNumSamples);

	StringOption optSampler
	    = new StringOption("s", "sampler", "blog.LWSampler", 
			       "Use sampler class <s>");
	specialOptions.put("samplerClass", optSampler);
	
	StringOption optProposer
	    = new StringOption("p", "proposer", "blog.GenericProposer", 
			       "Use Metropolis-Hastings proposer class <s>");
	specialOptions.put("proposerClass", optProposer);

	BooleanOption optDebugParse
	    = new BooleanOption("g", "debug_parse", false, 
				"Print debug messages for parse errors");
	IntOption optNumTrials
	    = new IntOption("t", "num_trials", 1, 
			    "Do <n> independent runs of inference");
	BooleanOption optGenerate
	    = new BooleanOption(null, "generate", false, 
				"Sample worlds from prior and print them");
	StringListOption optPackages
	    = new StringListOption("k", "package", 
				   "Parser looks for classes in package <s>");
	BooleanOption optVerbose
	    = new BooleanOption("v", "verbose", false, 
				"Print info about every world sampled");
	StringOption optWrite
	    = new StringOption("w", "write", null, 
			       "Write sampling results to file <s>");
	IntOption optInterval
	    = new IntOption("i", "interval", 0, 
			    "Write results after every <n> samples");
	StringOption optHist
	    = new StringOption("h", "histogram_output", null, 
			       "Write histogram output to file <s>");
	PropertiesOption optInferenceProps
	    = new PropertiesOption("P", null, null, 
				   "Set inference configuration properties");
	
	filenames = common.cmdline.Parser.parse(args);
	if (filenames.isEmpty()) {
	    System.err.println("Error: no BLOG input files specified.");
	    Parser.printUsage(System.err);
	    System.exit(1);
	}

	randomize = optRandomize.getValue();
	doDebugParse = optDebugParse.getValue();
	numStatSamples = optNumTrials.getValue();
	generate = optGenerate.getValue();
	packages = optPackages.getValue();
	verbose = optVerbose.getValue();

	outputPath = optWrite.getValue();	
	if (outputPath != null) {
	    // Need to determine output interval
	    outputInterval = optInterval.getValue();
	    if (outputInterval == 0) {
		// default value is num samples / 100
		outputInterval = Math.max(optNumSamples.getValue() / 100, 1);
	    }
	} else if (optInterval.wasPresent()) {
	    System.err.println("Warning: ignoring --interval option "
			       + "because no output file specified.");
	}

	histOut = optHist.getValue();

	// Load inference properties specified with -P option
	inferenceProps = optInferenceProps.getValue();
	for (Iterator iter = inferenceProps.keySet().iterator(); 
	     iter.hasNext(); ) {
	    String property = (String) iter.next();
	    Option specialOpt = (Option) specialOptions.get(property);
	    if (specialOpt != null) {
		System.err.println("Error: can't use -P to set value for \""
				   + property + "\".  Use special-purpose "
				   + "option " + specialOpt + " instead.");
	    }
	}

	// Enter properties from special-purpose options
	inferenceProps.setProperty("engineClass", optEngine.getValue());
	inferenceProps.setProperty("numSamples", 
				   String.valueOf(optNumSamples.getValue()));
	numSamples = optNumSamples.getValue();
	inferenceProps.setProperty("samplerClass", optSampler.getValue());
	inferenceProps.setProperty("proposerClass", optProposer.getValue());
    }

    /**
     * Print to the PrintStream ps the String s exactly n times, followed by a 
     * newline.
     */
    public static void printTimes(PrintStream ps, String s, int n) {
	for (int i = 0 ; i < n ; i++) {
	    ps.print(s);
	}
	ps.println();
    }

    /**
     * Returns a PrintStream representing the newly created file, with given 
     * pathname s.  Guaranteed not to be null.
     */
    public static PrintStream filePrintStream(String s) {
	try {
	    File f = new File(s);
	    if (! f.createNewFile()) {
		System.err.println("Cannot create file (already exists): "
				   + f.getPath());
		System.exit(1);
	    }
	    if (! f.canWrite()) {
		System.err.println("Cannot write to file: " + f.getPath());
		System.exit(1);
	    }
	    return new PrintStream(new FileOutputStream(f));
	} catch (Exception e) {
	    System.err.println("Cannot create/open a file for output: " + s);
	    System.err.println(e);
	    System.exit(1);
	    return null;  // for some reason, the compiler needs this.
	}
    }

    public static boolean verbose() {
	return verbose;
    }

    public static String outputPath() {
	return outputPath;
    }

    public static int outputInterval() {
	return outputInterval;
    }

    public static int numSamples() {
	return numSamples;
    }

    public static int numTrials() {
	return numStatSamples;
    }

    public static String histOut() {
	return histOut;
    }

    public static List getPackagesToSearch() {
	return packages;
    }

    public static int typeErrors = 0; 
    private static List filenames; // of String
    private static Properties inferenceProps;
    private static boolean randomize = false;
    private static int numSamples;
    private static boolean doDebugParse;
    private static int numStatSamples;
    private static Model model = new Model();
    private static Evidence evidence = new Evidence();
    private static List queries = new ArrayList();
    private static boolean generate;
    private static List packages;
    private static boolean verbose;
    private static String outputPath;
    private static int outputInterval;
    private static String histOut;
}
