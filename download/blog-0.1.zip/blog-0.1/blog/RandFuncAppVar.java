/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;

/**
 * A function application random variable.  It consists of a function  
 * and a tuple of arguments.  Its value in a given world is the value of that 
 * function applied to those arguments.
 */
public class RandFuncAppVar extends BasicVar {
    /**
     * Creates a RandFuncAppVar for the given function applied to the given 
     * tuple of arguments.
     */
    public RandFuncAppVar(RandomFunction f, List args) {
	super(args, f.getArgTypes());
	this.f = f;
    }

    /**
     * Returns the function being applied in this function application 
     * variable.
     */
    public RandomFunction func() {
	return f;
    }

    /**
     * Returns the dependency model for this variable's function.
     */
    public DependencyModel getDepModel() {
	return f.getDepModel();
    }

    /**
     * Returns the variables that stand for the function arguments in this 
     * variable's dependency model.
     *
     * @return a List of String objects representing the variables
     */
    public List getArgVars() {
	return f.getArgVars();
    }

    /**
     * Returns the return type of this variable's function.
     */
    public Type getType() {
	return f.getRetType();
    }

    /**
     * Two RandFuncAppVar objects are equal if they have the same function and
     * their argument lists are equal (recall that list equality is
     * checked by calling the <code>equals</code> method on each
     * corresponding pair of objects in the two lists).
     */
    public boolean equals(Object obj) {
	if (obj instanceof RandFuncAppVar) {
	    RandFuncAppVar other = (RandFuncAppVar) obj;
	    return ((func() == other.func()) 
		    && (args().equals(other.args())));
	}
	return false;
    }
		
    public int hashCode() {
	return func().hashCode() ^ args().hashCode();
    }

    public String toString() {
	if (args().isEmpty()) {
	    return f.toString();
	}

	StringBuffer buf = new StringBuffer();
	buf.append(f);
	buf.append("(");
	buf.append(args().get(0));
	for (int i = 1; i < args().size(); ++i) {
	    buf.append(", ");
	    buf.append(args().get(i));
	}
	buf.append(")");
	return buf.toString();
    }
	

    private RandomFunction f;
}
