/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package blog;

import java.util.*;
import common.Multiset;
import common.MultisetBackedSet;
import common.SetBackedMultiset;
import common.HashMapDiff;

/** Represents an argument - set with implicit specification of its elements. 
 * An ImplicitSetSpec consists of a type <code>type</code>, a variable 
 * <code>set_elt</code>, and a formula <code>cond</code>.  It evaluates to 
 * the set of objects <i>o</i> of type <code>type</code> such that 
 * <code>cond</code> is satisfied when <code>set_elt</code> is bound to 
 * <i>o</i>.   
 */
public class ImplicitSetSpec extends ArgSpec{


    public ImplicitSetSpec( ){

    }


    public ImplicitSetSpec( String set_elt, Type type, Formula cond ){

	this.set_elt = set_elt;
	this.type = type;
	this.cond = cond;

	satisfierSpec = new CompiledSetSpec(type, set_elt, cond);
    }


    public String getGenericSetElt( ){

	return set_elt;

    }

  
    public Type getType( ){

	return type;

    }

  
    public Formula getCond( ){

	return cond;

    }

    /**
     * Returns the set of objects <i>o</i> of type <code>type</code>
     * such that when the assignment <code>a</code> is augmented so
     * <code>set_elt</code> is bound to <i>o</i>, the formula
     * <code>cond</code> is satisfied in <code>w</code>.  
     */
    public Set getSatisfyingSet(PartialWorld w, Assignment a) {
	return new MultisetBackedSet((Multiset) evaluate(w, a));
    }

    /**
     * Returns the active parents and value of this formula in the 
     * given partial world.  If the world is not complete enough to 
     * evaluate this formula, uses the given ValueChooser object to 
     * instantiate the necessary basic variables.  If the world is 
     * not complete enough and the ValueChooser is null, then this 
     * method returns null.  
     */
    public ParentsAndValue getParentsAndValue(PartialWorld w, 
					      Assignment a, 
					      ValueChooser chooser) {
	Set parents = new HashSet();
	PartEnumSet s = satisfierSpec.elementSet(w, a, chooser, parents);
	if (s == null) {
	    return null;
	}
	return new ParentsAndValue(parents, s);
    }

    public boolean checkTypesAndScope(Map scope) {
	Map extendedScope = new HashMapDiff(scope);
	extendedScope.put(set_elt, type);
	return cond.checkTypesAndScope(extendedScope);
    }

    /**
     * Two implicit set specifications are equal if they have the same
     * type, generic element variable, and condition.  Two implicit
     * set specifications that differ only in the choice of generic
     * element variable are equivalent, but we do not consider them equal, 
     * just as we do not consider two universally quantified formulas equal 
     * if they differ in the quantified variable.
     */
    public boolean equals(Object o) {
	if (o instanceof ImplicitSetSpec) {
	    ImplicitSetSpec other = (ImplicitSetSpec) o;
	    return (set_elt.equals(other.getGenericSetElt())
		    && type.equals(other.getType())
		    && cond.equals(other.getCond()));
	}
	return false;
    }

    public int hashCode() {
	return (set_elt.hashCode() ^ type.hashCode() ^ cond.hashCode());
    }

    /**
     * Returns a string of the form {Type var : cond} where Type is this 
     * implicit set specification's type, var is the generic set element 
     * variable, and cond is the membership condition.
     */
    public String toString() {
	return ("{" + type + " " + set_elt + " : " + cond + "}");
    }

    private String set_elt;
    private Type type;
    private Formula cond;

    private CompiledSetSpec satisfierSpec;
}
