Bayesian Logic (BLOG) Inference Engine version 0.1

Copyright (c) 2005, Regents of the University of California
All rights reserved.  This software is distributed under the license 
included in LICENSE.txt.

Lead author: Brian Milch, milch@cs.berkeley.edu
Supervisor: Prof. Stuart Russell
Contributors: Bhaskara Marthi, Andrey Kolobov, David Sontag, Daniel L. Ong


Online Information
------------------
For documentation and the latest version of the BLOG Inference Engine,
please see:

  http://www.cs.berkeley.edu/~milch/blog


Installation
------------
The following installation instructions assume that you're using a
machine with the Java SDK (version 1.4 or newer), the "make" utility,
and the ability to run a shell script.

Decompressing the ZIP archive that you downloaded will yield a
directory called "blog-0.1".  You can put this directory wherever you
like.  To compile the source code, go into this directory and type
"make".  The inference engine is now ready to run.


Getting Started
---------------
To get you started with BLOG, we'll show you how to reproduce the
experiment from our IJCAI-05 paper.  The top-level BLOG directory
contains a shell script called "runblog", which invokes java with the
proper classpath.  There is also a subdirectory called "examples" that
contains several example BLOG models.  To run inference on the
urn-and-balls scenario from our paper, give the command:

./runblog examples/balls/poisson-prior-noisy.mblog 
    examples/balls/all-same.eblog examples/balls/num-balls.qblog

The program will do inference and print out the posterior distribution over the number of balls in the urn, given 10 draws that all appear to be the same color.  By default, the program does 10000 samples of likelihood weighting.  You can compare its output to the correct posterior distribution, which is given in a comment at the end of examples/balls/poisson-prior-noisy.mblog.

To find out how to do more with the BLOG Inference Engine, please see the user manual at:

  http://www.cs.berkeley.edu/~milch/blog/manual


What Can It Do?
---------------
The BLOG Inference Engine Version 0.1 can parse any model written in
the BLOG language that we introduced in our SRL-04 and IJCAI-05
papers.  It includes a full set of built-in types (integers, strings,
real numbers, vectors, matrices) and can use arbitrary conditional
probability distributions (CPDs) in the form of Java classes that
implement a certain interface.  Models can include arbitrary
first-order formulas.

As noted in our papers, some BLOG models do not actually define unique
probability distributions, because they contain cycles or infinite
receding chains.  The current version of the Inference Engine does not
make any effort to detect whetehr a model is well-defined or not.  On
some ill-defined models, the inference algorithms will end up in
infinite loops.

This version of the Inference Engine includes three general-purpose
inference algorithms: rejection sampling (as in our IJCAI-05 paper),
likelihood weighting (as in our AISTATS-05 paper), and a
Metropolis-Hastings algorithm where the proposal distribution just
samples values for variables given their parents.  These algorithms
are very slow, but they can still yield interesting results on toy
problems.  The Inference Engine also allows modelers to plug in their
own Metropolis-Hastings proposal distributions: the proposal
distribution can propose arbitrary changes to the current world, and
the engine will compute the acceptance probability.  We include a
hand-crafted split-merge proposal distribution for the urn-and-balls
scenario as an example.

We also plan to include parameter estimation capabilities in the BLOG
Inference Engine -- specifically Monte Carlo EM.  However, the current
version has no learning code.


How to Help
-----------
The main reason we're releasing the BLOG Inference Engine code is so
that other people can use it, evaluate the strengths and weaknesses of
the BLOG language, and develop new inference and learning algorithms.
It would also be great to have help improving the Inference Engine's
interface and building utilities to work with it.  If you have
feedback, bug reports, ideas for improvement, or new code, please send
email to Brian Milch at milch@cs.berkeley.edu.
