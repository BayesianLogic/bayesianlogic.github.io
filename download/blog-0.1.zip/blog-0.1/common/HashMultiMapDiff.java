/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package common;

import java.util.*;

/**
 * Implementation of MultiMapDiff that uses two HashMultiMaps, one to store 
 * additions and one to store removals.
 */
public class HashMultiMapDiff extends AbstractMap implements MultiMapDiff {

    /**
     * Creates a new HashMultiMapDiff with the given underlying MultiMap.
     */
    public HashMultiMapDiff(MultiMap underlying) {
	this.underlying = underlying;
    }

    public int size() {
	int size = underlying.size();

	// Add 1 for each key that has a non-empty set here and an empty 
	// set in the underlying multi-map.
	for (Iterator iter = additions.entrySet().iterator(); 
	     iter.hasNext(); ) {
	    Map.Entry entry = (Map.Entry) iter.next();
	    if (!underlying.containsKey(entry.getKey())) {
		++size;
	    }
	}

	// Subtract 1 for each key whose set was removed completely
	for (Iterator iter = removals.entrySet().iterator(); 
	     iter.hasNext(); ) {
	    Map.Entry entry = (Map.Entry) iter.next();
	    Set orig = (Set) underlying.get(entry.getKey());
	    Set removed = (Set) entry.getValue();
	    if (removed.size() == orig.size()) {
		--size;
	    }
	}

	return size;
    }

    public boolean containsKey(Object key) {
	if (additions.containsKey(key)) {
	    return true;
	}

	Set orig = (Set) underlying.get(key);
	Set removed = (Set) removals.get(key);
	return (orig.size() > removed.size());
    }

    public Object get(Object key) {
	Set orig = (Set) underlying.get(key);
	Set added = (Set) additions.get(key);
	Set removed = (Set) removals.get(key);

	if ((added.size() > 0) || (orig.size() > removed.size())) {
	    Set set = new HashSet(orig);
	    set.addAll(added);
	    set.removeAll(removed);
	    return Collections.unmodifiableSet(set);
	}

	return Collections.EMPTY_SET;
    }

    public Object put(Object key, Object value) {
	if (!(value instanceof Set)) {
	    throw new IllegalArgumentException
		("Values stored in MultiMap must be sets.");
	}
       
	Set oldSet = (Set) get(key);
	Set newSet = (Set) value;
	Set orig = (Set) underlying.get(key);

	// Recompute additions
	additions.remove(key);
	for (Iterator iter = newSet.iterator(); iter.hasNext(); ) {
	    Object o = iter.next();
	    if (!orig.contains(o)) {
		additions.add(key, o);
	    }
	}

	// Recompute removals.  Note that this takes time linear in the 
	// size of the set associated with this key in the underlying 
	// multi-map.  
	removals.remove(key);
	for (Iterator iter = orig.iterator(); iter.hasNext(); ) {
	    Object o = iter.next();
	    if (!newSet.contains(o)) {
		removals.add(key, o);
	    }
	}

	return oldSet;
    }

    public void add(Object key, Object value) {
	// If this value is associated with this key in the underlying 
	// multi-map, just record that it was not removed.
	if (((Set) underlying.get(key)).contains(value)) {
	    removals.remove(key, value);
	} else {
	    // Really an addition
	    additions.add(key, value);
	}
    }

    public void addAll(Object key, Set values) {
	for (Iterator iter = values.iterator(); iter.hasNext(); ) {
	    add(key, iter.next());
	}
    }	

    public Object remove(Object key) {
	Set oldSet = (Set) get(key);

	// Clear all additions for this key, and set the removals to the 
	// full set associated with the key in the underlying multi-map.
	additions.remove(key);
	removals.put(key, (Set) underlying.get(key));

	return oldSet;
    }

    public void remove(Object key, Object value) {
	// If this value is associated with this key in the underlying 
	// multi-map, record the removal.
	if (((Set) underlying.get(key)).contains(value)) {
	    removals.add(key, value);
	} else {
	    // Just record that the value was not added
	    additions.remove(key, value);
	}
    }

    public void removeAll(Object key, Set values) {
	for (Iterator iter = values.iterator(); iter.hasNext(); ) {
	    remove(key, iter.next());
	}
    }

    public void clear() {
	additions.clear();

	// For every key in the underlying multi-map, every value is removed.
	for (Iterator iter = underlying.entrySet().iterator(); 
	     iter.hasNext(); ) {
	    Map.Entry entry = (Map.Entry) iter.next();
	    removals.addAll(entry.getKey(), (Set) entry.getValue());
	}
    }

    public Set entrySet() {
	return entrySet;
    }

    /**
     * Returns the set of keys for which the associated set in this 
     * multi-map contains some values that are not in the associated 
     * set in the underlying multi-map.  This includes keys that are not in 
     * the underlying multi-map at all.
     *
     * @return unmodifiable Set of Objects
     */
    public Set getKeysWithAdditions() {
	return Collections.unmodifiableSet(additions.keySet());
    }

    /**
     * Returns the set of keys for which the associated set in the underlying 
     * multi-map contains some values that are not in the associated set in 
     * this multi-map.  This includes keys that are not in this 
     * multi-map at all.
     *
     * @return unmodifiable Set of Objects
     */
    public Set getKeysWithRemovals() {
	return Collections.unmodifiableSet(removals.keySet());
    }

    /**
     * Returns the set of values that are associated with the given key in 
     * this multi-map and not in the underlying multi-map.  Returns an 
     * empty set if the key is not in this multi-map.  
     *
     * @return unmodifiable Set of Objects
     */
    public Set getAddedValues(Object key) {
	return (Set) additions.get(key);
    }

    /**
     * Returns the set of values that are associated with the given key in 
     * the underlying multi-map but not in this multi-map.  Returns an 
     * empty set if the key is not in the underlying multi-map.
     *
     * @return unmodifiable Set of Objects
     */
    public Set getRemovedValues(Object key) {
	return (Set) removals.get(key);
    }

    /**
     * Changes the underlying multi-map to equal this multi-map.
     */
    public void changeUnderlying() {
	// Apply additions
	for (Iterator entryIter = additions.entrySet().iterator();
	     entryIter.hasNext(); ) {
	    Map.Entry entry = (Map.Entry) entryIter.next();
	    underlying.addAll(entry.getKey(), (Set) entry.getValue());
	}

	// Apply removals
	for (Iterator entryIter = removals.entrySet().iterator(); 
	     entryIter.hasNext(); ) {
	    Map.Entry entry = (Map.Entry) entryIter.next();
	    underlying.removeAll(entry.getKey(), (Set) entry.getValue());
	}

	clearChanges();
    }

    /**
     * Resets this multi-map to be equal to the underlying multi-map.
     */
    public void clearChanges() {
	additions.clear();
	removals.clear();
    }

    private class EntrySet extends AbstractSet {
	public int size() {
	    return HashMultiMapDiff.this.size();
	}

	public boolean contains(Object o) {
	    if (o instanceof Map.Entry) {
		Map.Entry entry = (Map.Entry) o;
		return get(entry.getKey()).equals(entry.getValue());
	    }
	    return false;
	}

	public Iterator iterator() {
	    return new EntrySetIterator();
	}
    }

    private class EntrySetIterator implements Iterator {
	EntrySetIterator() {
	    underlyingIter = underlying.entrySet().iterator();

	    List addedEntries = new ArrayList();
	    for (Iterator iter = additions.entrySet().iterator(); 
		 iter.hasNext(); ) {
		Map.Entry addition = (Map.Entry) iter.next();
		if (!underlying.containsKey(addition.getKey())) {
		    addedEntries.add(new Entry(addition));
		    // Don't need to worry about removals because the set 
		    // associated with this key in the underlying multi-map 
		    // is empty.  
		}
	    }
	    addedEntriesIter = addedEntries.iterator();

	    prepareNextEntry();
	}

	public boolean hasNext() {
	    return (nextEntry != null);
	}

	public Object next() {
	    lastEntry = nextEntry;
	    prepareNextEntry();
	    return lastEntry;
	}

	public void remove() {
	    if (lastEntry == null) {
		throw new IllegalStateException("Nothing to remove.");
	    }

	    HashMultiMapDiff.this.remove(lastEntry.getKey());
	    lastEntry = null;
	}

	void prepareNextEntry() {
	    nextEntry = null;

	    // Iterate over the underlying map until we find key that 
	    // hasn't been removed.  Apply additions and removals to its 
	    // associated set.  
	    while (underlyingIter.hasNext()) {
		Map.Entry underlyingEntry = (Map.Entry) underlyingIter.next();
		Object key = underlyingEntry.getKey();
		Set orig = (Set) underlyingEntry.getValue();
		Set added = (Set) additions.get(key);
		Set removed = (Set) removals.get(key);
		Set resulting = orig;
		
		if ((!added.isEmpty()) || (!removed.isEmpty())) {
		    resulting = new HashSet(orig);
		    resulting.addAll(added);
		    resulting.removeAll(removed);
		}

		nextEntry 
		    = new Entry(key, Collections.unmodifiableSet(resulting));
		return;
	    }
	    
	    // Use the next added entry
	    if (addedEntriesIter.hasNext()) {
		nextEntry = (Map.Entry) addedEntriesIter.next();
	    }
	}

	Iterator underlyingIter;
	Iterator addedEntriesIter;
	Map.Entry lastEntry = null;
	Map.Entry nextEntry;
    }

    // We need to use our own Map.Entry objects instead of the underlying 
    // multi-map's entries because we don't want the setValue method to write 
    // through to the underlying multi-map; we want it to call the 
    // HashMultiMapDiff's put method instead.  This put operation doesn't 
    // disrupt the iteration because it doesn't change the underlying map.
    //
    // For iterating over added keys, we use our own Map.Entry objects 
    // so that removals from the additions map (which can happen if the 
    // iterator's remove method is called) don't disrupt our iteration.
    private class Entry extends DefaultMapEntry {
	Entry(Object key, Object value) {
	    super(key, value);
	}

	Entry(Map.Entry entry) {
	    super(entry);
	}

	public Object setValue(Object newValue) {
	    Object oldValue = getValue();
	    HashMultiMapDiff.this.put(getKey(), newValue);
	    value = newValue;
	    return oldValue;
	}
    }

    MultiMap underlying;

    MultiMap additions = new HashMultiMap();
    MultiMap removals = new HashMultiMap();

    EntrySet entrySet = new EntrySet();
}
