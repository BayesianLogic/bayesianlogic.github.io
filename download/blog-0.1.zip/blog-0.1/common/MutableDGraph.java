/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package common;

import java.util.*;

/**
 * Mutable implementation of the DGraph interface.  Represents both
 * the parent set and the child set for each node (even though this is
 * redundant) so both kinds of sets can be accessed quickly.
 */
public class MutableDGraph extends AbstractDGraph {
    /**
     * Creates a new, empty graph.
     */
    public MutableDGraph() {
    }

    /**
     * Returns an unmodifiable set consisting of the nodes in this graph.
     */
    public Set nodes() {
	return Collections.unmodifiableSet(nodeInfo.keySet());
    }

    /**
     * Returns an unmodifiable set consisting of the given object's parents.
     *
     * @throws IllegalArgumentException if the given object is not a node 
     *                                  in this graph
     */
    public Set getParents(Object v) {
	if (!nodeInfo.containsKey(v)) {
	    throw new IllegalArgumentException("Object not in graph: " + v);
	}
	
	Set parents = ((NodeInfo) nodeInfo.get(v)).parents;
	return Collections.unmodifiableSet(parents);
    }

    /**
     * Returns an unmodifiable set consisting of the given object's children.
     *
     * @throws IllegalArgumentException if the given object is not a node 
     *                                  in this graph
     */
    public Set getChildren(Object v) {
	if (!nodeInfo.containsKey(v)) {
	    throw new IllegalArgumentException("Object not in graph: " + v);
	}
	
	Set children = ((NodeInfo) nodeInfo.get(v)).children;
	return Collections.unmodifiableSet(children);
    }

    /**
     * Adds the given object as a node in the graph.  Does nothing if the 
     * object is already a node.
     */
    public void addNode(Object v) {
	if (!nodeInfo.containsKey(v)) {
	    nodeInfo.put(v, new NodeInfo());
	}
    }

    /**
     * Removes the given node from the graph, and removes all edges incident 
     * on the node.  Does nothing if the object is not in the graph.
     */
    public void removeNode(Object v) {
	NodeInfo info = (NodeInfo) nodeInfo.get(v);
	if (info == null) {
	    return;
	}

	for (Iterator iter = info.parents.iterator(); iter.hasNext(); ) {
	    Object parent = iter.next();
	    NodeInfo parentInfo = (NodeInfo) nodeInfo.get(parent);
	    parentInfo.children.remove(v);
	}
	for (Iterator iter = info.children.iterator(); iter.hasNext(); ) {
	    Object child = iter.next();
	    NodeInfo childInfo = (NodeInfo) nodeInfo.get(child);
	    childInfo.parents.remove(v);
	}
	nodeInfo.remove(v);
    }

    /**
     * Adds to the graph an edge from <code>parent</code> to 
     * <code>child</code>.  
     */
    public void addEdge(Object parent, Object child) {
	NodeInfo parentInfo = (NodeInfo) nodeInfo.get(parent);
	parentInfo.children.add(child);

	NodeInfo childInfo = (NodeInfo) nodeInfo.get(child);
	childInfo.parents.add(parent);
    }

    /**
     * Removes from the graph an edge from <code>parent</code> to 
     * <code>child</code>.  This is safe to call even if 
     * <code>parent</code> or <code>child</code> has already been 
     * removed from the graph.  
     */
    public void removeEdge(Object parent, Object child) {
	NodeInfo parentInfo = (NodeInfo) nodeInfo.get(parent);
	if (parentInfo != null) {
	    parentInfo.children.remove(child);
	}

	NodeInfo childInfo = (NodeInfo) nodeInfo.get(child);
	if (childInfo != null) {
	    childInfo.parents.remove(parent);
	}
    }

    private static class NodeInfo {
	Set parents = new HashSet();
	Set children = new HashSet();
    }
    
    Map nodeInfo = new HashMap(); // from Object to NodeInfo
}
