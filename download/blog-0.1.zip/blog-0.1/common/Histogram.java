/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package common;

import java.util.*;

/**
 * A mapping from objects to weights, which are real numbers.  A
 * Histogram maintains an internal hash map from objects to Doubles,
 * and also keeps track of the sum of the weights.  
 *
 * <p>A histogram conceptually stores a weight for every object, but most 
 * objects have zero weight.  Only objects with non-zero weight are 
 * explicitly represented.  The <code>iterator</code> method only allows you 
 * to iterate over objects with non-zero weight; if you want to iterate 
 * over other objects, you need to enumerate those objects in some other 
 * way, and call <code>getWeight</code> for each one.  
 */
public class Histogram {
    /**
     * Creates an empty histogram.
     */
    public Histogram() {
	totalWeight = 0;
    }

    /**
     * Returns the weight of the given object in this histogram.  If the 
     * object is not explicitly represented in the histogram, its weight 
     * is zero.
     */
    public double getWeight(Object obj) {
	Double value = (Double) map.get(obj);
	if (value == null) {
	    return 0;
	}
	return value.doubleValue();
    }

    /**
     * Returns the sum of the weights of all objects in this histogram.
     */
    public double getTotalWeight() {
	return totalWeight;
    }

    /**
     * Increases the weight for the given object by the given amount.  
     * If the object was not explicitly represented in the histogram, its 
     * old weight is considered to be zero.
     */
    public void increaseWeight(Object obj, double delta) {
	double newWeight = getWeight(obj) + delta;
	if (newWeight == 0) {
	    map.remove(obj);
	} else {
	    map.put(obj, new Double(newWeight));
	}

	totalWeight += delta;
    }

    /**
     * Resets the weights of all objects to zero.
     */
    public void clear() {
	map.clear();
	totalWeight = 0;
    }

    /**
     * Returns an unmodifiable view of the set of objects that have 
     * non-zero weight in this histogram.
     */
    public Set elementSet() {
	return Collections.unmodifiableMap(map).keySet();
    }

    /**
     * Returns an unmodifiable view of the set of Histogram.Entry objects 
     * corresponding to the non-zero weight objects in this histogram.
     */
    public Set entrySet() {
	return entrySet;
    }

    /**
     * Nested class for the entries in a histogram.
     */
    public static class Entry {
	Entry(Object obj, double weight) {
	    this.obj = obj;
	    this.weight = weight;
	}

	/**
	 * Returns the object in this entry.
	 */
	public Object getElement() {
	    return obj;
	}

	/**
	 * Returns the weight of the object.
	 */
	public double getWeight() {
	    return weight;
	}

	public boolean equals(Object o) {
	    if (o instanceof Histogram.Entry) {
		Histogram.Entry other = (Histogram.Entry) o;
		return (other.getElement().equals(obj) 
			&& (other.getWeight() == weight));
	    }
	    return false;
	}

	public int hashCode() {
	    return obj.hashCode();
	}

	public String toString() {
	    return ("(" + obj + ", " + weight + ")");
	}

	private Object obj;
	private double weight;
    }    

    private class EntrySet extends AbstractSet {
	public int size() {
	    return map.size();
	}

	public Iterator iterator() {
	    return new EntrySetIterator();
	}

	private class EntrySetIterator implements Iterator {
	    public boolean hasNext() {
		return mapIter.hasNext();
	    }
	    
	    public Object next() {
		Map.Entry mapEntry = (Map.Entry) mapIter.next();
		double weight = ((Double) mapEntry.getValue()).doubleValue();
		return new Histogram.Entry(mapEntry.getKey(), weight);
	    }

	    public void remove() {
		throw new UnsupportedOperationException
		    ("Histogram entry set iterator does not allow removal.");
	    }

	    private Iterator mapIter = map.entrySet().iterator();
	}
    }

    private HashMap map = new HashMap();
    private double totalWeight;
    private EntrySet entrySet = new Histogram.EntrySet();
}
