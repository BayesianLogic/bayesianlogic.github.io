/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package common;

import java.util.*;

/**
 * MapDiff implementation that uses a HashMap to store the values for 
 * changed keys, and a HashSet to store the removed keys.
 */
public class HashMapDiff extends AbstractMap implements MapDiff {
    /**
     * Creates a new HashMapDiff with the given underlying map.
     */
    public HashMapDiff(Map underlying) {
	this.underlying = underlying;
    }

    public boolean containsKey(Object key) {
	if (changedKeys.containsKey(key)) {
	    return true;
	} else if (removedKeys.contains(key)) {
	    return false;
	}
	return underlying.containsKey(key);
    }

    public Object get(Object key) {
	if (changedKeys.containsKey(key)) {
	    return changedKeys.get(key);
	} else if (removedKeys.contains(key)) {
	    return null;
	}
	return underlying.get(key);
    }

    public int size() {
	int size = underlying.size();
	
	for (Iterator iter = changedKeys.keySet().iterator(); 
	     iter.hasNext(); ) {
	    if (!underlying.containsKey(iter.next())) {
		++size;
	    }
	}

	size -= removedKeys.size();
	return size;
    }

    public Object put(Object key, Object value) {
	Object oldValue = get(key);

	// If the same key-value mapping is in the underlying map, then just 
	// record that the value for this key is unchanged.
	if (underlying.containsKey(key)) {
	    Object underlyingValue = underlying.get(key);
	    if (((value == null) && (underlyingValue == null))
		|| ((value != null) && value.equals(underlyingValue))) {
		// Yes, same value
		changedKeys.remove(key);
		removedKeys.remove(key);
		return oldValue;
	    }
	}

	// Otherwise, record the change.
	changedKeys.put(key, value);
	removedKeys.remove(key);
	return oldValue;
    }

    public Object remove(Object key) {
	Object oldValue = null;

	// If value was changed, remove from changedKeys map.  If key is also 
	// in underlying map, record that it was removed.  
	if (changedKeys.containsKey(key)) {
	    oldValue = changedKeys.get(key);
	    changedKeys.remove(key);
	    if (underlying.containsKey(key)) {
		removedKeys.add(key);
	    }
	} else if (underlying.containsKey(key) && !removedKeys.contains(key)) {
	    // In underlying map, value not changed.  Just record removal.  
	    oldValue = underlying.get(key);
	    removedKeys.add(key);
	} 

	return oldValue;
    }

    public Set entrySet() {
	return entrySet;
    }

    /**
     * Returns the set of keys that are in this map but not the underlying 
     * map, or map to different values in this map than in the underlying map.
     *
     * @return unmodifiable Set of Object
     */
    public Set getChangedKeys() {
	return Collections.unmodifiableSet(changedKeys.keySet());
    }

    /**
     * Returns the set of keys that are in the underlying map but not in 
     * this map.
     *
     * @return unmodifiable Set of Object
     */
    public Set getRemovedKeys() {
	return Collections.unmodifiableSet(removedKeys);
    }

    /**
     * Changes the underlying map so it is equal to this map.
     *
     * @throws UnsupportedOperationException if the underlying map is 
     *                                       not modifiable
     */
    public void changeUnderlying() {
	for (Iterator iter = changedKeys.entrySet().iterator(); 
	     iter.hasNext(); ) {
	    Map.Entry entry = (Map.Entry) iter.next();
	    underlying.put(entry.getKey(), entry.getValue());
	}

	for (Iterator iter = removedKeys.iterator(); iter.hasNext(); ) {
	    underlying.remove(iter.next());
	}

	clearChanges();
    }

    /**
     * Resets this map so it is equal to the underlying map.
     */
    public void clearChanges() {
	changedKeys.clear();
	removedKeys.clear();
    }

    // Private inner class; an object of this class is returned by entrySet.
    private class EntrySet extends AbstractSet {
	
	public int size() {
	    return HashMapDiff.this.size();
	}

	public boolean contains(Object obj) {
	    if (obj instanceof Map.Entry) {
		Map.Entry entry = (Map.Entry) obj;
		if (containsKey(entry.getKey())) {
		    Object value = get(entry.getKey());
		    return ((value == null) ? 
			    entry.getValue() == null :
			    value.equals(entry.getValue()));
		}
	    }
	    return false;
	}

	public Iterator iterator() {
	    return new EntrySetIterator();
	}
    }

    // First iterates over the entry set of the underlying map, 
    // skipping keys that have been removed and returning the changed values 
    // for keys whose values have changed.  Then iterates over the 
    // changed keys, returning entries for those that are not in the 
    // underlying map.  
    private class EntrySetIterator implements Iterator {
	EntrySetIterator() {
	    underlyingIter = underlying.entrySet().iterator();

	    List addedEntries = new ArrayList();
	    for (Iterator iter = changedKeys.entrySet().iterator(); 
		 iter.hasNext(); ) {
		Map.Entry changedEntry = (Map.Entry) iter.next();
		if (!underlying.containsKey(changedEntry.getKey())) {
		    addedEntries.add(new Entry(changedEntry));
		}
	    }
	    addedEntriesIter = addedEntries.iterator();

	    prepareNextEntry();
	}

	public boolean hasNext() {
	    return (nextEntry != null);
	}

	public Object next() {
	    lastEntry = nextEntry;
	    prepareNextEntry();
	    return lastEntry;
	}

	public void remove() {
	    if (lastEntry == null) {
		throw new IllegalStateException("Nothing to remove.");
	    }

	    HashMapDiff.this.remove(lastEntry.getKey());
	    lastEntry = null;
	}

	void prepareNextEntry() {
	    nextEntry = null;

	    // Iterate over the underlying map until we find entry that 
	    // hasn't been removed.  Use new value if it was changed.  
	    while (underlyingIter.hasNext()) {
		Map.Entry underlyingEntry = (Map.Entry) underlyingIter.next();
		Object key = underlyingEntry.getKey();
		if (changedKeys.containsKey(key)) {
		    // value changed, but not removed
		    nextEntry = new Entry(key, changedKeys.get(key));
		    return;
		}
		if (!removedKeys.contains(key)) {
		    // value unchanged, not removed
		    nextEntry = new Entry(underlyingEntry);
		    return;
		}
	    }
	    
	    // Use the next added entry
	    if (addedEntriesIter.hasNext()) {
		nextEntry = (Map.Entry) addedEntriesIter.next();
	    }
	}

	Iterator underlyingIter;
	Iterator addedEntriesIter;
	Map.Entry lastEntry = null;
	Map.Entry nextEntry;
    }

    // We need to use our own Map.Entry objects instead of the underlying 
    // map's entries because we don't want the setValue method to write 
    // through to the underlying map; we want it to call the HashMapDiff's 
    // put method instead.  This put operation doesn't disrupt the iteration 
    // because it doesn't change the underlying map.
    //
    // For iterating over added entries, we use our own Map.Entry objects 
    // so that removals from the changedKeys map (which can happen if the 
    // iterator's remove method is called) don't disrupt our iteration.
    private class Entry extends DefaultMapEntry {
	Entry(Object key, Object value) {
	    super(key, value);
	}

	Entry(Map.Entry entry) {
	    super(entry);
	}

	public Object setValue(Object newValue) {
	    Object oldValue = getValue();
	    HashMapDiff.this.put(getKey(), newValue);
	    value = newValue;
	    return oldValue;
	}
    }

    private Map underlying;

    private Map changedKeys = new HashMap();
    private Set removedKeys = new HashSet();

    private Set entrySet = new EntrySet();
}
