/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package common;

import java.util.*;

/**
 * Directed graph that is backed by an underlying MutableDGraph, but 
 * represents changes to the set of nodes and to the parent sets of some 
 * existing nodes (and thus to the child sets of some nodes as well).
 */
public class ParentUpdateDGraph extends AbstractDGraph {
    /**
     * Creates a new ParentUpdateDGraph that represents no changes to the 
     * given underlying graph.
     */
    public ParentUpdateDGraph(MutableDGraph underlying) {
	this.underlying = underlying;
    }

    public Set nodes() {
	Set nodes = new HashSet(underlying.nodes());
	nodes.removeAll(removedNodes);
	nodes.addAll(newParentSets.keySet());
	return nodes;
    }

    public Set getParents(Object v) {
	if (newParentSets.containsKey(v)) {
	    return Collections.unmodifiableSet((Set) newParentSets.get(v));
	} else if (underlying.nodes().contains(v) 
		   && !removedNodes.contains(v)) {
	    return underlying.getParents(v);
	}

	throw new IllegalArgumentException("Object not in graph: " + v);
    }

    public Set getChildren(Object v) {
	if (!containsNode(v)) {
	    throw new IllegalArgumentException("Object not in graph: " + v);
	}

	Set childrenSet = new HashSet();

	if(underlying.nodes().contains(v))
	    childrenSet.addAll(underlying.getChildren(v));
	if(childSetRemove.containsKey(v))
	    childrenSet.removeAll((Set) childSetRemove.get(v));
	if(childSetAdd.containsKey(v))
	    childrenSet.addAll((Set) childSetAdd.get(v));

	return childrenSet;
    }

    /**
     * Returns true if the updated graph contains the given object as a node.
     */
    public boolean containsNode(Object v) {
	return ((underlying.nodes().contains(v) 
		 || newParentSets.keySet().contains(v))
		&& !removedNodes.contains(v));
    }

    /**
     * Adds the given node to the graph with an empty parent set.  Does 
     * nothing if the node is already in the graph.  If a node is removed 
     * and then added again, it gets an empty parent set.  
     */
    public void addNode(Object v) {
	if (!containsNode(v)) {
	    newParentSets.put(v, new HashSet());
	    removedNodes.remove(v); // in case it was removed previously
	}
    }

    /**
     * Removes the given node from the graph, along with all incident edges.
     * 
     * @throws IllegalArgumentException if the node is not in the graph.
     */
    public void removeNode(Object v) {
	if (!containsNode(v)) {
	    throw new IllegalArgumentException("Object not in graph: " + v);
	}

	// Remove all incoming edges
	setParents(v, Collections.EMPTY_SET);

	// Remove all outgoing edges
	for (Iterator iter = getChildren(v).iterator(); iter.hasNext(); ) {
	    Object child = iter.next();
	    Set newParentSet = new HashSet(getParents(child));
	    newParentSet.remove(v);
	    setParents(child, newParentSet);
	}

	newParentSets.remove(v);
	childSetAdd.remove(v);
	childSetRemove.remove(v);
	removedNodes.add(v);
    }

    /**
     * Changes the parent set of the given node to equal the given set.  
     * 
     * @throws IllegalArgumentException if any elements of the new parent 
     *                                  set are not nodes in the graph
     */
    public void setParents(Object v, Set newParents) {
	Set curParents = getParents(v);
	if (curParents.equals(newParents)) {
	    return;
	}
	
	for (Iterator iter = newParents.iterator(); iter.hasNext(); ) {
	    Object parent = iter.next();
	    if (!containsNode(parent)) {
		throw new IllegalArgumentException("New parent not in graph: " 
						   + parent);
	    }
	    if (!curParents.contains(parent)) {
		addChild(parent, v);
	    }
	}

	for (Iterator iter = curParents.iterator(); iter.hasNext(); ) {
	    Object parent = iter.next();
	    if (!newParents.contains(parent)) {
		removeChild(parent, v);
	    }
	}

	newParentSets.put(v, newParents);
    }

    /**
     * Returns the set of nodes that are barren in this graph but are
     * not barren nodes in the underlying graph.  A barren node is one
     * with no children.
     */
    public Set getNewlyBarrenNodes() {
	Set newlyBarren = new HashSet();
	
	// One way to get a new barren node is to add a node, but not add 
	// any children to it.
	for (Iterator iter = newParentSets.keySet().iterator(); 
	     iter.hasNext(); ) {
	    Object v = iter.next();
	    if (!underlying.nodes().contains(v)
		  && !childSetAdd.containsKey(v)) {
		newlyBarren.add(v);
	    }
	}

	// The other way is to remove children from a node.
	for (Iterator iter = childSetRemove.keySet().iterator(); 
	     iter.hasNext(); ) {
	    Object v = iter.next();
	    if (getChildren(v).isEmpty()) {
		// Make sure it wasn't already barren
		if (!(underlying.nodes().contains(v) 
		      && underlying.getChildren(v).isEmpty())) {
		    newlyBarren.add(v);
		}
	    }
	}

	return newlyBarren;
    }

    /**
     * Changes the underlying graph so it is equal to this graph.  
     */
    public void changeUnderlying() {
	// Add nodes that were added (and not removed again)
	for (Iterator iter = newParentSets.keySet().iterator(); 
	     iter.hasNext(); ) {
	    underlying.addNode(iter.next());
	}

	// Remove nodes that were removed (and not added again)
	for (Iterator iter = removedNodes.iterator(); iter.hasNext(); ) {
	    underlying.removeNode(iter.next());
	}

	//  Add new edges.
	Iterator parentIter = childSetAdd.keySet().iterator();
	while(parentIter.hasNext()) {
	    Object parent = parentIter.next();
	    Iterator childrenIter =
		((Set) childSetAdd.get(parent)).iterator();
	    while(childrenIter.hasNext())
		underlying.addEdge(parent, childrenIter.next());
	}

	//  Remove deleted edges (where parent was not removed). 
	parentIter = childSetRemove.keySet().iterator();
	while(parentIter.hasNext()) {
	    Object parent = parentIter.next();
	    Iterator childrenIter =
		((Set) childSetRemove.get(parent)).iterator();
	    while(childrenIter.hasNext())
		underlying.removeEdge(parent, childrenIter.next());
	}

	clearChanges();
    }

    public void clearChanges() {
	removedNodes.clear();
	newParentSets.clear();
	childSetAdd.clear();
	childSetRemove.clear();
    }	

    void addChild(Object parent, Object child) {
	// If this child was previously removed, just reverse that operation
	if (((Set) childSetRemove.get(parent)).contains(child)) {
	    childSetRemove.remove(parent, child);
	} else {
	    // Really an addition
	    childSetAdd.add(parent, child);
	}
    }

    void removeChild(Object parent, Object child) {
	// If this child was previously added, just reverse that operation
	if (((Set) childSetAdd.get(parent)).contains(child)) {
	    childSetAdd.remove(parent, child);
	} else {
	    // Really a removal
	    childSetRemove.add(parent, child);
	}
    }

    // Underlying graph
    MutableDGraph underlying;

    // Set of nodes removed from the graph.
    Set removedNodes = new HashSet();

    // Map from node objects to Set objects representing their new 
    // parent sets.  Nodes that are not in the underlying graph are 
    // also included here.  
    Map newParentSets = new HashMap();
   
    // Multi-map from node objects to the sets of nodes added to their 
    // child sets.
    MultiMap childSetAdd = new HashMultiMap();

    // Multi-map from node objects to the sets of nodes removed from their 
    // child sets.
    MultiMap childSetRemove = new HashMultiMap();
}
