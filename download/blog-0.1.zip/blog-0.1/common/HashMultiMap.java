/*
 * Copyright (c) 2005, Regents of the University of California
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.  
 *
 * * Neither the name of the University of California, Berkeley nor
 *   the names of its contributors may be used to endorse or promote
 *   products derived from this software without specific prior 
 *   written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package common;

import java.util.*;

/**
 * Implementation of the MultiMap interface that uses a HashMap for the 
 * map and HashSets for automatically created sets.
 *
 * <p>Technically, a MultiMap implementation should put a wrapper around 
 * the iterators for the underlying data structure so the values associated 
 * with keys are <b>unmodifiable</b> sets.  Also, its Map.Entry objects 
 * should have a <code>setValue</code> method that removes the key when the 
 * value is set to an empty set.  For now, we don't bother with these issues.  
 */
public class HashMultiMap extends AbstractMap implements MultiMap {
    /**
     * Creates a new, empty HashMultiMap.
     */
    public HashMultiMap() {
	map = new HashMap();
    }

    /**
     * Creates a new HashMultiMap that is equal to the given MultiMap.
     */
    public HashMultiMap(MultiMap orig) {
	map = new HashMap(orig);
    }

    public int size() {
	return map.size();
    }

    public boolean containsKey(Object key) {
	return map.containsKey(key);
    }

    public boolean containsValue(Object value) {
	return map.containsValue(value);
    }

    public Object get(Object key) {
	Set set = (Set) map.get(key);
	if (set == null) {
	    return Collections.EMPTY_SET;
	}
	return Collections.unmodifiableSet(set);
    }

    public Object put(Object key, Object value) {
	if (!(value instanceof Set)) {
	    throw new IllegalArgumentException
		("Values stored in MultiMap must be sets.");
	}
       
	Object oldValue = get(key);
	map.put(key, new HashSet((Set) value)); // in case value unmodifiable
	return oldValue;
    }

    public void add(Object key, Object value) {
	Set s = addKeyInternal(key);
	s.add(value);
    }

    public void addAll(Object key, Set values) {
	Set s = addKeyInternal(key);
	s.addAll(values);
    }	

    private Set addKeyInternal(Object key) {
	Set s = (Set) map.get(key);
	if (s == null) {
	    s = new HashSet();
	    map.put(key, s);
	}
	return s;
    }

    public Object remove(Object key) {
	Object oldValue = get(key);
	map.remove(key);
	return oldValue;
    }

    public void remove(Object key, Object value) {
	Set s = (Set) map.get(key);
	if (s != null) {
	    s.remove(value);
	    if (s.isEmpty()) {
		map.remove(key);
	    }
	}
    }

    public void removeAll(Object key, Set values) {
	Set s = (Set) map.get(key);
	if (s != null) {
	    s.removeAll(values);
	    if (s.isEmpty()) {
		map.remove(key);
	    }
	}
    }

    public void clear() {
	map.clear();
    }

    public Set entrySet() {
	return map.entrySet();
    }

    public Set keySet() {
	return map.keySet();
    }

    public boolean equals(Object o) {
	return map.equals(o);
    }

    public int hashCode() {
	return map.hashCode();
    }

    private HashMap map;
}
