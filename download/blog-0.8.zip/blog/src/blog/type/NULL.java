package blog.type;

public class NULL extends Type {
	public NULL() {
	}

	public boolean coerceTo(Type t) {
		// TO-DO
		return true;
	}
}
