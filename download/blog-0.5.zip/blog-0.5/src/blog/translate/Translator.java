/**
 * 
 */
package blog.translate;

/**
 * @author leili
 *
 */
public class Translator {

}
