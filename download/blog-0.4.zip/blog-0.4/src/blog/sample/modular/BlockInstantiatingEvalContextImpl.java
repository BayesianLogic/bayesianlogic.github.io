/**
 * 
 */
package blog.sample.modular;

import blog.sample.ClassicInstantiatingEvalContext;
import blog.world.PartialWorld;

/**
 * @author leili
 *
 */
public class BlockInstantiatingEvalContextImpl extends
		ClassicInstantiatingEvalContext implements BlockInstantiatingEvalContext {

	/**
	 * @param world
	 */
	public BlockInstantiatingEvalContextImpl(PartialWorld world) {
		super(world);
	}
	
	
	

}
