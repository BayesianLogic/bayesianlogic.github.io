package blog.engine;

import java.io.BufferedReader;
import java.io.Reader;

public class EvidenceReader extends BufferedReader {

	public EvidenceReader(Reader in) {
		super(in);
		// TODO Auto-generated constructor stub
	}

}
