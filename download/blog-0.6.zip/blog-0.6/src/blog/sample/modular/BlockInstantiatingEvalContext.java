package blog.sample.modular;

import blog.sample.InstantiatingEvalContext;

public interface BlockInstantiatingEvalContext extends InstantiatingEvalContext {
//	public 
}
