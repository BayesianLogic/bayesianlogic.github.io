package common;

/**
 * The interface of a unary predicate, useful for anonymous classes used as Lambda operators.
 * @author Rodrigo
 *
 */
public interface UnaryPredicate {
	public boolean test(Object x);
}
